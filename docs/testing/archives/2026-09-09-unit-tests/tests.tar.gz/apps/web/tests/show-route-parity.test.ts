import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest, NextResponse } from "next/server";

process.env.TRR_ADMIN_ROUTE_CACHE_DISABLED = "1";

const {
  requireAdminMock,
  fetchAdminBackendJsonMock,
  getShowByIdMock,
  updateShowByIdMock,
  resolveShowSlugMock,
} = vi.hoisted(() => ({
  requireAdminMock: vi.fn(),
  fetchAdminBackendJsonMock: vi.fn(),
  getShowByIdMock: vi.fn(),
  updateShowByIdMock: vi.fn(),
  resolveShowSlugMock: vi.fn(),
}));

vi.mock("@/lib/server/auth", () => ({
  requireAdmin: requireAdminMock,
  toVerifiedAdminContext: (user: { uid: string; email?: string }) => ({
    uid: user.uid,
    email: user.email ?? null,
    verifiedAt: 42,
  }),
}));

vi.mock("@/lib/server/trr-api/trr-shows-repository", () => ({
  getShowById: getShowByIdMock,
  updateShowById: updateShowByIdMock,
  validateShowImageForField: vi.fn(),
}));

vi.mock("@/lib/server/trr-api/admin-show-slug-reads", () => ({
  getAdminShowByExactSlug: vi.fn(),
}));

vi.mock("@/lib/server/trr-api/public-identities", () => ({
  resolveShowSlug: resolveShowSlugMock,
}));

vi.mock("@/lib/server/trr-api/admin-read-proxy", () => ({
  fetchAdminBackendJson: fetchAdminBackendJsonMock,
  invalidateAdminBackendCache: vi.fn(),
  ADMIN_READ_PROXY_SHORT_TIMEOUT_MS: 5_000,
  ADMIN_READ_PROXY_PRIMARY_TIMEOUT_MS: 12_000,
  buildAdminProxyErrorResponse: (error: unknown) =>
    NextResponse.json({ error: error instanceof Error ? error.message : "failed" }, { status: 500 }),
}));

import { GET as getShowsRoute } from "@/app/api/admin/trr-api/shows/route";
import {
  GET as getShowByIdRoute,
  PUT as putShowByIdRoute,
} from "@/app/api/admin/trr-api/shows/[showId]/route";
import { GET as getShowResolveSlugRoute } from "@/app/api/admin/trr-api/shows/resolve-slug/route";

describe("TRR show route parity", () => {
  beforeEach(() => {
    requireAdminMock.mockReset();
    fetchAdminBackendJsonMock.mockReset();
    getShowByIdMock.mockReset();
    updateShowByIdMock.mockReset();
    resolveShowSlugMock.mockReset();
    requireAdminMock.mockResolvedValue({ uid: "admin-user" });
  });

  it("returns backend-owned show search results with canonical slugs preserved", async () => {
    fetchAdminBackendJsonMock.mockResolvedValueOnce({
      status: 200,
      data: {
        shows: [
          {
            id: "7782652f-783a-488b-8860-41b97de32e75",
            name: "The Real Housewives of Salt Lake City",
            slug: "the-real-housewives-of-salt-lake-city",
            canonical_slug: "the-real-housewives-of-salt-lake-city",
          },
        ],
        pagination: { limit: 20, offset: 0, count: 1 },
      },
      durationMs: 5,
    });

    const response = await getShowsRoute(
      new NextRequest("http://localhost/api/admin/trr-api/shows?q=Salt+Lake"),
    );
    const payload = await response.json();

    expect(response.status).toBe(200);
    expect(fetchAdminBackendJsonMock).toHaveBeenCalledWith(
      "/admin/trr-api/shows?q=Salt+Lake&limit=20&offset=0",
      expect.objectContaining({ routeName: "admin-shows" }),
    );
    expect(payload.shows[0]).toMatchObject({
      slug: "the-real-housewives-of-salt-lake-city",
      canonical_slug: "the-real-housewives-of-salt-lake-city",
    });
  });

  it("returns the backend-owned single show contract", async () => {
    fetchAdminBackendJsonMock.mockResolvedValueOnce({
      status: 200,
      data: {
        show: {
          id: "7782652f-783a-488b-8860-41b97de32e75",
          name: "The Real Housewives of Salt Lake City",
          slug: "the-real-housewives-of-salt-lake-city",
          canonical_slug: "the-real-housewives-of-salt-lake-city",
        },
      },
      durationMs: 4,
    });

    const response = await getShowByIdRoute(
      new NextRequest("http://localhost/api/admin/trr-api/shows/7782652f-783a-488b-8860-41b97de32e75"),
      { params: Promise.resolve({ showId: "7782652f-783a-488b-8860-41b97de32e75" }) },
    );
    const payload = await response.json();

    expect(response.status).toBe(200);
    expect(response.headers.get("x-trr-show-detail-source")).toBe("backend");
    expect(fetchAdminBackendJsonMock).toHaveBeenCalledWith(
      "/admin/trr-api/shows/7782652f-783a-488b-8860-41b97de32e75",
      expect.objectContaining({ routeName: "show-detail", timeoutMs: 20_000 }),
    );
    expect(payload.show).toMatchObject({
      slug: "the-real-housewives-of-salt-lake-city",
      canonical_slug: "the-real-housewives-of-salt-lake-city",
    });
  });

  it("forwards show writes through the verified-admin repository seam", async () => {
    const showId = "7782652f-783a-488b-8860-41b97de32e75";
    updateShowByIdMock.mockResolvedValue({
      id: showId,
      name: "Updated Show",
      slug: "updated-show",
      canonical_slug: "updated-show",
    });

    const response = await putShowByIdRoute(
      new NextRequest(`http://localhost/api/admin/trr-api/shows/${showId}`, {
        method: "PUT",
        body: JSON.stringify({ name: "Updated Show" }),
        headers: { "content-type": "application/json" },
      }),
      { params: Promise.resolve({ showId }) },
    );

    expect(response.status).toBe(200);
    expect(updateShowByIdMock).toHaveBeenCalledWith(
      showId,
      { name: "Updated Show" },
      { adminContext: { uid: "admin-user", email: null, verifiedAt: 42 } },
    );
  });

  it("does not keep show detail responses in the in-memory route cache when caching is disabled", async () => {
    vi.resetModules();
    process.env.TRR_ADMIN_ROUTE_CACHE_DISABLED = "1";
    fetchAdminBackendJsonMock.mockResolvedValue({
      status: 200,
      data: {
        show: {
          id: "7782652f-783a-488b-8860-41b97de32e75",
          name: "The Real Housewives of Salt Lake City",
          slug: "the-real-housewives-of-salt-lake-city",
          canonical_slug: "the-real-housewives-of-salt-lake-city",
          watch_provider_regions: [
            {
              region: "US",
              stream: ["Peacock Premium"],
              free: ["Bravo TV"],
              buy_rent: ["Amazon Video", "Apple TV Store"],
            },
          ],
        },
      },
      durationMs: 4,
    });
    const { GET: freshGetShowByIdRoute } = await import("@/app/api/admin/trr-api/shows/[showId]/route");

    const request = new NextRequest(
      "http://localhost/api/admin/trr-api/shows/7782652f-783a-488b-8860-41b97de32e75",
    );
    const first = await freshGetShowByIdRoute(
      request,
      { params: Promise.resolve({ showId: "7782652f-783a-488b-8860-41b97de32e75" }) },
    );
    const second = await freshGetShowByIdRoute(
      request,
      { params: Promise.resolve({ showId: "7782652f-783a-488b-8860-41b97de32e75" }) },
    );

    expect(first.status).toBe(200);
    expect(second.status).toBe(200);
    expect(first.headers.get("x-trr-cache")).not.toBe("hit");
    expect(second.headers.get("x-trr-cache")).not.toBe("hit");
    expect(fetchAdminBackendJsonMock).toHaveBeenCalledTimes(2);
  });

  it("falls back to local show detail when the backend show read times out", async () => {
    const timeout = Object.assign(new Error("Admin read request timed out after 20s"), {
      status: 504,
      code: "BACKEND_TIMEOUT",
      retryable: true,
    });
    fetchAdminBackendJsonMock.mockRejectedValueOnce(timeout);
    getShowByIdMock.mockResolvedValueOnce({
      id: "7782652f-783a-488b-8860-41b97de32e75",
      name: "The Real Housewives of Salt Lake City",
      slug: "the-real-housewives-of-salt-lake-city",
      canonical_slug: "the-real-housewives-of-salt-lake-city",
    });

    const response = await getShowByIdRoute(
      new NextRequest("http://localhost/api/admin/trr-api/shows/7782652f-783a-488b-8860-41b97de32e75"),
      { params: Promise.resolve({ showId: "7782652f-783a-488b-8860-41b97de32e75" }) },
    );
    const payload = await response.json();

    expect(response.status).toBe(200);
    expect(response.headers.get("x-trr-show-detail-source")).toBe("local-fallback");
    expect(fetchAdminBackendJsonMock).toHaveBeenCalledTimes(1);
    expect(getShowByIdMock).toHaveBeenCalledWith("7782652f-783a-488b-8860-41b97de32e75");
    expect(payload.show).toMatchObject({
      id: "7782652f-783a-488b-8860-41b97de32e75",
      name: "The Real Housewives of Salt Lake City",
    });
  });

  it("can force local show detail fallback for smoke verification outside production", async () => {
    getShowByIdMock.mockResolvedValueOnce({
      id: "7782652f-783a-488b-8860-41b97de32e75",
      name: "The Traitors",
      slug: "the-traitors",
      canonical_slug: "the-traitors",
    });

    const response = await getShowByIdRoute(
      new NextRequest(
        "http://localhost/api/admin/trr-api/shows/7782652f-783a-488b-8860-41b97de32e75?__trr_smoke_force_local_fallback=1",
      ),
      { params: Promise.resolve({ showId: "7782652f-783a-488b-8860-41b97de32e75" }) },
    );
    const payload = await response.json();

    expect(response.status).toBe(200);
    expect(response.headers.get("x-trr-show-detail-source")).toBe("local-fallback");
    expect(fetchAdminBackendJsonMock).not.toHaveBeenCalled();
    expect(getShowByIdMock).toHaveBeenCalledWith("7782652f-783a-488b-8860-41b97de32e75");
    expect(payload.show).toMatchObject({
      id: "7782652f-783a-488b-8860-41b97de32e75",
      name: "The Traitors",
    });
  });

  it("keeps show resolve-slug parity", async () => {
    resolveShowSlugMock.mockResolvedValueOnce({
      show_id: "show-1",
      slug: "rhobh",
      canonical_slug: "rhobh",
      show_name: "The Real Housewives of Beverly Hills",
    });

    const response = await getShowResolveSlugRoute(
      new NextRequest("http://localhost/api/admin/trr-api/shows/resolve-slug?slug=rhobh"),
    );

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toEqual({
      resolved: {
        show_id: "show-1",
        slug: "rhobh",
        canonical_slug: "rhobh",
        show_name: "The Real Housewives of Beverly Hills",
      },
    });
    expect(resolveShowSlugMock).toHaveBeenCalledWith("rhobh");
    expect(fetchAdminBackendJsonMock).not.toHaveBeenCalled();
  });
});
