import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";

const {
  getBackendApiUrlMock,
  fetchAdminBackendJsonMock,
  requireAdminMock,
  buildAdminReadResponseHeadersMock,
} = vi.hoisted(() => ({
  getBackendApiUrlMock: vi.fn(),
  fetchAdminBackendJsonMock: vi.fn(),
  requireAdminMock: vi.fn(),
  buildAdminReadResponseHeadersMock: vi.fn(),
}));

vi.mock("@/lib/server/trr-api/backend", () => ({
  getBackendApiUrl: getBackendApiUrlMock,
}));

vi.mock("@/lib/server/auth", () => ({
  requireAdmin: requireAdminMock,
}));

vi.mock("@/lib/server/trr-api/admin-read-proxy", () => ({
  fetchAdminBackendJson: fetchAdminBackendJsonMock,
  ADMIN_READ_PROXY_SHORT_TIMEOUT_MS: 5_000,
  buildAdminReadResponseHeaders: buildAdminReadResponseHeadersMock,
}));

import {
  fetchSeasonBackendJson,
  fetchSocialBackendJson,
  resetSeasonIdResolutionCacheForTests,
  SOCIAL_PROXY_PROGRESS_TIMEOUT_MS,
  socialProxyErrorResponse,
} from "@/lib/server/trr-api/social-admin-proxy";
import { createSocialProfileProxyRoute } from "@/lib/server/trr-api/social-profile-route-factory";

describe("social-admin-proxy", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
    vi.spyOn(console, "error").mockImplementation(() => undefined);
    process.env.TRR_INTERNAL_ADMIN_SHARED_SECRET = "internal-secret-for-tests";
    delete process.env.TRR_CORE_SUPABASE_SERVICE_ROLE_KEY;
    requireAdminMock.mockReset();
    requireAdminMock.mockResolvedValue({
      uid: "admin-1",
      email: "admin@example.com",
      provider: "firebase",
      token: {},
    });
    buildAdminReadResponseHeadersMock.mockReset();
    buildAdminReadResponseHeadersMock.mockImplementation(({ cacheStatus }: { cacheStatus: string }) => ({
      "x-trr-cache": cacheStatus,
    }));
    fetchAdminBackendJsonMock.mockReset();
    fetchAdminBackendJsonMock.mockResolvedValue({
      status: 200,
      data: {
        seasons: [{ id: "season-1", season_number: 6 }],
        pagination: { count: 1 },
      },
      durationMs: 1,
    });
    getBackendApiUrlMock.mockReturnValue("http://backend.local/api/v1/admin/socials/seasons/season-1/analytics");
    resetSeasonIdResolutionCacheForTests();
  });

  it("retries transient upstream failures and succeeds", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce({
        ok: false,
        status: 502,
        json: async () => ({ error: "temporary upstream failure" }),
      } as Response)
      .mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({ ok: true }),
      } as Response)
      .mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ ok: true }),
      } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    const payload = await fetchSeasonBackendJson("show-1", "6", "/analytics", {
      fallbackError: "Failed to fetch social analytics",
      retries: 2,
      timeoutMs: 1000,
    });

    expect(payload).toEqual({ ok: true });
    expect(fetchAdminBackendJsonMock).toHaveBeenCalledWith(
      "/admin/trr-api/shows/show-1/seasons",
      expect.objectContaining({ routeName: "social-season-resolve" }),
    );
    const backendCalls = fetchMock.mock.calls.filter(
      (call) => String(call[0]) === "http://backend.local/api/v1/admin/socials/seasons/season-1/analytics",
    );
    expect(backendCalls).toHaveLength(2);
    const firstInit = backendCalls[0]?.[1] as RequestInit | undefined;
    const firstHeaders = new Headers(firstInit?.headers);
    expect(typeof firstHeaders.get("x-trace-id")).toBe("string");
    expect((firstHeaders.get("x-trace-id") ?? "").length).toBeGreaterThan(0);
    expect(firstHeaders.get("Authorization")).toMatch(/^Bearer /);
    expect(firstHeaders.get("x-trr-local-admin-proxy")).toBeNull();
  });

  it("marks loopback backend requests as local admin proxy calls", async () => {
    getBackendApiUrlMock.mockImplementation((path: string) => `http://127.0.0.1:8000/api/v1${path}`);
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ ok: true }),
    } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    await fetchSocialBackendJson("/profiles/instagram/bravotv/posts", {
      fallbackError: "Failed to fetch posts",
      timeoutMs: 1000,
    });

    const requestInit = fetchMock.mock.calls[0]?.[1] as RequestInit | undefined;
    const headers = new Headers(requestInit?.headers);
    expect(fetchMock.mock.calls[0]?.[0]).toBe("http://127.0.0.1:8000/api/v1/admin/socials/profiles/instagram/bravotv/posts");
    expect(headers.get("Authorization")).toMatch(/^Bearer /);
    expect(headers.get("x-trr-local-admin-proxy")).toBe("1");
  });

  it("does not retry mutating POST requests even when the upstream error is retryable", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 502,
      headers: { get: () => null },
      json: async () => ({ error: "temporary upstream failure" }),
    } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    await expect(
      fetchSocialBackendJson("/ingest/active-jobs/cancel", {
        method: "POST",
        body: JSON.stringify({}),
        headers: {
          "content-type": "application/json",
        },
        fallbackError: "Failed to cancel active jobs",
        retries: 3,
        timeoutMs: 1000,
      }),
    ).rejects.toThrow("temporary upstream failure");

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const requestInit = fetchMock.mock.calls[0]?.[1] as RequestInit | undefined;
    const forwardedHeaders = new Headers(requestInit?.headers);
    expect(forwardedHeaders.get("content-type")).toBe("application/json");
    expect(requestInit?.body).toBe(JSON.stringify({}));
  });

  it("still retries idempotent GET requests on retryable upstream errors", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce({
        ok: false,
        status: 502,
        headers: { get: () => null },
        json: async () => ({ error: "temporary upstream failure" }),
      } as Response)
      .mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({ ok: true }),
      } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    const payload = await fetchSocialBackendJson("/ingest/live-status", {
      method: "GET",
      fallbackError: "Failed to fetch live status",
      retries: 3,
      timeoutMs: 1000,
    });

    expect(payload).toEqual({ ok: true });
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it("maps persistent upstream 502 to retryable standardized envelope", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 502,
      json: async () => ({
        error: "still down",
        detail: { code: "SOCIAL_WORKER_UNAVAILABLE", message: "No healthy workers", worker_health: { healthy: false } },
      }),
    } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    let thrown: unknown;
    try {
      await fetchSeasonBackendJson("show-1", "6", "/analytics", {
        fallbackError: "Failed to fetch social analytics",
        retries: 1,
        timeoutMs: 1000,
      });
    } catch (error) {
      thrown = error;
    }

    expect(thrown).toBeDefined();
    const response = socialProxyErrorResponse(thrown, "[test] proxy failure");
    const payload = (await response.json()) as {
      error: string;
      code?: string;
      retryable?: boolean;
      trace_id?: string;
      upstream_status?: number;
      upstream_detail?: unknown;
      upstream_detail_code?: string;
    };

    expect(response.status).toBe(502);
    expect(payload.code).toBe("UPSTREAM_ERROR");
    expect(payload.retryable).toBe(true);
    expect(typeof payload.trace_id).toBe("string");
    expect((payload.trace_id ?? "").length).toBeGreaterThan(0);
    expect(payload.upstream_status).toBe(502);
    expect(payload.upstream_detail_code).toBe("SOCIAL_WORKER_UNAVAILABLE");
    expect(payload.upstream_detail).toEqual({
      code: "SOCIAL_WORKER_UNAVAILABLE",
      message: "No healthy workers",
      worker_health: { healthy: false },
    });
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it("maps backend pool saturation to retryable 503 metadata", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 503,
      headers: { get: () => null },
      json: async () => ({
        detail: "connection pool exhausted",
      }),
    } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    let thrown: unknown;
    try {
      await fetchSeasonBackendJson("show-1", "6", "/analytics", {
        fallbackError: "Failed to fetch social analytics",
        retries: 0,
        timeoutMs: 1000,
      });
    } catch (error) {
      thrown = error;
    }

    const response = socialProxyErrorResponse(thrown, "[test] saturation");
    const payload = (await response.json()) as {
      error: string;
      code?: string;
      retryable?: boolean;
      retry_after_seconds?: number;
      upstream_status?: number;
      upstream_detail?: unknown;
    };

    expect(response.status).toBe(503);
    expect(payload.code).toBe("BACKEND_SATURATED");
    expect(payload.retryable).toBe(true);
    expect(payload.retry_after_seconds).toBe(2);
    expect(payload.error).toMatch(/backend is saturated/i);
    expect(payload.upstream_status).toBe(503);
    expect(payload.upstream_detail).toBe("connection pool exhausted");
    expect(response.headers.get("retry-after")).toBe("2");
  });

  it("classifies raw 500 session-pool saturation as BACKEND_SATURATED", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 500,
      headers: { get: () => null },
      json: async () => ({
        detail: {
          code: "DATABASE_SERVICE_UNAVAILABLE",
          reason: "session_pool_capacity",
          message:
            "Database pool initialization failed: connection to server at aws-1-us-east-1.pooler.supabase.com failed: FATAL: MaxClientsInSessionMode: max clients reached",
        },
      }),
    } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    let thrown: unknown;
    try {
      await fetchSeasonBackendJson("show-1", "6", "/analytics", {
        fallbackError: "Failed to fetch social analytics",
        retries: 0,
        timeoutMs: 1000,
      });
    } catch (error) {
      thrown = error;
    }

    const response = socialProxyErrorResponse(thrown, "[test] raw saturation");
    const payload = (await response.json()) as {
      code?: string;
      retryable?: boolean;
      upstream_status?: number;
      upstream_detail?: unknown;
    };

    expect(response.status).toBe(503);
    expect(payload.code).toBe("BACKEND_SATURATED");
    expect(payload.retryable).toBe(true);
    expect(payload.upstream_status).toBe(500);
    expect(payload.upstream_detail).toEqual({
      code: "DATABASE_SERVICE_UNAVAILABLE",
      reason: "session_pool_capacity",
      message:
        "Database pool initialization failed: connection to server at aws-1-us-east-1.pooler.supabase.com failed: FATAL: MaxClientsInSessionMode: max clients reached",
    });
  });

  it("uses seasonIdHint directly when it is a valid UUID (skips canonical lookup)", async () => {
    const hintedSeasonId = "11111111-1111-4111-8111-111111111111";
    getBackendApiUrlMock.mockImplementation(
      (path: string) => `http://backend.local/api/v1${path}`,
    );

    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ ok: true }),
    } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    const payload = await fetchSeasonBackendJson("show-hint-1", "7", "/analytics", {
      queryString: "source_scope=bravo",
      seasonIdHint: hintedSeasonId,
      fallbackError: "Failed to fetch social analytics",
      retries: 0,
      timeoutMs: 1000,
    });

    expect(payload).toEqual({ ok: true });
    expect(fetchAdminBackendJsonMock).toHaveBeenCalledTimes(0);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(String(fetchMock.mock.calls[0]?.[0])).toContain(`/seasons/${hintedSeasonId}/analytics?source_scope=bravo`);
  });

  it("uses seasonIdHint even when canonical differs (no verification against DB)", async () => {
    const hintedSeasonId = "11111111-1111-4111-8111-111111111111";
    getBackendApiUrlMock.mockImplementation(
      (path: string) => `http://backend.local/api/v1${path}`,
    );

    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ ok: true }),
    } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    await fetchSeasonBackendJson("show-hint-2", "8", "/analytics", {
      seasonIdHint: hintedSeasonId,
      fallbackError: "Failed to fetch social analytics",
      retries: 0,
      timeoutMs: 1000,
    });

    expect(fetchAdminBackendJsonMock).toHaveBeenCalledTimes(0);
    expect(String(fetchMock.mock.calls[0]?.[0])).toContain(`/seasons/${hintedSeasonId}/analytics`);
  });

  it("falls back to season lookup when seasonIdHint is invalid", async () => {
    fetchAdminBackendJsonMock.mockResolvedValue({
      status: 200,
      data: {
        seasons: [{ id: "resolved-season-id", season_number: 9 }],
        pagination: { count: 1 },
      },
      durationMs: 1,
    });
    getBackendApiUrlMock.mockImplementation(
      (path: string) => `http://backend.local/api/v1${path}`,
    );

    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ ok: true }),
    } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    await fetchSeasonBackendJson("show-hint-3", "9", "/analytics", {
      seasonIdHint: "bad-season-id",
      fallbackError: "Failed to fetch social analytics",
      retries: 0,
      timeoutMs: 1000,
    });

    expect(fetchAdminBackendJsonMock).toHaveBeenCalledTimes(2);
    expect(fetchAdminBackendJsonMock).toHaveBeenNthCalledWith(
      1,
      "/shows/show-hint-3/seasons/9",
      expect.objectContaining({
        apiVersion: "v2",
        routeName: "public-core-show-season-detail",
      }),
    );
    expect(fetchAdminBackendJsonMock).toHaveBeenNthCalledWith(
      2,
      "/admin/trr-api/shows/show-hint-3/seasons",
      expect.objectContaining({ routeName: "social-season-resolve" }),
    );
  });

  it("normalizes DNS and SSL transport detail responses to BACKEND_UNREACHABLE", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 500,
      json: async () => ({
        detail: {
          code: "INTERNAL_ERROR",
          message: "could not translate host name \"aws-1-us-east-1.pooler.supabase.com\" to address",
          error: "SSL SYSCALL error: EOF detected",
        },
      }),
    } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    let thrown: unknown;
    try {
      await fetchSeasonBackendJson("show-1", "6", "/analytics", {
        fallbackError: "Failed to fetch social analytics",
        retries: 0,
        timeoutMs: 1000,
      });
    } catch (error) {
      thrown = error;
    }

    const response = socialProxyErrorResponse(thrown, "[test] transport failure");
    const payload = (await response.json()) as {
      code?: string;
      retryable?: boolean;
      upstream_status?: number;
    };

    expect(response.status).toBe(502);
    expect(payload.code).toBe("BACKEND_UNREACHABLE");
    expect(payload.retryable).toBe(true);
    expect(payload.upstream_status).toBe(500);
  });

  it("fails before fetch when the internal admin secret is absent", async () => {
    delete process.env.TRR_INTERNAL_ADMIN_SHARED_SECRET;
    getBackendApiUrlMock.mockImplementation((path: string) => `http://backend.local/api/v1${path}`);
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    await expect(
      fetchSocialBackendJson("/ingest/queue-status", {
        fallbackError: "Failed to fetch queue status",
        retries: 0,
        timeoutMs: 1000,
      }),
    ).rejects.toThrow("TRR_INTERNAL_ADMIN_SHARED_SECRET is not configured");
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("classifies backend 504 with REQUEST_TIMEOUT as BACKEND_REQUEST_TIMEOUT (retryable)", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 504,
      headers: { get: () => null },
      json: async () => ({
        error: "request timed out",
        detail: { code: "REQUEST_TIMEOUT", message: "The request exceeded the maximum allowed duration" },
      }),
    } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    let thrown: unknown;
    try {
      await fetchSeasonBackendJson("show-1", "6", "/analytics", {
        fallbackError: "Failed to fetch social analytics",
        retries: 0,
        timeoutMs: 1000,
      });
    } catch (error) {
      thrown = error;
    }

    expect(thrown).toBeDefined();
    const response = socialProxyErrorResponse(thrown, "[test] backend request timeout");
    const payload = (await response.json()) as {
      error: string;
      code?: string;
      retryable?: boolean;
      trace_id?: string;
      upstream_status?: number;
      upstream_detail?: unknown;
      upstream_detail_code?: string;
    };

    expect(response.status).toBe(504);
    expect(payload.code).toBe("BACKEND_REQUEST_TIMEOUT");
    expect(payload.retryable).toBe(true);
    expect(typeof payload.trace_id).toBe("string");
    expect(payload.upstream_status).toBe(504);
    expect(payload.upstream_detail_code).toBe("REQUEST_TIMEOUT");
  });

  it("logs timeout tier, path, trace id, and cause when AbortError becomes UPSTREAM_TIMEOUT", async () => {
    getBackendApiUrlMock.mockImplementation((path: string) => `http://backend.local/api/v1${path}`);
    const abortError = new Error("signal aborted");
    abortError.name = "AbortError";
    (abortError as Error & { cause?: unknown }).cause = {
      code: "UND_ERR_ABORTED",
      reason: "timeout",
    };
    const fetchMock = vi.fn().mockRejectedValue(abortError);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    let thrown: unknown;
    try {
      await fetchSocialBackendJson("/profiles/instagram/bravodailydish/summary", {
        fallbackError: "Failed to fetch social account profile summary",
        retries: 0,
        timeoutMs: 60_000,
      });
    } catch (error) {
      thrown = error;
    }

    const response = socialProxyErrorResponse(thrown, "[test] upstream timeout");
    const payload = (await response.json()) as { code?: string; trace_id?: string };
    const consoleErrorMock = vi.mocked(console.error);
    const [, logPayload] = consoleErrorMock.mock.calls.at(-1) ?? [];

    expect(response.status).toBe(504);
    expect(payload.code).toBe("UPSTREAM_TIMEOUT");
    expect(logPayload).toEqual(
      expect.objectContaining({
        code: "UPSTREAM_TIMEOUT",
        trace_id: payload.trace_id,
        context: expect.objectContaining({
          backend_path: "/api/v1/admin/socials/profiles/instagram/bravodailydish/summary",
          timeout_ms: 60_000,
          timeout_tier: "long",
          error_cause: expect.objectContaining({
            code: "UND_ERR_ABORTED",
            reason: "timeout",
          }),
        }),
      }),
    );
  });

  it("classifies the catalog progress timeout tier separately", async () => {
    getBackendApiUrlMock.mockImplementation((path: string) => `http://backend.local/api/v1${path}`);
    const abortError = new Error("signal aborted");
    abortError.name = "AbortError";
    const fetchMock = vi.fn().mockRejectedValue(abortError);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    let thrown: unknown;
    try {
      await fetchSocialBackendJson("/profiles/instagram/bravotv/catalog/runs/run-1/progress", {
        fallbackError: "Failed to fetch social account catalog run progress",
        retries: 0,
        timeoutMs: SOCIAL_PROXY_PROGRESS_TIMEOUT_MS,
      });
    } catch (error) {
      thrown = error;
    }

    const response = socialProxyErrorResponse(thrown, "[test] catalog progress timeout");
    const payload = (await response.json()) as { code?: string; trace_id?: string };
    const consoleErrorMock = vi.mocked(console.error);
    const [, logPayload] = consoleErrorMock.mock.calls.at(-1) ?? [];

    expect(response.status).toBe(504);
    expect(payload.code).toBe("UPSTREAM_TIMEOUT");
    expect(logPayload).toEqual(
      expect.objectContaining({
        code: "UPSTREAM_TIMEOUT",
        trace_id: payload.trace_id,
        context: expect.objectContaining({
          backend_path: "/api/v1/admin/socials/profiles/instagram/bravotv/catalog/runs/run-1/progress",
          timeout_ms: 30_000,
          timeout_tier: "progress",
        }),
      }),
    );
  });

  it("maps missing backend configuration to BACKEND_UNREACHABLE", async () => {
    getBackendApiUrlMock.mockReturnValue(null);

    let thrown: unknown;
    try {
      await fetchSocialBackendJson("/ingest/queue-status", {
        fallbackError: "Failed to fetch queue status",
        retries: 0,
        timeoutMs: 1000,
      });
    } catch (error) {
      thrown = error;
    }

    const response = socialProxyErrorResponse(thrown, "[test] backend missing");
    const payload = (await response.json()) as { code?: string; retryable?: boolean };

    expect(response.status).toBe(502);
    expect(payload.code).toBe("BACKEND_UNREACHABLE");
    expect(payload.retryable).toBe(true);
  });

  it("surfaces retry-after metadata for rate-limited upstream responses", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 429,
      headers: { get: (name: string) => (name.toLowerCase() === "retry-after" ? "0" : null) },
      json: async () => ({ error: "rate limited" }),
    } as Response);
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    let thrown: unknown;
    try {
      await fetchSeasonBackendJson("show-1", "6", "/analytics", {
        fallbackError: "Failed to fetch social analytics",
        retries: 0,
        timeoutMs: 1000,
      });
    } catch (error) {
      thrown = error;
    }

    const response = socialProxyErrorResponse(thrown, "[test] rate limited");
    const payload = (await response.json()) as { code?: string; retryable?: boolean; retry_after_seconds?: number };

    expect(response.status).toBe(429);
    expect(payload.code).toBe("UPSTREAM_ERROR");
    expect(payload.retryable).toBe(true);
    expect(payload.retry_after_seconds).toBe(0);
    expect(response.headers.get("retry-after")).toBe("0");
  });

  describe("social profile route factory proxy matrix", () => {
    const routeContext = {
      params: Promise.resolve({ platform: "instagram", handle: "bravo/tv" }),
    };

    beforeEach(() => {
      getBackendApiUrlMock.mockImplementation((path: string) => `http://backend.local/api/v1${path}`);
    });

    it.each([
      {
        name: "GET query forwarding",
        config: {
          endpoint: "posts",
          fallbackError: "Failed to fetch social account profile posts",
          logLabel: "[test] factory posts",
          method: "GET" as const,
          queryString: "forward" as const,
          timeoutMs: 1000,
        },
        request: new NextRequest(
          "http://localhost/api/admin/trr-api/social/profiles/instagram/bravo%2Ftv/posts?limit=2&cursor=a%20b",
        ),
        expectedUrl:
          "http://backend.local/api/v1/admin/socials/profiles/instagram/bravo%2Ftv/posts?limit=2&cursor=a+b",
        expectedMethod: "GET",
        expectedBody: undefined,
      },
      {
        name: "POST body forwarding with stripped refresh query",
        config: {
          endpoint: "comments/scrape",
          fallbackError: "Failed to start social account comments scrape",
          logLabel: "[test] factory comments scrape",
          method: "POST" as const,
          queryString: "strip-refresh" as const,
          headers: { "content-type": "application/json" },
          timeoutMs: 1000,
        },
        request: new NextRequest(
          "http://localhost/api/admin/trr-api/social/profiles/instagram/bravo%2Ftv/comments/scrape?refresh=1&limit=5",
          {
            method: "POST",
            body: JSON.stringify({ mode: "full" }),
          },
        ),
        expectedUrl:
          "http://backend.local/api/v1/admin/socials/profiles/instagram/bravo%2Ftv/comments/scrape?limit=5",
        expectedMethod: "POST",
        expectedBody: JSON.stringify({ mode: "full" }),
      },
    ])("centralizes $name", async ({ config, request, expectedUrl, expectedMethod, expectedBody }) => {
      const fetchMock = vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ ok: true }),
      } as Response);
      vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

      const response = await createSocialProfileProxyRoute(config)(request, routeContext);
      const payload = await response.json();
      const requestInit = fetchMock.mock.calls[0]?.[1] as RequestInit | undefined;

      expect(response.status).toBe(200);
      expect(payload).toEqual({ ok: true });
      expect(fetchMock).toHaveBeenCalledWith(expectedUrl, expect.objectContaining({ method: expectedMethod }));
      expect(requestInit?.body).toBe(expectedBody);
      expect(new Headers(requestInit?.headers).get("Authorization")).toMatch(/^Bearer /);
    });

    it("normalizes upstream errors through the shared error response", async () => {
      const fetchMock = vi.fn().mockResolvedValue({
        ok: false,
        status: 503,
        headers: { get: () => null },
        json: async () => ({ detail: "connection pool exhausted" }),
      } as Response);
      vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

      const response = await createSocialProfileProxyRoute({
        endpoint: "summary",
        fallbackError: "Failed to fetch social account profile summary",
        logLabel: "[test] factory summary",
        queryString: "forward",
        timeoutMs: 1000,
      })(
        new NextRequest("http://localhost/api/admin/trr-api/social/profiles/instagram/bravo%2Ftv/summary"),
        routeContext,
      );
      const payload = (await response.json()) as { code?: string; retryable?: boolean };

      expect(response.status).toBe(503);
      expect(payload.code).toBe("BACKEND_SATURATED");
      expect(payload.retryable).toBe(true);
    });

    it("keeps timeout tier metadata on factory-created routes", async () => {
      const abortError = new Error("signal aborted");
      abortError.name = "AbortError";
      const fetchMock = vi.fn().mockRejectedValue(abortError);
      vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

      const response = await createSocialProfileProxyRoute({
        endpoint: "summary",
        fallbackError: "Failed to fetch social account profile summary",
        logLabel: "[test] factory timeout",
        queryString: "forward",
        timeoutMs: 60_000,
      })(
        new NextRequest("http://localhost/api/admin/trr-api/social/profiles/instagram/bravo%2Ftv/summary"),
        routeContext,
      );
      const payload = (await response.json()) as { code?: string; trace_id?: string };
      const consoleErrorMock = vi.mocked(console.error);
      const [, logPayload] = consoleErrorMock.mock.calls.at(-1) ?? [];

      expect(response.status).toBe(504);
      expect(payload.code).toBe("UPSTREAM_TIMEOUT");
      expect(logPayload).toEqual(
        expect.objectContaining({
          code: "UPSTREAM_TIMEOUT",
          trace_id: payload.trace_id,
          context: expect.objectContaining({
            backend_path: "/api/v1/admin/socials/profiles/instagram/bravo%2Ftv/summary",
            timeout_ms: 60_000,
            timeout_tier: "long",
          }),
        }),
      );
    });

    it("runs optional cache invalidation hooks after successful mutating proxy calls", async () => {
      const invalidateCache = vi.fn();
      const fetchMock = vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ saved: true }),
      } as Response);
      vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

      const response = await createSocialProfileProxyRoute({
        endpoint: "hashtags",
        fallbackError: "Failed to update social account profile hashtags",
        logLabel: "[test] factory hashtag update",
        method: "PUT",
        headers: { "content-type": "application/json" },
        timeoutMs: 45_000,
        invalidateCache,
      })(
        new NextRequest("http://localhost/api/admin/trr-api/social/profiles/instagram/bravo%2Ftv/hashtags", {
          method: "PUT",
          body: JSON.stringify({ hashtags: [] }),
        }),
        routeContext,
      );

      expect(response.status).toBe(200);
      expect(invalidateCache).toHaveBeenCalledWith(
        expect.objectContaining({
          backendPath: "/profiles/instagram/bravo%2Ftv/hashtags",
          data: { saved: true },
          params: { platform: "instagram", handle: "bravo/tv" },
        }),
      );
    });
  });
});
