import { describe, expect, it } from "vitest";

import {
  BRAVOCON_LABEL,
  CANONICAL_SCOPED_SOURCE_ORDER,
  buildPersonGalleryShowOptions,
  buildShowAcronym,
  computePersonGalleryMediaViewAvailability,
  computePersonPhotoShowBuckets,
  getShowDisplayLabel,
  resolvePersonGalleryImportContext,
  resolveGalleryShowFilterFallback,
  isLikelyImdbEpisodeCaption,
  toCanonicalScopedSource,
  WWHL_LABEL,
} from "@/lib/admin/person-gallery-media-view";
import type { TrrPersonPhoto } from "@/lib/server/trr-api/trr-shows-repository";

const makePhoto = (overrides: Partial<TrrPersonPhoto>): TrrPersonPhoto =>
  ({
    id: "photo-1",
    person_id: "person-1",
    source: "tmdb",
    source_image_id: null,
    source_asset_id: null,
    url: "https://example.com/original.jpg",
    hosted_url: "https://cdn.example.com/photo.jpg",
    caption: null,
    width: 1200,
    height: 1600,
    context_section: null,
    context_type: null,
    season: null,
    source_page_url: null,
    people_names: null,
    people_ids: null,
    title_names: null,
    metadata: null,
    fetched_at: null,
    created_at: null,
    origin: "cast_photos",
    link_id: null,
    media_asset_id: null,
    facebank_seed: false,
    thumbnail_focus_x: null,
    thumbnail_focus_y: null,
    thumbnail_zoom: null,
    thumbnail_crop_mode: null,
    ...overrides,
  }) as TrrPersonPhoto;

describe("person gallery media view helpers", () => {
  it("computes WWHL and Other Shows availability from photo buckets", () => {
    const photos = [
      makePhoto({
        id: "this-show",
        metadata: { show_id: "show-1", show_name: "The Real Housewives of Salt Lake City" },
      }),
      makePhoto({
        id: "wwhl",
        caption: "Best moment on #WWHL",
      }),
      makePhoto({
        id: "other",
        metadata: { show_name: "The Real Housewives of Beverly Hills" },
      }),
    ];

    const availability = computePersonGalleryMediaViewAvailability({
      photos,
      showIdForApi: "show-1",
      activeShowName: "The Real Housewives of Salt Lake City",
      activeShowAcronym: buildShowAcronym("The Real Housewives of Salt Lake City"),
      allKnownShowNameMatches: [
        "the real housewives of salt lake city",
        "the real housewives of beverly hills",
      ],
      allKnownShowAcronymMatches: new Set(["TRSL", "RHOBH"]),
      allKnownShowIds: ["show-1"],
      otherShowNameMatches: ["the real housewives of beverly hills"],
      otherShowAcronymMatches: new Set(["RHOBH"]),
    });

    expect(availability.hasWwhlMatches).toBe(true);
    expect(availability.hasOtherShowMatches).toBe(true);
    expect(availability.hasNonThisShowMatches).toBe(true);
  });

  it("builds BravoCon and event dropdown buckets from explicit bucket metadata", () => {
    const availability = computePersonGalleryMediaViewAvailability({
      photos: [
        makePhoto({
          id: "bravocon",
          source: "getty",
          bucket_type: "bravocon",
          bucket_key: "bravocon",
          bucket_label: BRAVOCON_LABEL,
          metadata: {
            bucket_type: "bravocon",
            bucket_key: "bravocon",
            bucket_label: BRAVOCON_LABEL,
          },
        }),
        makePhoto({
          id: "event",
          source: "getty",
          bucket_type: "event",
          bucket_key: "directv-plot-twist-featuring-bravo",
          bucket_label: "DIRECTV Plot Twist Featuring Bravo",
          metadata: {
            bucket_type: "event",
            bucket_key: "directv-plot-twist-featuring-bravo",
            bucket_label: "DIRECTV Plot Twist Featuring Bravo",
            grouped_image_count: 35,
          },
        }),
      ],
      showIdForApi: "show-1",
      activeShowName: "The Real Housewives of Salt Lake City",
      activeShowAcronym: buildShowAcronym("The Real Housewives of Salt Lake City"),
      allKnownShowNameMatches: ["the real housewives of salt lake city"],
      allKnownShowAcronymMatches: new Set(["RHOSLC"]),
      allKnownShowIds: ["show-1"],
      otherShowNameMatches: [],
      otherShowAcronymMatches: new Set(),
    });

    expect(availability.hasBravoconMatches).toBe(true);
    expect(availability.eventSubcategoryOptions).toEqual([
      {
        key: "reality_tv_bravo_franchise",
        label: "Reality TV / Bravo / Franchise Event",
      },
    ]);
    expect(availability.eventOptions).toEqual([
      {
        key: "directv-plot-twist-featuring-bravo",
        label: "DIRECTV Plot Twist Featuring Bravo",
        count: 35,
      },
    ]);
  });

  it("builds Real Housewives acronyms with franchise-aware shortcodes", () => {
    expect(buildShowAcronym("The Real Housewives of Salt Lake City")).toBe("RHOSLC");
    expect(buildShowAcronym("The Real Housewives of Beverly Hills")).toBe("RHOBH");
    expect(getShowDisplayLabel("The Real Housewives of Salt Lake City")).toBe("RHOSLC");
  });

  it("dedupes duplicate show buckets and keeps only photo-backed show tabs", () => {
    const options = buildPersonGalleryShowOptions([
      makePhoto({
        id: "rhoslc-1",
        bucket_type: "show",
        resolved_show_id: "show-rhoslc",
        resolved_show_name: "The Real Housewives of Salt Lake City",
      }),
      makePhoto({
        id: "rhoslc-2",
        bucket_type: "show",
        resolved_show_id: null,
        resolved_show_name: "The Real Housewives of Salt Lake City (RHOSLC)",
      }),
      makePhoto({
        id: "wwhl",
        bucket_type: "show",
        resolved_show_id: "show-wwhl",
        resolved_show_name: "Watch What Happens Live with Andy Cohen",
      }),
    ]);

    expect(options).toEqual([
      {
        key: "id:show-rhoslc",
        showId: "show-rhoslc",
        showName: "The Real Housewives of Salt Lake City (RHOSLC)",
        acronym: "RHOSLC",
      },
    ]);
  });

  it("recovers show tabs from resolved show metadata when legacy rows are missing bucket_type", () => {
    const options = buildPersonGalleryShowOptions([
      makePhoto({
        id: "legacy-rhoslc",
        bucket_type: null,
        bucket_key: null,
        bucket_label: null,
        resolved_show_id: "show-rhoslc",
        resolved_show_name: "The Real Housewives of Salt Lake City",
      }),
    ]);

    expect(options).toEqual([
      {
        key: "id:show-rhoslc",
        showId: "show-rhoslc",
        showName: "The Real Housewives of Salt Lake City",
        acronym: "RHOSLC",
      },
    ]);
  });

  it("keeps the highest grouped event count per event bucket", () => {
    const availability = computePersonGalleryMediaViewAvailability({
      photos: [
        makePhoto({
          id: "event-1",
          source: "getty",
          bucket_type: "event",
          bucket_key: "watch-what-happens-live-15th-anniversary-special",
          bucket_label: "Watch What Happens Live 15th Anniversary Special",
          metadata: {
            bucket_type: "event",
            bucket_key: "watch-what-happens-live-15th-anniversary-special",
            bucket_label: "Watch What Happens Live 15th Anniversary Special",
            grouped_image_count: 12,
          },
        }),
        makePhoto({
          id: "event-2",
          source: "getty",
          bucket_type: "event",
          bucket_key: "watch-what-happens-live-15th-anniversary-special",
          bucket_label: "Watch What Happens Live 15th Anniversary Special",
          metadata: {
            bucket_type: "event",
            bucket_key: "watch-what-happens-live-15th-anniversary-special",
            bucket_label: "Watch What Happens Live 15th Anniversary Special",
            grouped_image_count: 18,
          },
        }),
      ],
      showIdForApi: "show-1",
      activeShowName: "The Real Housewives of Salt Lake City",
      activeShowAcronym: buildShowAcronym("The Real Housewives of Salt Lake City"),
      allKnownShowNameMatches: ["the real housewives of salt lake city"],
      allKnownShowAcronymMatches: new Set(["RHOSLC"]),
      allKnownShowIds: ["show-1"],
      otherShowNameMatches: [],
      otherShowAcronymMatches: new Set(),
    });

    expect(availability.eventOptions).toEqual([
      {
        key: "watch-what-happens-live-15th-anniversary-special",
        label: "Watch What Happens Live 15th Anniversary Special",
        count: 18,
      },
    ]);
  });

  it("hides event buckets unless grouped image count is greater than one", () => {
    const availability = computePersonGalleryMediaViewAvailability({
      photos: [
        makePhoto({
          id: "event-1",
          source: "getty",
          bucket_type: "event",
          bucket_key: "single-image-event",
          bucket_label: "Single Image Event",
          metadata: {
            bucket_type: "event",
            bucket_key: "single-image-event",
            bucket_label: "Single Image Event",
            grouped_image_count: 1,
          },
        }),
        makePhoto({
          id: "event-2",
          source: "getty",
          bucket_type: "event",
          bucket_key: "multi-image-event",
          bucket_label: "Multi Image Event",
          metadata: {
            bucket_type: "event",
            bucket_key: "multi-image-event",
            bucket_label: "Multi Image Event",
            grouped_image_count: 3,
          },
        }),
      ],
      showIdForApi: "show-1",
      activeShowName: "The Real Housewives of Salt Lake City",
      activeShowAcronym: buildShowAcronym("The Real Housewives of Salt Lake City"),
      allKnownShowNameMatches: ["the real housewives of salt lake city"],
      allKnownShowAcronymMatches: new Set(["RHOSLC"]),
      allKnownShowIds: ["show-1"],
      otherShowNameMatches: [],
      otherShowAcronymMatches: new Set(),
    });

    expect(availability.hasEventMatches).toBe(true);
    expect(availability.eventOptions).toEqual([
      {
        key: "multi-image-event",
        label: "Multi Image Event",
        count: 3,
      },
    ]);
  });

  it("matches selected other show by show_id", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        id: "selected-other",
        metadata: { show_id: "show-2", show_name: "Below Deck" },
      }),
      showIdForApi: "show-1",
      activeShowName: "The Real Housewives of Salt Lake City",
      activeShowAcronym: buildShowAcronym("The Real Housewives of Salt Lake City"),
      allKnownShowNameMatches: ["the real housewives of salt lake city", "below deck"],
      allKnownShowAcronymMatches: new Set(["TR", "BD"]),
      allKnownShowIds: ["show-1", "show-2"],
      otherShowNameMatches: ["below deck"],
      otherShowAcronymMatches: new Set(["BD"]),
      selectedOtherShow: {
        showId: "show-2",
        showName: "Below Deck",
        acronym: "BD",
      },
    });

    expect(buckets.matchesSelectedOtherShow).toBe(true);
  });

  it("resolves import context for selected other show", () => {
    expect(
      resolvePersonGalleryImportContext({
        galleryShowFilter: "other-shows",
        routeShow: {
          showId: "show-1",
          showName: "The Real Housewives of Salt Lake City",
          label: "The Real Housewives of Salt Lake City",
        },
        selectedOtherShow: {
          showId: "show-2",
          showName: "Below Deck",
        },
        wwhlShow: {
          showId: "show-wwhl",
          showName: "Watch What Happens Live with Andy Cohen",
        },
      }),
    ).toEqual({
      showId: "show-2",
      showName: "Below Deck",
      label: "Below Deck",
    });
  });

  it("resolves WWHL import context from WWHL credit", () => {
    expect(
      resolvePersonGalleryImportContext({
        galleryShowFilter: "wwhl",
        routeShow: null,
        selectedOtherShow: null,
        wwhlShow: {
          showId: "show-wwhl",
          showName: "Watch What Happens Live with Andy Cohen",
        },
      }),
    ).toEqual({
      showId: "show-wwhl",
      showName: "Watch What Happens Live with Andy Cohen",
      label: WWHL_LABEL,
    });
  });

  it("uses route-show import context only for explicit this-show runs", () => {
    expect(
      resolvePersonGalleryImportContext({
        galleryShowFilter: "this-show",
        routeShow: {
          showId: "show-1",
          showName: "The Real Housewives of Salt Lake City",
          label: "The Real Housewives of Salt Lake City",
        },
        selectedOtherShow: {
          showId: "show-2",
          showName: "Below Deck",
        },
        wwhlShow: {
          showId: "show-wwhl",
          showName: "Watch What Happens Live with Andy Cohen",
        },
      }),
    ).toEqual({
      showId: "show-1",
      showName: "The Real Housewives of Salt Lake City",
      label: "The Real Housewives of Salt Lake City",
    });
  });

  it("omits import context for all-filter gallery runs", () => {
    expect(
      resolvePersonGalleryImportContext({
        galleryShowFilter: "all",
        routeShow: {
          showId: "show-1",
          showName: "The Real Housewives of Salt Lake City",
          label: "The Real Housewives of Salt Lake City",
        },
        selectedOtherShow: {
          showId: "show-2",
          showName: "Below Deck",
        },
        wwhlShow: {
          showId: "show-wwhl",
          showName: "Watch What Happens Live with Andy Cohen",
        },
      }),
    ).toEqual({
      showId: null,
      showName: null,
      label: null,
    });
  });

  it("omits import context when no route or override show exists", () => {
    expect(
      resolvePersonGalleryImportContext({
        galleryShowFilter: "all",
        routeShow: null,
        selectedOtherShow: null,
        wwhlShow: null,
      }),
    ).toEqual({
      showId: null,
      showName: null,
      label: null,
    });
  });

  it("includes Getty and NBCUMV in canonical scoped source normalization", () => {
    expect(toCanonicalScopedSource("getty")).toBe("getty");
    expect(toCanonicalScopedSource("nbcumv")).toBe("nbcumv");
    expect(CANONICAL_SCOPED_SOURCE_ORDER).toContain("getty");
    expect(CANONICAL_SCOPED_SOURCE_ORDER).toContain("nbcumv");
  });

  it("falls back to this-show when selected filter is unavailable", () => {
    const fallback = resolveGalleryShowFilterFallback({
      currentFilter: "wwhl",
      showContextEnabled: true,
      hasWwhlMatches: false,
      hasBravoconMatches: false,
      hasEventMatches: false,
      hasOtherShowMatches: true,
      hasUnknownShowMatches: false,
      hasSelectedOtherShowMatches: true,
      hasNonThisShowMatches: true,
      canSelectWwhlWithoutMatches: false,
      canSelectOtherShowWithoutMatches: false,
    });
    expect(fallback).toBe("this-show");
  });

  it("keeps WWHL selected with zero matches when credit-eligible", () => {
    const fallback = resolveGalleryShowFilterFallback({
      currentFilter: "wwhl",
      showContextEnabled: true,
      hasWwhlMatches: false,
      hasBravoconMatches: false,
      hasEventMatches: false,
      hasOtherShowMatches: true,
      hasUnknownShowMatches: false,
      hasSelectedOtherShowMatches: true,
      hasNonThisShowMatches: true,
      canSelectWwhlWithoutMatches: true,
      canSelectOtherShowWithoutMatches: false,
    });
    expect(fallback).toBe("wwhl");
  });

  it("keeps selected other-show filter with zero matches when credit-eligible", () => {
    const fallback = resolveGalleryShowFilterFallback({
      currentFilter: "other-shows",
      showContextEnabled: true,
      hasWwhlMatches: true,
      hasBravoconMatches: false,
      hasEventMatches: false,
      hasOtherShowMatches: false,
      hasUnknownShowMatches: false,
      hasSelectedOtherShowMatches: false,
      hasNonThisShowMatches: true,
      canSelectWwhlWithoutMatches: false,
      canSelectOtherShowWithoutMatches: true,
    });
    expect(fallback).toBe("other-shows");
  });

  it("falls back from unsorted when there are no unsorted matches", () => {
    const fallback = resolveGalleryShowFilterFallback({
      currentFilter: "unsorted",
      showContextEnabled: false,
      hasWwhlMatches: false,
      hasBravoconMatches: false,
      hasEventMatches: true,
      hasOtherShowMatches: true,
      hasUnknownShowMatches: false,
      hasSelectedOtherShowMatches: false,
      hasNonThisShowMatches: true,
    });
    expect(fallback).toBe("all");
  });

  it("does not classify movie captions as episode captions", () => {
    expect(
      isLikelyImdbEpisodeCaption(
        "Alan Cumming in Reefer Madness: The Movie Musical (2005)"
      )
    ).toBe(false);
  });

  it("classifies explicit IMDb episode-style captions", () => {
    expect(isLikelyImdbEpisodeCaption("Episode 4 (2020)")).toBe(true);
    expect(isLikelyImdbEpisodeCaption("The Hills #5.12")).toBe(false);
    expect(isLikelyImdbEpisodeCaption("Season 3 Episode 12 (2015)")).toBe(true);
    expect(isLikelyImdbEpisodeCaption("S01E12 (2018)")).toBe(true);
    expect(isLikelyImdbEpisodeCaption("No year text")).toBe(false);
  });

  it("does not treat movie-style caption as current-show match", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Alan Cumming in Reefer Madness: The Movie Musical (2005)",
        metadata: {
          show_id: "legacy-show-id",
          show_name: "The Show No One Actually Wants",
        },
      }),
      showIdForApi: "the-traitors-show-id",
      activeShowName: "The Traitors",
      activeShowAcronym: "TR",
      allKnownShowNameMatches: ["the traitors", "other show"],
      allKnownShowAcronymMatches: new Set(["TR", "OS"]),
      allKnownShowIds: ["the-traitors-show-id", "legacy-show-id"],
      otherShowNameMatches: ["other show"],
      otherShowAcronymMatches: new Set(["OS"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(false);
    expect(buckets.matchesOtherShows).toBe(false);
    expect(buckets.matchesUnknownShows).toBe(true);
  });

  it("does not treat IMDb episode-style captions as current-show match without explicit show context", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Season 3 Episode 12 (2015)",
      }),
      showIdForApi: "the-traitors-show-id",
      activeShowName: "The Traitors",
      activeShowAcronym: "TR",
      allKnownShowNameMatches: ["the traitors"],
      allKnownShowAcronymMatches: new Set(["TR"]),
      allKnownShowIds: ["the-traitors-show-id"],
      otherShowNameMatches: ["other show"],
      otherShowAcronymMatches: new Set(["OS"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(false);
    expect(buckets.matchesOtherShows).toBe(false);
    expect(buckets.matchesUnknownShows).toBe(true);
  });

  it("classifies episode-style caption without show metadata as unknown show", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Season 3 Episode 12 (2015)",
      }),
      showIdForApi: "the-traitors-show-id",
      activeShowName: "The Traitors",
      activeShowAcronym: "TR",
      allKnownShowNameMatches: [],
      allKnownShowAcronymMatches: new Set(),
      allKnownShowIds: ["the-traitors-show-id"],
      otherShowNameMatches: ["other show"],
      otherShowAcronymMatches: new Set(["OS"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(false);
    expect(buckets.matchesOtherShows).toBe(false);
    expect(buckets.matchesUnknownShows).toBe(true);
  });

  it("classifies non-context, non-matching photos as unknown show", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "A scene with no identifiable show context",
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "TR",
      allKnownShowNameMatches: ["the traitors", "other known show"],
      allKnownShowAcronymMatches: new Set(["TR", "OKS"]),
      allKnownShowIds: ["show-traitors"],
      otherShowNameMatches: ["other known show"],
      otherShowAcronymMatches: new Set(["OKS"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(false);
    expect(buckets.matchesOtherShows).toBe(false);
    expect(buckets.matchesUnknownShows).toBe(true);
  });

  it("does not classify IMDb movie-title evidence as current show when scoped show_id is incorrect", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Alan Cumming in 007: The Return (1995)",
        title_names: ["007: The Return"],
        metadata: {
          show_id: "show-traitors",
          show_name: "The Traitors",
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "T",
      allKnownShowNameMatches: ["the traitors", "watch what happens live"],
      allKnownShowAcronymMatches: new Set(["T", "WWHL"]),
      allKnownShowIds: ["show-traitors", "show-wwhl"],
      otherShowNameMatches: ["watch what happens live"],
      otherShowAcronymMatches: new Set(["WWHL"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(false);
    expect(buckets.matchesOtherShows).toBe(false);
    expect(buckets.matchesUnknownShows).toBe(true);
  });

  it("routes IMDb WWHL episode-title rows to WWHL instead of this-show", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Alan Cumming and Milo Ventimiglia in Milo Ventimiglia & Alan Cumming (2023)",
        title_names: ["Milo Ventimiglia & Alan Cumming"],
        metadata: {
          episode_title: "Milo Ventimiglia & Alan Cumming",
          show_name: "Watch What Happens Live with Andy Cohen",
          show_id: "show-wwhl",
          show_context_source: "imdb_title_fallback",
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "T",
      allKnownShowNameMatches: ["the traitors", "watch what happens live with andy cohen"],
      allKnownShowAcronymMatches: new Set(["T", "WWHL"]),
      allKnownShowIds: ["show-traitors", "show-wwhl"],
      otherShowNameMatches: ["watch what happens live with andy cohen"],
      otherShowAcronymMatches: new Set(["WWHL"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(false);
    expect(buckets.matchesWwhl).toBe(true);
  });

  it("routes IMDb event rows to events bucket", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Alan Cumming at The 77th Primetime Emmy Awards",
        metadata: {
          imdb_image_type: "event",
          content_type: "EVENT",
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "T",
      allKnownShowNameMatches: ["the traitors"],
      allKnownShowAcronymMatches: new Set(["T"]),
      allKnownShowIds: ["show-traitors"],
      otherShowNameMatches: [],
      otherShowAcronymMatches: new Set(),
      selectedOtherShow: null,
    });

    expect(buckets.matchesEvents).toBe(true);
    expect(buckets.matchesUnknownShows).toBe(false);
  });

  it("routes event rows tagged as other shows out of generic events", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "getty",
        bucket_type: "event",
        bucket_key: "big-brother-finale-party",
        bucket_label: "Big Brother Finale Party",
        metadata: {
          bucket_type: "event",
          bucket_key: "big-brother-finale-party",
          bucket_label: "Big Brother Finale Party",
          grouped_image_count: 4,
          event_subcategory_keys: ["other_shows"],
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "T",
      allKnownShowNameMatches: ["the traitors"],
      allKnownShowAcronymMatches: new Set(["T"]),
      allKnownShowIds: ["show-traitors"],
      otherShowNameMatches: [],
      otherShowAcronymMatches: new Set(),
      selectedOtherShow: null,
    });

    expect(buckets.matchesEvents).toBe(false);
    expect(buckets.matchesOtherShows).toBe(true);
  });

  it("routes event rows tagged as unsorted into the unsorted bucket", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "getty",
        bucket_type: "event",
        bucket_key: "mystery-event",
        bucket_label: "Mystery Event",
        metadata: {
          bucket_type: "event",
          bucket_key: "mystery-event",
          bucket_label: "Mystery Event",
          grouped_image_count: 3,
          event_subcategory_keys: ["unsorted"],
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "T",
      allKnownShowNameMatches: ["the traitors"],
      allKnownShowAcronymMatches: new Set(["T"]),
      allKnownShowIds: ["show-traitors"],
      otherShowNameMatches: [],
      otherShowAcronymMatches: new Set(),
      selectedOtherShow: null,
    });

    expect(buckets.matchesEvents).toBe(false);
    expect(buckets.matchesUnknownShows).toBe(true);
  });

  it("keeps explicit Getty event buckets in Events even when the event title mentions the active show", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "getty",
        bucket_type: "event",
        bucket_key: "rhobh-season-5-premiere-party",
        bucket_label: 'Bravo\'s "The Real Housewives of Beverly Hills" Season 5 Premiere Party',
        resolved_show_name: null,
        metadata: {
          bucket_type: "event",
          bucket_key: "rhobh-season-5-premiere-party",
          bucket_label: 'Bravo\'s "The Real Housewives of Beverly Hills" Season 5 Premiere Party',
          grouped_image_count: 18,
          event_subcategory_keys: ["reality_tv_bravo_franchise"],
          show_name: "The Real Housewives of Beverly Hills",
        },
      }),
      showIdForApi: "show-rhobh",
      activeShowName: "The Real Housewives of Beverly Hills",
      activeShowAcronym: "RHOBH",
      allKnownShowNameMatches: ["the real housewives of beverly hills"],
      allKnownShowAcronymMatches: new Set(["RHOBH"]),
      allKnownShowIds: ["show-rhobh"],
      otherShowNameMatches: [],
      otherShowAcronymMatches: new Set(),
      selectedOtherShow: null,
    });

    expect(buckets.matchesEvents).toBe(true);
    expect(buckets.matchesThisShow).toBe(false);
    expect(buckets.eventBucketKey).toBe("rhobh-season-5-premiere-party");
  });

  it("prioritizes explicit Getty/NBCUMV bucket metadata over caption heuristics", () => {
    const showBuckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "getty",
        bucket_type: "show",
        bucket_key: "show-rhoslc",
        bucket_label: "The Real Housewives of Salt Lake City",
        resolved_show_id: "show-rhoslc",
        resolved_show_name: "The Real Housewives of Salt Lake City",
        metadata: {
          bucket_type: "show",
          resolved_show_id: "show-rhoslc",
          resolved_show_name: "The Real Housewives of Salt Lake City",
        },
        caption: 'Reunion -- Pictured: Mary Cosby',
      }),
      showIdForApi: "show-rhoslc",
      activeShowName: "The Real Housewives of Salt Lake City",
      activeShowAcronym: "RHOSLC",
      allKnownShowNameMatches: ["the real housewives of salt lake city"],
      allKnownShowAcronymMatches: new Set(["RHOSLC"]),
      allKnownShowIds: ["show-rhoslc"],
      otherShowNameMatches: [],
      otherShowAcronymMatches: new Set(),
      selectedOtherShow: null,
    });

    expect(showBuckets.matchesThisShow).toBe(true);
    expect(showBuckets.matchesEvents).toBe(false);

    const bravoconBuckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "getty",
        bucket_type: "bravocon",
        bucket_key: "bravocon",
        bucket_label: BRAVOCON_LABEL,
        metadata: {
          bucket_type: "bravocon",
          bucket_key: "bravocon",
          bucket_label: BRAVOCON_LABEL,
        },
        caption: "BravoCon Live with Andy Cohen Presents: The Bravos",
      }),
      showIdForApi: "show-rhoslc",
      activeShowName: "The Real Housewives of Salt Lake City",
      activeShowAcronym: "RHOSLC",
      allKnownShowNameMatches: ["the real housewives of salt lake city"],
      allKnownShowAcronymMatches: new Set(["RHOSLC"]),
      allKnownShowIds: ["show-rhoslc"],
      otherShowNameMatches: [],
      otherShowAcronymMatches: new Set(),
      selectedOtherShow: null,
    });

    expect(bravoconBuckets.matchesBravocon).toBe(true);
    expect(bravoconBuckets.matchesThisShow).toBe(false);
  });

  it("routes unresolved IMDb episode rows to WWHL via imdb_fallback_show_name", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Alan Cumming and Milo Ventimiglia in Milo Ventimiglia & Alan Cumming (2023)",
        title_names: ["Milo Ventimiglia & Alan Cumming"],
        metadata: {
          show_context_source: "imdb_episode_unresolved",
          imdb_fallback_show_name: "Watch What Happens Live with Andy Cohen",
          episode_title: "Milo Ventimiglia & Alan Cumming",
          imdb_title_type: "TVEpisode",
          imdb_image_type: "still_frame",
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "T",
      allKnownShowNameMatches: ["the traitors", "watch what happens live with andy cohen"],
      allKnownShowAcronymMatches: new Set(["T", "WWHL"]),
      allKnownShowIds: ["show-traitors", "show-wwhl"],
      otherShowNameMatches: ["watch what happens live with andy cohen"],
      otherShowAcronymMatches: new Set(["WWHL"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(false);
    expect(buckets.matchesWwhl).toBe(true);
    expect(buckets.matchesUnknownShows).toBe(false);
  });

  it("routes trusted IMDb fallback rows to WWHL when show_name is blank", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Alan Cumming and Milo Ventimiglia in Milo Ventimiglia & Alan Cumming (2023)",
        title_names: ["Milo Ventimiglia & Alan Cumming"],
        metadata: {
          show_context_source: "imdb_title_fallback",
          show_name: null,
          imdb_fallback_show_name: "Watch What Happens Live with Andy Cohen",
          episode_title: "Milo Ventimiglia & Alan Cumming",
          imdb_title_type: "TVEpisode",
          imdb_image_type: "still_frame",
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "T",
      allKnownShowNameMatches: ["the traitors", "watch what happens live with andy cohen"],
      allKnownShowAcronymMatches: new Set(["T", "WWHL"]),
      allKnownShowIds: ["show-traitors", "show-wwhl"],
      otherShowNameMatches: ["watch what happens live with andy cohen"],
      otherShowAcronymMatches: new Set(["WWHL"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(false);
    expect(buckets.matchesWwhl).toBe(true);
    expect(buckets.matchesUnknownShows).toBe(false);
  });

  it("routes IMDb rows to WWHL when fallback show name is present even without episode evidence", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Alan Cumming on a talk show",
        title_names: ["Alan Cumming"],
        metadata: {
          show_context_source: "request_context",
          imdb_fallback_show_name: "Watch What Happens Live with Andy Cohen",
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "T",
      allKnownShowNameMatches: ["the traitors", "watch what happens live with andy cohen"],
      allKnownShowAcronymMatches: new Set(["T", "WWHL"]),
      allKnownShowIds: ["show-traitors", "show-wwhl"],
      otherShowNameMatches: ["watch what happens live with andy cohen"],
      otherShowAcronymMatches: new Set(["WWHL"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(false);
    expect(buckets.matchesWwhl).toBe(true);
  });

  it("keeps trusted IMDb episode metadata in this-show bucket when show text is absent", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Titles: The Game Is Afoot",
        title_names: ["The Game Is Afoot"],
        metadata: {
          episode_title: "The Game Is Afoot",
          show_id: "show-traitors",
          show_name: "The Traitors",
          show_context_source: "episode_table",
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "T",
      allKnownShowNameMatches: ["the traitors", "watch what happens live with andy cohen"],
      allKnownShowAcronymMatches: new Set(["T", "WWHL"]),
      allKnownShowIds: ["show-traitors", "show-wwhl"],
      otherShowNameMatches: ["watch what happens live with andy cohen"],
      otherShowAcronymMatches: new Set(["WWHL"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(true);
    expect(buckets.matchesWwhl).toBe(false);
  });

  it("treats request-context inferred IMDb metadata as trusted for this-show", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Alan Cumming in The Power of the Seer (2025)",
        title_names: ["The Power of the Seer"],
        metadata: {
          episode_title: "The Power of the Seer",
          show_id: "show-traitors",
          show_name: "The Traitors",
          show_context_source: "request_context_inferred",
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "T",
      allKnownShowNameMatches: ["the traitors", "watch what happens live with andy cohen"],
      allKnownShowAcronymMatches: new Set(["T", "WWHL"]),
      allKnownShowIds: ["show-traitors", "show-wwhl"],
      otherShowNameMatches: ["watch what happens live with andy cohen"],
      otherShowAcronymMatches: new Set(["WWHL"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(true);
    expect(buckets.matchesUnknownShows).toBe(false);
  });

  it("does not trust request-context inferred IMDb metadata without corroborating show name", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Alan Cumming in The Power of the Seer (2025)",
        title_names: ["The Power of the Seer"],
        metadata: {
          episode_title: "The Power of the Seer",
          show_id: "show-traitors",
          show_name: "Different Show",
          show_context_source: "request_context_inferred",
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "T",
      allKnownShowNameMatches: ["the traitors", "watch what happens live with andy cohen"],
      allKnownShowAcronymMatches: new Set(["T", "WWHL"]),
      allKnownShowIds: ["show-traitors", "show-wwhl"],
      otherShowNameMatches: ["watch what happens live with andy cohen"],
      otherShowAcronymMatches: new Set(["WWHL"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(false);
    expect(buckets.matchesUnknownShows).toBe(true);
  });

  it("uses imdb_fallback_show_name for episode-evidenced IMDb rows in this-show bucket", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Revenge Is a Dish Best Served Cold (2025)",
        title_names: ["Revenge Is a Dish Best Served Cold"],
        metadata: {
          show_context_source: "imdb_episode_unresolved",
          imdb_fallback_show_name: "The Traitors",
          episode_title: "Revenge Is a Dish Best Served Cold",
          season_number: 3,
          episode_number: 2,
          imdb_image_type: "still_frame",
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors (US)",
      activeShowAcronym: "TT",
      allKnownShowNameMatches: ["the traitors", "watch what happens live with andy cohen"],
      allKnownShowAcronymMatches: new Set(["TT", "WWHL"]),
      allKnownShowIds: ["show-traitors", "show-wwhl"],
      otherShowNameMatches: ["watch what happens live with andy cohen"],
      otherShowAcronymMatches: new Set(["WWHL"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(true);
    expect(buckets.matchesUnknownShows).toBe(false);
  });

  it("matches selected other-show pill by normalized show name variants", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Episode Still (2025)",
        metadata: {
          show_context_source: "imdb_episode_unresolved",
          imdb_fallback_show_name: "The Traitors",
          episode_title: "Episode Still",
          imdb_title_type: "TVEPISODE",
        },
      }),
      showIdForApi: "show-rhobh",
      activeShowName: "The Real Housewives of Beverly Hills",
      activeShowAcronym: "RHOBH",
      allKnownShowNameMatches: ["the real housewives of beverly hills", "the traitors (us)"],
      allKnownShowAcronymMatches: new Set(["RHOBH", "TTUS"]),
      allKnownShowIds: ["show-rhobh"],
      otherShowNameMatches: ["the traitors (us)"],
      otherShowAcronymMatches: new Set(["TTUS"]),
      selectedOtherShow: {
        showId: null,
        showName: "The Traitors (US)",
        acronym: "TTUS",
      },
    });

    expect(buckets.matchesSelectedOtherShow).toBe(true);
    expect(buckets.matchesOtherShows).toBe(true);
  });

  it("keeps request_context IMDb metadata untrusted without corroborating text/acronym evidence", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Episode 2 (2025)",
        metadata: {
          show_context_source: "request_context",
          show_name: "The Traitors",
          episode_title: "Revenge Is a Dish Best Served Cold",
          season_number: 3,
          episode_number: 2,
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "TT",
      allKnownShowNameMatches: ["the traitors"],
      allKnownShowAcronymMatches: new Set(["TT"]),
      allKnownShowIds: ["show-traitors"],
      otherShowNameMatches: [],
      otherShowAcronymMatches: new Set(),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(false);
    expect(buckets.matchesUnknownShows).toBe(true);
  });

  it("prioritizes IMDb episode evidence over mismatched request-context show tags for Traitors", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Episode 2 (2025)",
        metadata: {
          show_context_source: "request_context",
          show_name: "Wrong Show",
          imdb_fallback_show_name: "The Traitors",
          episode_title: "Revenge Is a Dish Best Served Cold",
          season_number: 3,
          episode_number: 2,
          imdb_title_type: "TVEpisode",
          imdb_image_type: "still_frame",
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "TT",
      allKnownShowNameMatches: ["the traitors", "wrong show"],
      allKnownShowAcronymMatches: new Set(["TT", "WS"]),
      allKnownShowIds: ["show-traitors"],
      otherShowNameMatches: ["wrong show"],
      otherShowAcronymMatches: new Set(["WS"]),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(true);
    expect(buckets.matchesUnknownShows).toBe(false);
  });

  it("treats request_context_rejected IMDb metadata as explicitly untrusted", () => {
    const buckets = computePersonPhotoShowBuckets({
      photo: makePhoto({
        source: "imdb",
        caption: "Alan Cumming in The Power of the Seer (2025)",
        metadata: {
          show_context_source: "request_context_rejected",
          show_name: "The Traitors",
          imdb_fallback_show_name: "The Traitors",
          episode_title: "The Power of the Seer",
          season_number: 3,
          episode_number: 2,
          imdb_title_type: "TVEpisode",
        },
      }),
      showIdForApi: "show-traitors",
      activeShowName: "The Traitors",
      activeShowAcronym: "TT",
      allKnownShowNameMatches: ["the traitors"],
      allKnownShowAcronymMatches: new Set(["TT"]),
      allKnownShowIds: ["show-traitors"],
      otherShowNameMatches: [],
      otherShowAcronymMatches: new Set(),
      selectedOtherShow: null,
    });

    expect(buckets.matchesThisShow).toBe(false);
  });
});
