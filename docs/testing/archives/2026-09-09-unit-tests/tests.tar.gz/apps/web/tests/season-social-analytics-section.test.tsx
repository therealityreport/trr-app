import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import "@testing-library/jest-dom/vitest";

import SeasonSocialAnalyticsSection, {
  buildPreviewPlatformStatuses,
  buildRunsRequestKey,
  buildSocialRequestKey,
  formatIngestErrorMessage,
  formatJobOutcomeNote,
  shouldSetPollingRetry,
} from "../src/components/admin/season-social-analytics-section";
import ShowSocialTab from "../src/components/admin/show-tabs/ShowSocialTab";
import { auth } from "../src/lib/firebase";

vi.mock("@/components/admin/social-posts-section", () => ({
  __esModule: true,
  default: () => <div data-testid="social-posts-section" />,
}));

vi.mock("@/components/admin/reddit-sources-manager", () => ({
  __esModule: true,
  default: () => <div data-testid="reddit-sources-manager" />,
}));

const { routerReplaceMock } = vi.hoisted(() => ({
  routerReplaceMock: vi.fn((href: string) => {
    window.history.replaceState({}, "", href);
  }),
}));

vi.mock("next/navigation", () => ({
  useRouter: () => ({
    replace: routerReplaceMock,
  }),
  usePathname: () => window.location.pathname,
  useSearchParams: () => new URLSearchParams(window.location.search),
}));

type AnalyticsPayload = {
  window: {
    start: string;
    end: string;
    timezone: string;
    week_zero_start?: string;
    week?: number | null;
    source_scope?: string;
  };
  summary: {
    show_id: string;
    season_id: string;
    season_number: number;
    show_name: string | null;
    total_posts: number;
    total_comments: number;
    total_engagement: number;
    sentiment_mix: {
      positive: number;
      neutral: number;
      negative: number;
      counts: {
        positive: number;
        neutral: number;
        negative: number;
      };
    };
    data_quality?: {
      comments_saved_pct_overall: number | null;
      platform_comments_saved_pct: {
        instagram: number | null;
        youtube: number | null;
        tiktok: number | null;
        twitter: number | null;
      };
      youtube_content_breakdown?: {
        videos_count: number;
        reels_count: number;
        total_count: number;
      };
      last_post_at: string | null;
      last_comment_at: string | null;
      data_freshness_minutes: number | null;
    };
  };
  weekly: Array<{
    week_index: number;
    label: string;
    start: string;
    end: string;
    week_type?: "preseason" | "episode" | "bye" | "postseason";
    episode_number?: number | null;
    post_volume: number;
    comment_volume: number;
    engagement: number;
    sentiment: {
      positive: number;
      neutral: number;
      negative: number;
    };
  }>;
  weekly_platform_posts: Array<{
    week_index: number;
    label: string;
    start: string;
    end: string;
    week_type?: "preseason" | "episode" | "bye" | "postseason";
    episode_number?: number | null;
    posts: {
      instagram: number;
      youtube: number;
      tiktok: number;
      twitter: number;
    };
    comments: {
      instagram: number;
      youtube: number;
      tiktok: number;
      twitter: number;
    };
    reported_comments?: {
      instagram: number;
      youtube: number;
      tiktok: number;
      twitter: number;
    };
    total_posts: number;
    total_comments: number;
    total_reported_comments?: number;
    comments_saved_pct?: number | null;
  }>;
  weekly_platform_engagement: Array<{
    week_index: number;
    label: string;
    start: string;
    end: string;
    engagement: {
      instagram: number;
      youtube: number;
      tiktok: number;
      twitter: number;
    };
    total_engagement: number;
    has_data: boolean;
  }>;
  weekly_daily_activity: Array<{
    week_index: number;
    label: string;
    start: string;
    end: string;
    week_type?: "preseason" | "episode" | "bye" | "postseason";
    episode_number?: number | null;
    days: Array<{
      day_index: number;
      date_local: string;
      posts: {
        instagram: number;
        youtube: number;
        tiktok: number;
        twitter: number;
      };
      comments: {
        instagram: number;
        youtube: number;
        tiktok: number;
        twitter: number;
      };
      reported_comments?: {
        instagram: number;
        youtube: number;
        tiktok: number;
        twitter: number;
      };
      total_posts: number;
      total_comments: number;
      total_reported_comments?: number;
    }>;
  }>;
  weekly_flags?: Array<{
    week_index: number;
    code: "zero_activity" | "spike" | "drop" | "comment_gap";
    severity: "info" | "warn";
    message: string;
  }>;
  benchmark?: {
    week_index: number;
    current: {
      posts: number;
      comments: number;
      engagement: number;
    };
    previous_week: {
      week_index: number | null;
      metrics: {
        posts: number;
        comments: number;
        engagement: number;
      };
      delta_pct: {
        posts: number | null;
        comments: number | null;
        engagement: number | null;
      };
    };
    trailing_3_week_avg: {
      window_size: number;
      metrics: {
        posts: number;
        comments: number;
        engagement: number;
      };
      delta_pct: {
        posts: number | null;
        comments: number | null;
        engagement: number | null;
      };
    };
    consistency_score_pct?: Partial<Record<"instagram" | "youtube" | "tiktok" | "twitter", number | null>>;
  };
  platform_breakdown: Array<{
    platform: string;
    posts: number;
    comments: number;
    engagement: number;
    sentiment: {
      positive: number;
      neutral: number;
      negative: number;
    };
  }>;
  themes: {
    positive: Array<{ term: string; count: number; score: number }>;
    negative: Array<{ term: string; count: number; score: number }>;
  };
  leaderboards: {
    bravo_content: Array<{
      platform: string;
      source_id: string;
      text: string;
      engagement: number;
      url: string;
      timestamp: string;
      thumbnail_url?: string | null;
    }>;
    viewer_discussion: Array<{
      platform: string;
      source_id: string;
      text: string;
      engagement: number;
      url: string;
      timestamp: string;
      sentiment: "positive" | "neutral" | "negative";
      thumbnail_url?: string | null;
    }>;
  };
  jobs: Array<{
    id: string;
    platform: string;
    status: "queued" | "pending" | "retrying" | "running" | "completed" | "failed" | "cancelled";
  }>;
};

const makeZeroDay = (day_index: number, date_local: string) => ({
  day_index,
  date_local,
  posts: {
    instagram: 0,
    youtube: 0,
    tiktok: 0,
    twitter: 0,
  },
  comments: {
    instagram: 0,
    youtube: 0,
    tiktok: 0,
    twitter: 0,
  },
  reported_comments: {
    instagram: 0,
    youtube: 0,
    tiktok: 0,
    twitter: 0,
  },
  total_posts: 0,
  total_comments: 0,
  total_reported_comments: 0,
});

const analyticsBase: AnalyticsPayload = {
  window: {
    start: "2026-01-01T00:00:00Z",
    end: "2026-01-31T00:00:00Z",
    timezone: "America/New_York",
    source_scope: "bravo",
  },
  summary: {
    show_id: "show-1",
    season_id: "season-1",
    season_number: 6,
    show_name: "Test Show",
    total_posts: 10,
    total_comments: 20,
    total_engagement: 5000,
    sentiment_mix: {
      positive: 0.4,
      neutral: 0.3,
      negative: 0.3,
      counts: {
        positive: 8,
        neutral: 6,
        negative: 6,
      },
    },
    data_quality: {
      comments_saved_pct_overall: 40,
      platform_comments_saved_pct: {
        instagram: 40,
        youtube: 40,
        tiktok: 40,
        twitter: 40,
      },
      youtube_content_breakdown: {
        videos_count: 12,
        reels_count: 3,
        total_count: 15,
      },
      last_post_at: "2026-01-20T12:00:00Z",
      last_comment_at: "2026-01-20T13:00:00Z",
      data_freshness_minutes: 120,
    },
  },
  weekly: [
    {
      week_index: 1,
      label: "Week 1",
      start: "2026-01-07T00:00:00Z",
      end: "2026-01-13T23:59:59Z",
      week_type: "episode",
      episode_number: 1,
      post_volume: 4,
      comment_volume: 8,
      engagement: 1000,
      sentiment: {
        positive: 5,
        neutral: 2,
        negative: 1,
      },
    },
    {
      week_index: 2,
      label: "Week 2",
      start: "2026-01-14T00:00:00Z",
      end: "2026-01-20T23:59:59Z",
      week_type: "episode",
      episode_number: 2,
      post_volume: 0,
      comment_volume: 0,
      engagement: 0,
      sentiment: {
        positive: 0,
        neutral: 0,
        negative: 0,
      },
    },
  ],
  weekly_platform_posts: [
    {
      week_index: 1,
      label: "Week 1",
      start: "2026-01-07T00:00:00Z",
      end: "2026-01-13T23:59:59Z",
      week_type: "episode",
      episode_number: 1,
      posts: {
        instagram: 1,
        youtube: 1,
        tiktok: 1,
        twitter: 1,
      },
      comments: {
        instagram: 2,
        youtube: 2,
        tiktok: 2,
        twitter: 2,
      },
      reported_comments: {
        instagram: 5,
        youtube: 5,
        tiktok: 5,
        twitter: 5,
      },
      total_posts: 4,
      total_comments: 8,
      total_reported_comments: 20,
      comments_saved_pct: 40.0,
    },
    {
      week_index: 2,
      label: "Week 2",
      start: "2026-01-14T00:00:00Z",
      end: "2026-01-20T23:59:59Z",
      week_type: "episode",
      episode_number: 2,
      posts: {
        instagram: 0,
        youtube: 0,
        tiktok: 0,
        twitter: 0,
      },
      comments: {
        instagram: 0,
        youtube: 0,
        tiktok: 0,
        twitter: 0,
      },
      total_posts: 0,
      total_comments: 0,
    },
  ],
  weekly_platform_engagement: [
    {
      week_index: 1,
      label: "Week 1",
      start: "2026-01-07T00:00:00Z",
      end: "2026-01-13T23:59:59Z",
      engagement: {
        instagram: 100,
        youtube: 200,
        tiktok: 300,
        twitter: 400,
      },
      total_engagement: 1000,
      has_data: true,
    },
    {
      week_index: 2,
      label: "Week 2",
      start: "2026-01-14T00:00:00Z",
      end: "2026-01-20T23:59:59Z",
      engagement: {
        instagram: 0,
        youtube: 0,
        tiktok: 0,
        twitter: 0,
      },
      total_engagement: 0,
      has_data: false,
    },
  ],
  weekly_daily_activity: [
    {
      week_index: 1,
      label: "Week 1",
      start: "2026-01-07T00:00:00Z",
      end: "2026-01-13T23:59:59Z",
      week_type: "episode",
      episode_number: 1,
      days: [
        {
          day_index: 0,
          date_local: "2026-01-07",
          posts: {
            instagram: 1,
            youtube: 1,
            tiktok: 0,
            twitter: 0,
          },
          comments: {
            instagram: 2,
            youtube: 1,
            tiktok: 0,
            twitter: 0,
          },
          reported_comments: {
            instagram: 5,
            youtube: 5,
            tiktok: 0,
            twitter: 0,
          },
          total_posts: 2,
          total_comments: 3,
          total_reported_comments: 10,
        },
        {
          day_index: 1,
          date_local: "2026-01-08",
          posts: {
            instagram: 0,
            youtube: 0,
            tiktok: 1,
            twitter: 0,
          },
          comments: {
            instagram: 0,
            youtube: 0,
            tiktok: 2,
            twitter: 0,
          },
          reported_comments: {
            instagram: 0,
            youtube: 0,
            tiktok: 5,
            twitter: 0,
          },
          total_posts: 1,
          total_comments: 2,
          total_reported_comments: 5,
        },
        {
          day_index: 2,
          date_local: "2026-01-09",
          posts: {
            instagram: 0,
            youtube: 0,
            tiktok: 0,
            twitter: 1,
          },
          comments: {
            instagram: 0,
            youtube: 0,
            tiktok: 0,
            twitter: 3,
          },
          reported_comments: {
            instagram: 0,
            youtube: 0,
            tiktok: 0,
            twitter: 5,
          },
          total_posts: 1,
          total_comments: 3,
          total_reported_comments: 5,
        },
        makeZeroDay(3, "2026-01-10"),
        makeZeroDay(4, "2026-01-11"),
        makeZeroDay(5, "2026-01-12"),
        makeZeroDay(6, "2026-01-13"),
      ],
    },
    {
      week_index: 2,
      label: "Week 2",
      start: "2026-01-14T00:00:00Z",
      end: "2026-01-20T23:59:59Z",
      week_type: "episode",
      episode_number: 2,
      days: [
        makeZeroDay(0, "2026-01-14"),
        makeZeroDay(1, "2026-01-15"),
        makeZeroDay(2, "2026-01-16"),
        makeZeroDay(3, "2026-01-17"),
        makeZeroDay(4, "2026-01-18"),
        makeZeroDay(5, "2026-01-19"),
        makeZeroDay(6, "2026-01-20"),
      ],
    },
  ],
  weekly_flags: [
    {
      week_index: 2,
      code: "zero_activity",
      severity: "info",
      message: "No posts captured in this week window.",
    },
  ],
  benchmark: {
    week_index: 2,
    current: { posts: 0, comments: 0, engagement: 0 },
    previous_week: {
      week_index: 1,
      metrics: { posts: 4, comments: 8, engagement: 1000 },
      delta_pct: { posts: -100, comments: -100, engagement: -100 },
    },
    trailing_3_week_avg: {
      window_size: 1,
      metrics: { posts: 4, comments: 8, engagement: 1000 },
      delta_pct: { posts: -100, comments: -100, engagement: -100 },
    },
    consistency_score_pct: {
      instagram: 14.3,
      youtube: 14.3,
      tiktok: 14.3,
      twitter: 14.3,
    },
  },
  platform_breakdown: [],
  themes: {
    positive: [],
    negative: [],
  },
  leaderboards: {
    bravo_content: [],
    viewer_discussion: [],
  },
  jobs: [],
};

const jsonResponse = (body: unknown): Response =>
  ({
    ok: true,
    status: 200,
    json: async () => body,
    headers: { get: () => null },
  }) as Response;

const escapeRegExp = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const platformTabName = (label: string) =>
  new RegExp(`^${escapeRegExp(label)}(?: \\(\\d+\\))?$`);

const syncSessionStreamResponse = (body: unknown): Response =>
  new Response(`event: sync_session\ndata: ${JSON.stringify(body)}\n\n`, {
    status: 200,
    headers: { "content-type": "text/event-stream; charset=utf-8" },
  });

/**
 * Builds a snapshot envelope matching the shape returned by the
 * `/social/analytics/snapshot` endpoint.  Tests that use custom inline
 * fetch mocks call this from the `/social/analytics/snapshot?` branch
 * so the component's `fetchSeasonSnapshot` works identically to
 * production.
 */
const buildSnapshotEnvelope = (
  analytics: AnalyticsPayload | null,
  overrides?: {
    targets?: Array<{
      platform: string;
      accounts?: string[];
      hashtags?: string[];
      keywords?: string[];
      timezone?: string;
      is_active?: boolean;
      config?: Record<string, unknown>;
    }>;
    runs?: Array<Record<string, unknown>>;
    run_summaries?: Array<Record<string, unknown>>;
    worker_health?: Record<string, unknown> | null;
    shared_status?: Record<string, unknown> | null;
    jobs?: Array<Record<string, unknown>>;
    generated_at?: string | null;
    stale?: boolean;
    cache_age_ms?: number;
  },
) => ({
  analytics,
  targets: overrides?.targets ?? [],
  runs: overrides?.runs ?? [],
  run_summaries: overrides?.run_summaries ?? [],
  worker_health: overrides?.worker_health ?? { queue_enabled: false, healthy: true, healthy_workers: 1, reason: null },
  shared_status: overrides?.shared_status ?? {
    ingest_mode: "shared_account_async",
    matched_posts: 12,
    review_queue_count: 2,
    latest_match_at: "2025-01-10T16:00:00Z",
    shared_scrape_status: { status: "running", job_count: 3, active_jobs: 2, completed_jobs: 1, failed_jobs: 0 },
    classification_status: { status: "complete", job_count: 3, active_jobs: 0, completed_jobs: 3, failed_jobs: 0 },
    materialization_status: { status: "queued", job_count: 1, active_jobs: 0, completed_jobs: 0, failed_jobs: 0 },
    latest_shared_run: {
      run_id: "shared-run-12345678",
      status: "running",
      created_at: "2025-01-10T15:30:00Z",
      started_at: "2025-01-10T15:31:00Z",
      completed_at: null,
    },
  },
  jobs: overrides?.jobs ?? [],
  generated_at: overrides?.generated_at ?? new Date().toISOString(),
  stale: overrides?.stale ?? false,
  cache_age_ms: overrides?.cache_age_ms ?? 0,
});

/**
 * Wraps a fetch mock handler to transparently support the snapshot endpoint.
 * When `/social/analytics/snapshot?` is called, it delegates to the inner handler's
 * `/social/analytics?` handler (and other individual endpoints) to build the
 * bundled snapshot. The inner handler MUST be a plain function (not vi.fn);
 * wrap the result with vi.fn() after.
 */
function wrapWithSnapshotSupport(
  innerHandler: (input: RequestInfo | URL, init?: RequestInit) => Promise<Response> | Response,
): (input: RequestInfo | URL, init?: RequestInit) => Promise<Response> {
  return async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = String(input);

    // Handle snapshot invalidation POST requests
    if (url.includes("/snapshots/invalidate") && (init?.method ?? "GET") === "POST") {
      return jsonResponse({ ok: true });
    }

    // Handle snapshot endpoint by building envelope from individual handlers
    if (url.includes("/social/analytics/snapshot?")) {
      const baseUrl = url.replace("/social/analytics/snapshot?", "/social/analytics?");

      let analytics: unknown = null;
      let targets: unknown[] = [];
      let runs: unknown[] = [];
      let runSummaries: unknown[] = [];
      let workerHealth: unknown = null;
      let sharedStatus: unknown = null;
      let jobs: unknown[] = [];

      const safeCall = async (syntheticUrl: string): Promise<Response | null> => {
        try {
          const resp = await innerHandler(syntheticUrl, init);
          return resp;
        } catch {
          return null;
        }
      };

      const analyticsResp = await safeCall(baseUrl);
      if (analyticsResp?.ok) analytics = await analyticsResp.json();

      const targetsResp = await safeCall(url.replace("/social/analytics/snapshot?", "/social/targets?"));
      if (targetsResp?.ok) {
        const body = await targetsResp.json();
        targets = (body as Record<string, unknown>)?.targets as unknown[] ?? [];
      }

      const runsResp = await safeCall(url.replace("/social/analytics/snapshot?", "/social/runs?"));
      if (runsResp?.ok) {
        const body = await runsResp.json();
        runs = (body as Record<string, unknown>)?.runs as unknown[] ?? [];
      }

      const summariesResp = await safeCall(url.replace("/social/analytics/snapshot?", "/social/runs/summary?"));
      if (summariesResp?.ok) {
        const body = await summariesResp.json();
        runSummaries = (body as Record<string, unknown>)?.summaries as unknown[] ?? [];
      }

      const healthResp = await safeCall(url.replace(/\/social\/analytics\/snapshot\?.*/, "/social/ingest/worker-health"));
      if (healthResp?.ok) workerHealth = await healthResp.json();

      const statusResp = await safeCall(url.replace("/social/analytics/snapshot?", "/social/shared-status?"));
      if (statusResp?.ok) sharedStatus = await statusResp.json();

      const jobsResp = await safeCall(url.replace("/social/analytics/snapshot?", "/social/jobs?"));
      if (jobsResp?.ok) {
        const body = await jobsResp.json();
        jobs = (body as Record<string, unknown>)?.jobs as unknown[] ?? [];
      }

      return jsonResponse({
        analytics,
        targets,
        runs,
        run_summaries: runSummaries,
        worker_health: workerHealth,
        shared_status: sharedStatus,
        jobs,
        generated_at: new Date().toISOString(),
        stale: false,
        cache_age_ms: 0,
      });
    }

    return innerHandler(input, init);
  };
}

const defaultWeekDetailResponse = (weekIndex: number) => {
  if (weekIndex !== 1) {
    return {
      platforms: {
        instagram: { posts: [] },
        youtube: { posts: [] },
        tiktok: { posts: [] },
        twitter: { posts: [] },
      },
    };
  }
  return {
    platforms: {
      instagram: {
        posts: [
          {
            source_id: "ig-week1-1",
            text: "Premiere vibes #RHOSLC @bravotv",
            hashtags: ["RHOSLC"],
            mentions: ["@bravotv"],
            profile_tags: ["@housewife_1"],
            collaborators: ["@housewife_2"],
            comments_count: 5,
            total_comments_available: 5,
          },
        ],
      },
      youtube: {
        posts: [
          {
            source_id: "yt-week1-1",
            text: "Watch #RHOSLC now @BravoTV",
            hashtags: ["RHOSLC"],
            mentions: ["@BravoTV"],
            comments_count: 2,
            total_comments_available: 2,
          },
        ],
      },
      tiktok: {
        posts: [
          {
            source_id: "tt-week1-1",
            text: "Clip #TeamLisa @housewife_1",
            hashtags: ["TeamLisa"],
            mentions: ["@housewife_1"],
            comments_count: 1,
            total_comments_available: 1,
          },
        ],
      },
      twitter: {
        posts: [
          {
            source_id: "tw-week1-1",
            text: "Live thread #RHOSLC @bravoandy",
            hashtags: ["RHOSLC"],
            mentions: ["@bravoandy"],
            comments_count: 0,
            replies_count: 0,
            total_comments_available: 0,
          },
        ],
      },
    },
  };
};

function mockSeasonSocialFetch(
  analytics: AnalyticsPayload,
  snapshotOverrides?: Parameters<typeof buildSnapshotEnvelope>[1],
) {
  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = String(input);

    if (url.includes("/snapshots/invalidate") && (init?.method ?? "GET") === "POST") {
      return jsonResponse({ ok: true });
    }
    if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
    if (url.includes("/social/shared-status?")) {
      return jsonResponse({
        ingest_mode: "shared_account_async",
        matched_posts: 12,
        review_queue_count: 2,
        latest_match_at: "2025-01-10T16:00:00Z",
        shared_scrape_status: { status: "running", job_count: 3, active_jobs: 2, completed_jobs: 1, failed_jobs: 0 },
        classification_status: { status: "complete", job_count: 3, active_jobs: 0, completed_jobs: 3, failed_jobs: 0 },
        materialization_status: { status: "queued", job_count: 1, active_jobs: 0, completed_jobs: 0, failed_jobs: 0 },
        latest_shared_run: {
          run_id: "shared-run-12345678",
          status: "running",
          created_at: "2025-01-10T15:30:00Z",
          started_at: "2025-01-10T15:31:00Z",
          completed_at: null,
        },
      });
    }
    if (url.includes("/social/analytics/snapshot?")) {
      return jsonResponse(buildSnapshotEnvelope(analytics, snapshotOverrides));
    }
    if (url.includes("/social/analytics?")) {
      return jsonResponse(analytics);
    }
    if (url.includes("/cast-role-members?")) {
      return jsonResponse([]);
    }
    const weekDetailMatch = /\/social\/analytics\/week\/(\d+)\?/.exec(url);
    if (weekDetailMatch) {
      return jsonResponse(defaultWeekDetailResponse(Number(weekDetailMatch[1])));
    }
    if (url.includes("/social/targets?")) {
      return jsonResponse({ targets: [] });
    }
    if (url.includes("/social/profiles/")) {
      return jsonResponse({ avatar_url: null, profile_url: null });
    }
    if (url.includes("/social/jobs?")) {
      return jsonResponse({ jobs: [] });
    }
    if (url.includes("/social/runs/summary?")) {
      return jsonResponse({ summaries: [] });
    }
    if (url.includes("/social/runs?")) {
      return jsonResponse({ runs: [] });
    }
    throw new Error(`Unexpected fetch URL: ${url}`);
  });
  vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);
  return fetchMock;
}

describe("SeasonSocialAnalyticsSection weekly trend", () => {
  beforeEach(() => {
    routerReplaceMock.mockClear();
    window.localStorage.clear();
    (auth as unknown as { currentUser?: { getIdToken: () => Promise<string> } }).currentUser = {
      getIdToken: vi.fn().mockResolvedValue("test-token"),
    };
    window.history.replaceState({}, "", "/shows/show-1/s6/social/official");
  });

  afterEach(() => {
    if (vi.isFakeTimers()) {
      vi.clearAllTimers();
    }
    vi.useRealTimers();
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  it("renders daily heatmap rows with zero-value squares visible", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />
    );

    await waitFor(() => {
      expect(screen.getByText("Weekly Trend")).toBeInTheDocument();
    });

    const weekTwoRow = screen.getByTestId("weekly-heatmap-row-2");
    expect(within(weekTwoRow).getAllByTestId(/weekly-heatmap-day-2-/)).toHaveLength(7);
    expect(within(weekTwoRow).getByText("JAN 14")).toBeInTheDocument();
    const zeroTile = within(weekTwoRow).getByTestId("weekly-heatmap-day-2-0").firstElementChild;
    expect(zeroTile?.className).toContain("bg-zinc-200");
    expect(within(weekTwoRow).getByTestId("weekly-heatmap-total-2")).toHaveTextContent("0 posts");
  });

  it("renders section skeletons before analytics resolve", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    expect(screen.getByTestId("social-analytics-skeleton")).toBeInTheDocument();
    await screen.findByText("Weekly Trend");
  });

  it("renders classification rules and shared async pipeline status", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByText("Weekly Trend");

    expect(screen.getByText("Classification Rules")).toBeInTheDocument();
    expect(screen.getByText("Shared Async Pipeline")).toBeInTheDocument();
    expect(screen.getByText("Production Path")).toBeInTheDocument();
    expect(screen.getByText("Matched posts")).toBeInTheDocument();
    expect(screen.getByText("Review queue")).toBeInTheDocument();
    expect(screen.getByText("Retained unassigned")).toBeInTheDocument();
  });

  it("renders official season windows from analytics data", async () => {
    const payload: AnalyticsPayload = {
      ...analyticsBase,
      weekly: [
        {
          week_index: 0,
          label: "Pre-Season",
          start: "2026-01-02T01:00:00Z",
          end: "2026-01-09T01:00:00Z",
          week_type: "preseason",
          episode_number: null,
          post_volume: 1,
          comment_volume: 1,
          engagement: 10,
          sentiment: { positive: 1, neutral: 0, negative: 0 },
        },
        ...analyticsBase.weekly,
        {
          week_index: 3,
          label: "Post-Season",
          start: "2026-01-21T01:00:00Z",
          end: "2026-01-24T01:00:00Z",
          week_type: "postseason",
          episode_number: null,
          post_volume: 0,
          comment_volume: 0,
          engagement: 0,
          sentiment: { positive: 0, neutral: 0, negative: 0 },
        },
      ],
    };
    mockSeasonSocialFetch(payload);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const panel = await screen.findByTestId("season-window-settings");
    expect(within(panel).getByText("Season Windows")).toBeInTheDocument();
    expect(within(panel).getByText("Trailer to premiere")).toBeInTheDocument();
    expect(within(panel).getByText("After finale")).toBeInTheDocument();
    expect(within(panel).getAllByText("Pre-Season").length).toBeGreaterThan(0);
    expect(within(panel).getAllByText("Post-Season").length).toBeGreaterThan(0);
  });

  it("saves trailer drop and postseason overrides through the targets endpoint", async () => {
    const fetchMock = mockSeasonSocialFetch(analyticsBase, {
      targets: [
        {
          platform: "instagram",
          accounts: ["bravotv"],
          hashtags: ["rhoslc"],
          keywords: [],
          timezone: "America/New_York",
          is_active: true,
          config: {
            trailer_drop_at: "2026-01-02T01:00:00+00:00",
            preseason_start: "2026-01-02T01:00:00+00:00",
            preseason_start_at: "2026-01-02T01:00:00+00:00",
            week_zero_start: "2026-01-02T01:00:00+00:00",
          },
        },
      ],
    });

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const trailerInput = await screen.findByLabelText("Trailer Drop");
    await waitFor(() => {
      expect(trailerInput).toHaveValue("2026-01-01T20:00");
    });

    fireEvent.change(trailerInput, { target: { value: "2026-01-02T21:30" } });
    const postseasonInput = screen.getByLabelText("Post-Season End Override");
    fireEvent.change(postseasonInput, { target: { value: "2026-02-09T20:00" } });
    fireEvent.click(screen.getByRole("button", { name: "Save Windows" }));

    await waitFor(() => {
      expect(
        fetchMock.mock.calls.some(
          ([input, init]) => String(input).includes("/social/targets?") && init?.method === "PUT",
        ),
      ).toBe(true);
    });

    const putCall = fetchMock.mock.calls.find(
      ([input, init]) => String(input).includes("/social/targets?") && init?.method === "PUT",
    );
    expect(putCall).toBeDefined();
    const body = JSON.parse(String((putCall?.[1] as RequestInit | undefined)?.body ?? "{}")) as {
      source_scope?: string;
      targets?: Array<{ config?: Record<string, unknown>; timezone?: string }>;
    };
    expect(body.source_scope).toBe("network");
    expect(body.targets?.[0]?.timezone).toBe("America/New_York");
    expect(body.targets?.[0]?.config?.trailer_drop_at).toBe("2026-01-02T21:30");
    expect(body.targets?.[0]?.config?.preseason_start).toBe("2026-01-02T21:30");
    expect(body.targets?.[0]?.config?.preseason_start_at).toBe("2026-01-02T21:30");
    expect(body.targets?.[0]?.config?.week_zero_start).toBe("2026-01-02T21:30");
    expect(body.targets?.[0]?.config?.postseason_end_at).toBe("2026-02-09T20:00");
  });

  it("formats summary count cards with compact number notation", async () => {
    mockSeasonSocialFetch({
      ...analyticsBase,
      summary: {
        ...analyticsBase.summary,
        total_posts: 1025,
        total_comments: 41725,
        total_engagement: 129_514_143,
      },
    });

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    expect(await screen.findByText("1K")).toBeInTheDocument();
    expect(screen.getByText("41.7K")).toBeInTheDocument();
    expect(screen.getByText("129.5M")).toBeInTheDocument();
  });

  it("renders additive reddit summary cards in the unified overview", async () => {
    mockSeasonSocialFetch({
      ...analyticsBase,
      reddit: {
        community_id: "community-1",
        subreddit: "BravoRealHousewives",
        tracked_post_count: 660,
        show_match_post_count: 401,
        comment_count: 18841,
        freshness: {
          latest_run_timestamp: "2026-03-22T14:00:00Z",
          latest_run_status: "partial",
        },
        coverage: {
          recovered_container_count: 18,
          stale_container_count: 1,
        },
        deep_link: {
          path: "/admin/social/reddit/BravoRealHousewives/rhoslc/s6",
        },
      },
    } as AnalyticsPayload);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    expect(await screen.findByTestId("reddit-summary-card")).toBeInTheDocument();
    expect(screen.getByText(/660/)).toBeInTheDocument();
    expect(screen.getByTestId("reddit-freshness-card")).toHaveTextContent(/18/i);
    expect(screen.getByTestId("reddit-freshness-card")).toHaveTextContent(/1 stale/i);
    expect(screen.getByRole("link", { name: /Open Reddit Manager/i })).toHaveAttribute(
      "href",
      "/admin/social/reddit/BravoRealHousewives/rhoslc/s6",
    );
  });

  it("hides reddit summary cards on non-overview platform tabs", async () => {
    window.history.replaceState({}, "", "/shows/show-1/s6/social/official?social_platform=instagram");

    mockSeasonSocialFetch({
      ...analyticsBase,
      reddit: {
        community_id: "community-1",
        subreddit: "BravoRealHousewives",
        tracked_post_count: 660,
        show_match_post_count: 401,
        comment_count: 18841,
        freshness: {
          latest_run_timestamp: "2026-03-22T14:00:00Z",
          latest_run_status: "partial",
        },
        coverage: {
          recovered_container_count: 18,
          stale_container_count: 1,
        },
        deep_link: {
          path: "/admin/social/reddit/BravoRealHousewives/rhoslc/s6",
        },
      },
    } as AnalyticsPayload);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByText("Instagram Classification Rules");
    expect(screen.queryByTestId("reddit-summary-card")).not.toBeInTheDocument();
    expect(screen.queryByTestId("reddit-freshness-card")).not.toBeInTheDocument();
    expect(screen.queryByRole("link", { name: /Open Reddit Manager/i })).not.toBeInTheDocument();
  });

  it("renders post metadata completeness cards and content type distribution", async () => {
    mockSeasonSocialFetch({
      ...analyticsBase,
      summary: {
        ...analyticsBase.summary,
        data_quality: {
          ...analyticsBase.summary.data_quality,
          post_metadata: {
            total_posts: 100,
            captions: { posts_with: 88, pct: 88 },
            tags: { posts_with: 14, pct: 14 },
            mentions: { posts_with: 39, pct: 39 },
            collaborators: { posts_with: 8, pct: 8 },
            content_types: {
              total_posts: 100,
              buckets: [
                { key: "photo", count: 45, pct: 45 },
                { key: "album", count: 12, pct: 12 },
                { key: "video", count: 36, pct: 36 },
                { key: "other", count: 7, pct: 7 },
              ],
            },
          },
        },
      },
    });

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    expect(await screen.findByTestId("metric-captions-coverage-value")).toHaveTextContent("88.0%");
    expect(screen.getByTestId("metric-tags-coverage-value")).toHaveTextContent("14.0%");
    expect(screen.getByTestId("metric-mentions-coverage-value")).toHaveTextContent("39.0%");
    expect(screen.getByTestId("metric-collaborators-coverage-value")).toHaveTextContent("8.0%");
    expect(screen.getByText("88/100 Captions (Saved/Posts)")).toBeInTheDocument();
    expect(screen.getByText("Photo 45.0% (45)")).toBeInTheDocument();
    expect(screen.getByText("Video 36.0% (36)")).toBeInTheDocument();
  });

  it("requires two consecutive poll failures before setting retry state", () => {
    expect(shouldSetPollingRetry(0)).toBe(false);
    expect(shouldSetPollingRetry(1)).toBe(false);
    expect(shouldSetPollingRetry(2)).toBe(true);
  });

  it("builds unique in-flight request keys across filter/scope/view changes", () => {
    const base = buildSocialRequestKey({
      seasonId: "season-1",
      sourceScope: "bravo",
      platformFilter: "all",
      weekFilter: "all",
      analyticsView: "bravo",
    });
    const differentWeek = buildSocialRequestKey({
      seasonId: "season-1",
      sourceScope: "bravo",
      platformFilter: "all",
      weekFilter: 2,
      analyticsView: "bravo",
    });
    const differentPlatform = buildSocialRequestKey({
      seasonId: "season-1",
      sourceScope: "bravo",
      platformFilter: "youtube",
      weekFilter: "all",
      analyticsView: "bravo",
    });
    const differentScope = buildRunsRequestKey({
      seasonId: "season-1",
      sourceScope: "creator",
    });
    const baseRuns = buildRunsRequestKey({
      seasonId: "season-1",
      sourceScope: "bravo",
    });

    expect(base).not.toBe(differentWeek);
    expect(base).not.toBe(differentPlatform);
    expect(baseRuns).not.toBe(differentScope);
  });

  it("builds weekly table links to canonical week detail routes", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />
    );

    const weekOneLink = await screen.findByRole("link", { name: /Week 1/i });
    const href = weekOneLink.getAttribute("href") ?? "";

    expect(href).toContain("/show-1/s6/social/w1");
    expect(href).not.toContain("source_scope=");
    expect(href).not.toContain("season_id=");
    expect(href).not.toContain("?tab=social/week");
  });

  it("preserves active platform tab in week detail links", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByText("Weekly Trend");
    const platformTabs = screen.getByRole("navigation");
    fireEvent.click(within(platformTabs).getByRole("button", { name: platformTabName("YouTube") }));

    const weekOneLink = await screen.findByRole("link", { name: /Week 1/i });
    const href = weekOneLink.getAttribute("href") ?? "";
    expect(href).toContain("/s6/social/w1/youtube");
    expect(href).not.toContain("social_platform=youtube");
  });

  it("renders BYE WEEK labels from backend weekly payloads", async () => {
    const byePayload: AnalyticsPayload = {
      ...analyticsBase,
      weekly: analyticsBase.weekly.map((row) =>
        row.week_index === 2
          ? {
              ...row,
              label: "BYE WEEK (Jan 15-Jan 22)",
              week_type: "bye",
              episode_number: null,
            }
          : row,
      ),
      weekly_platform_posts: analyticsBase.weekly_platform_posts.map((row) =>
        row.week_index === 2
          ? {
              ...row,
              label: "BYE WEEK (Jan 15-Jan 22)",
              week_type: "bye",
              episode_number: null,
            }
          : row,
      ),
      weekly_daily_activity: analyticsBase.weekly_daily_activity.map((row) =>
        row.week_index === 2
          ? {
              ...row,
              label: "BYE WEEK (Jan 15-Jan 22)",
              week_type: "bye",
              episode_number: null,
            }
          : row,
      ),
    };
    mockSeasonSocialFetch(byePayload);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const byeWeekLink = await screen.findByRole("link", {
      name: /bye week/i,
    });
    expect(byeWeekLink.getAttribute("href") ?? "").toContain("/s6/social/w2");
    expect(screen.getAllByText(/BYE WEEK/i).length).toBeGreaterThan(0);
  });

  it("renders preseason and postseason episode labels in the weekly table", async () => {
    const payload: AnalyticsPayload = {
      ...analyticsBase,
      weekly_platform_posts: [
        {
          week_index: 0,
          label: "Pre-Season",
          start: "2025-08-14T00:00:00Z",
          end: "2025-09-16T23:59:59Z",
          week_type: "preseason",
          episode_number: null,
          posts: { instagram: 1, youtube: 0, tiktok: 0, twitter: 0 },
          comments: { instagram: 1, youtube: 0, tiktok: 0, twitter: 0 },
          total_posts: 1,
          total_comments: 1,
        },
        ...analyticsBase.weekly_platform_posts,
        {
          week_index: 3,
          label: "Week 3",
          start: "2026-01-21T00:00:00Z",
          end: "2026-01-27T23:59:59Z",
          week_type: "postseason",
          episode_number: null,
          posts: { instagram: 0, youtube: 0, tiktok: 0, twitter: 0 },
          comments: { instagram: 0, youtube: 0, tiktok: 0, twitter: 0 },
          total_posts: 0,
          total_comments: 0,
        },
      ],
      weekly_platform_engagement: [
        {
          week_index: 0,
          label: "Pre-Season",
          start: "2025-08-14T00:00:00Z",
          end: "2025-09-16T23:59:59Z",
          engagement: { instagram: 10, youtube: 0, tiktok: 0, twitter: 0 },
          total_engagement: 10,
          has_data: true,
        },
        ...analyticsBase.weekly_platform_engagement,
        {
          week_index: 3,
          label: "Week 3",
          start: "2026-01-21T00:00:00Z",
          end: "2026-01-27T23:59:59Z",
          engagement: { instagram: 0, youtube: 0, tiktok: 0, twitter: 0 },
          total_engagement: 0,
          has_data: false,
        },
      ],
    };
    mockSeasonSocialFetch(payload);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const preseasonLink = await screen.findByRole("link", { name: /Episode 0/i });
    expect(preseasonLink).toBeInTheDocument();
    const preseasonRow = preseasonLink.closest("tr");
    expect(preseasonRow).not.toBeNull();
    expect(within(preseasonRow as HTMLElement).getByText("Pre-Season")).toBeInTheDocument();

    const postseasonLink = await screen.findByRole("link", { name: /Post-Season/i });
    expect(postseasonLink).toBeInTheDocument();
    const postseasonRow = postseasonLink.closest("tr");
    expect(postseasonRow).not.toBeNull();
    expect(within(postseasonRow as HTMLElement).getByText("Week 3")).toBeInTheDocument();
  });

  it("wraps long pre-season periods into 7-day rows in Comfortable view", async () => {
    const preseasonDates = [
      "2025-08-14",
      "2025-08-15",
      "2025-08-16",
      "2025-08-17",
      "2025-08-18",
      "2025-08-19",
      "2025-08-20",
      "2025-08-21",
      "2025-08-22",
      "2025-08-23",
      "2025-08-24",
      "2025-08-25",
    ];
    const payload: AnalyticsPayload = {
      ...analyticsBase,
      weekly_daily_activity: [
        {
          week_index: 0,
          label: "Pre-Season",
          start: "2025-08-14T12:00:00Z",
          end: "2025-09-16T12:00:00Z",
          week_type: "preseason",
          episode_number: null,
          days: preseasonDates.map((date, index) => ({
            ...makeZeroDay(index, date),
            total_posts: index === 0 ? 1 : 0,
          })),
        },
        ...analyticsBase.weekly_daily_activity,
      ],
    };
    mockSeasonSocialFetch(payload);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByTestId("weekly-heatmap-row-0");
    fireEvent.click(screen.getByRole("button", { name: "Comfortable" }));

    const preseasonRow = screen.getByTestId("weekly-heatmap-row-0");
    const preseasonDays = within(preseasonRow).getAllByTestId(/weekly-heatmap-day-0-/);
    expect(preseasonDays).toHaveLength(12);

    const dayGrid = within(preseasonRow).getByTestId("weekly-heatmap-day-0-0").parentElement;
    expect(dayGrid).not.toBeNull();
    expect(dayGrid).toHaveClass("grid-cols-7");
  });

  it("renders BYE weeks as their own week sections with week numbers", async () => {
    const byePostsByDay = [4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3];
    const byeCommentsByDay = [40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 38];
    const byeDays = byePostsByDay.map((posts, index) => {
      const dayNumber = 16 + index;
      const dateLocal = `2025-12-${String(dayNumber).padStart(2, "0")}`;
      return {
        ...makeZeroDay(index, dateLocal),
        total_posts: posts,
        total_comments: byeCommentsByDay[index],
      };
    });
    const payload: AnalyticsPayload = {
      ...analyticsBase,
      weekly_daily_activity: [
        analyticsBase.weekly_daily_activity[0],
        {
          week_index: 14,
          label: "BYE WEEK (Dec 16-Dec 30)",
          start: "2025-12-16T12:00:00Z",
          end: "2025-12-30T12:00:00Z",
          week_type: "bye",
          episode_number: null,
          days: byeDays,
        },
      ],
    };
    mockSeasonSocialFetch(payload);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const byeWeekRow = await screen.findByTestId("weekly-heatmap-row-14");
    expect(within(byeWeekRow).getByText("Week 14")).toBeInTheDocument();
    expect(within(byeWeekRow).getByText("BYE WEEK")).toBeInTheDocument();
    expect(within(byeWeekRow).getByTestId("weekly-heatmap-total-14")).toHaveTextContent("43 posts");
    expect(within(byeWeekRow).getByTestId("weekly-heatmap-comments-total-14")).toHaveTextContent("558 comments");
  });

  it("renders premiere and episode/bye metadata tags in the heatmap header", async () => {
    const payload: AnalyticsPayload = {
      ...analyticsBase,
      weekly_daily_activity: analyticsBase.weekly_daily_activity.map((row) =>
        row.week_index === 2
          ? {
              ...row,
              week_type: "bye",
              episode_number: null,
            }
          : row,
      ),
    };
    mockSeasonSocialFetch(payload);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByTestId("weekly-heatmap-row-1");
    expect(screen.getByText("PREMIERE WEEK")).toBeInTheDocument();
    expect(screen.getByText("BYE WEEK")).toBeInTheDocument();
  });

  it("renders platform tabs as the first control row and hides filter/season-id cards", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const nav = await screen.findByRole("navigation");
    expect(within(nav).getByRole("button", { name: "Overview" })).toBeInTheDocument();
    expect(screen.queryByText("Filters")).not.toBeInTheDocument();
    expect(screen.queryByText("Season Details")).not.toBeInTheDocument();
    expect(screen.queryByText("Season ID")).not.toBeInTheDocument();
  });

  it("renders the compact control rail with no selected run", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    expect(await screen.findByRole("button", { name: "Ingest + Export" })).toBeInTheDocument();
    expect(screen.getByRole("combobox", { name: "Run" })).toHaveValue("");
    expect(screen.getByRole("combobox", { name: "Run" })).toHaveAttribute("title", "No Run Selected");
    expect(screen.queryByText("Current Run")).not.toBeInTheDocument();
    expect(screen.queryByText("No run selected.")).not.toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "Test Show · Season 6" })).not.toBeInTheDocument();
  });

  it("opens and closes the ingest plus export popover from the control rail", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    fireEvent.click(await screen.findByRole("button", { name: "Ingest + Export" }));

    expect(screen.getByRole("dialog", { name: "Ingest + Export" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Run Selected Week" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Run Selected Day" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Run Season Sync (All)" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Export CSV" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Export PDF" })).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Close" }));

    await waitFor(() => {
      expect(screen.queryByRole("dialog", { name: "Ingest + Export" })).not.toBeInTheDocument();
    });
  });

  it("loads jobs for a run chosen from the pill dropdown", async () => {
    const activeRunId = "run-active-123";
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes("/social/runs/summary?")) return jsonResponse({ summaries: [] });
      if (url.includes("/social/runs?")) {
        return jsonResponse({
          runs: [
            { id: "run-completed-999", status: "completed", created_at: "2026-02-16T10:00:00Z" },
            { id: activeRunId, status: "running", created_at: "2026-02-17T10:00:00Z" },
          ],
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const runSelect = await screen.findByRole("combobox", { name: "Run" });
    fireEvent.change(runSelect, { target: { value: activeRunId } });

    await waitFor(() => {
      expect(screen.getByRole("combobox", { name: /Run/i })).toHaveValue(activeRunId);
      expect(
        fetchMock.mock.calls.some((call) => String(call[0]).includes("run_id=run-active-123")),
      ).toBe(true);
    });
  });

  it("renders last updated and window in the analytics intro block", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const lastUpdated = await screen.findByText("Last Updated");
    const seasonMetadata = lastUpdated.closest("dl");
    expect(seasonMetadata).toBeTruthy();
    const windowLabel = await screen.findByText("Window", { selector: "dt" });
    const windowRow = windowLabel.closest("div");
    expect(windowRow).toBeTruthy();
    const windowValue = windowRow?.querySelector("dd");
    expect(windowValue?.textContent).toContain("to");
  });

  it("renders the control rail into the show-level header host", async () => {
    mockSeasonSocialFetch(analyticsBase);

    function ShowSocialTabHarness() {
      const [controlsHost, setControlsHost] = React.useState<HTMLDivElement | null>(null);

      return (
        <div>
          <div ref={setControlsHost} data-testid="show-social-header-host" />
          <ShowSocialTab
            socialDependencyError={null}
            selectedSocialSeason={{ id: "season-1", season_number: 6 }}
            socialSeasonOptions={[
              { id: "season-1", season_number: 6 },
              { id: "season-2", season_number: 5 },
            ]}
            selectedSocialSeasonId="season-1"
            onSelectSocialSeasonId={() => {}}
            analyticsSection={
              <SeasonSocialAnalyticsSection
                showId="show-1"
                seasonNumber={6}
                seasonId="season-1"
                showName="Test Show"
                platformTab="overview"
                onPlatformTabChange={() => {}}
                hidePlatformTabs={true}
                externalControlsTarget={controlsHost}
              />
            }
            fallbackSection={<div>Fallback</div>}
          />
        </div>
      );
    }

    render(<ShowSocialTabHarness />);

    const ingestTrigger = await screen.findByRole("button", { name: "Ingest + Export" });
    const seasonSelect = screen.getByRole("combobox", { name: "Season" });
    const headerHost = screen.getByTestId("show-social-header-host");

    expect(headerHost).toContainElement(ingestTrigger);
    expect(
      Boolean(headerHost.compareDocumentPosition(seasonSelect) & Node.DOCUMENT_POSITION_FOLLOWING),
    ).toBe(true);
  });

  it("shows platform handle counts and linked handle tabs for the selected platform", async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health") || url.includes("/social/ingest/health-dot")) {
        return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      }
      if (url.includes("/social/analytics?")) {
        return jsonResponse(analyticsBase);
      }
      if (url.includes("/social/targets?")) {
        return jsonResponse({
          targets: [
            {
              platform: "instagram",
              accounts: ["bravotv", "bravowwhl", "bravodailydish"],
              hashtags: [],
              keywords: [],
              is_active: true,
            },
            {
              platform: "youtube",
              accounts: ["bravo", "wwhl"],
              hashtags: [],
              keywords: [],
              is_active: true,
            },
          ],
        });
      }
      if (url.includes("/social/profiles/instagram/bravowwhl/summary")) {
        return jsonResponse({ avatar_url: "https://images.test/bravowwhl.jpg", profile_url: null });
      }
      if (url.includes("/social/profiles/")) {
        return jsonResponse({ avatar_url: null, profile_url: null });
      }
      if (url.includes("/social/jobs?")) {
        return jsonResponse({ jobs: [] });
      }
      if (url.includes("/social/runs/summary?")) {
        return jsonResponse({ summaries: [] });
      }
      if (url.includes("/social/runs?")) {
        return jsonResponse({ runs: [] });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const instagramTab = await screen.findByRole("button", { name: /Instagram \(3\)/i });
    expect(screen.getByRole("button", { name: /YouTube \(2\)/i })).toBeInTheDocument();

    fireEvent.click(instagramTab);

    const linkedHandles = await screen.findByRole("navigation", { name: "Instagram linked handles" });
    expect(within(linkedHandles).getByText("ALL")).toBeInTheDocument();
    expect(within(linkedHandles).getByRole("link", { name: /@bravotv$/i })).toBeInTheDocument();
    expect(within(linkedHandles).getByRole("link", { name: /@bravowwhl$/i })).toBeInTheDocument();
    expect(within(linkedHandles).getByRole("link", { name: /@bravodailydish$/i })).toBeInTheDocument();
    await waitFor(() => {
      expect(linkedHandles.querySelectorAll("img").length).toBeGreaterThan(0);
    });
  });

  it("preselects tab from social_platform query param and updates URL on tab change", async () => {
    window.history.replaceState(
      {},
      "",
      "/shows/show-1/s6/social/official?social_platform=youtube",
    );
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByText("YouTube Posts Schedule");

    const platformTabs = screen.getByRole("navigation");
    fireEvent.click(within(platformTabs).getByRole("button", { name: platformTabName("Instagram") }));
    expect(window.location.search).toContain("social_platform=instagram");
  });

  it.each(["facebook", "threads"] as const)(
    "redirects episode social path to matching week detail route for %s",
    async (platform) => {
      routerReplaceMock.mockClear();
      window.history.replaceState({}, "", `/shows/show-1/s6/e1/social/${platform}`);
      mockSeasonSocialFetch(analyticsBase);

      render(
        <SeasonSocialAnalyticsSection
          showId="show-1"
          seasonNumber={6}
          seasonId="season-1"
          showName="Test Show"
        />,
      );

      await waitFor(() => {
        expect(routerReplaceMock).toHaveBeenCalled();
      });
      expect(routerReplaceMock).toHaveBeenCalledTimes(1);
      const redirectedHref = String(routerReplaceMock.mock.calls.at(-1)?.[0] ?? "");
      expect(redirectedHref).toContain(`/show-1/s6/social/w1/${platform}`);
    },
  );

  it("renders YouTube Videos/Reels cards only on the YouTube tab", async () => {
    window.history.replaceState({}, "", "/shows/show-1/s6/social/official?social_platform=youtube");
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByText("YouTube Posts Schedule");
    expect(screen.getByTestId("metric-youtube-videos-card")).toBeInTheDocument();
    expect(screen.getByTestId("metric-youtube-videos-value")).toHaveTextContent("12");
    expect(screen.getByTestId("metric-youtube-reels-value")).toHaveTextContent("3");

    const platformTabs = screen.getByRole("navigation");
    fireEvent.click(within(platformTabs).getByRole("button", { name: platformTabName("Instagram") }));
    await waitFor(() => {
      expect(screen.queryByTestId("metric-youtube-videos-card")).not.toBeInTheDocument();
      expect(screen.queryByTestId("metric-youtube-reels-card")).not.toBeInTheDocument();
    });
  });

  it("shows fallback for YouTube Videos/Reels cards when breakdown is missing", async () => {
    window.history.replaceState({}, "", "/shows/show-1/s6/social/official?social_platform=youtube");
    mockSeasonSocialFetch({
      ...analyticsBase,
      summary: {
        ...analyticsBase.summary,
        data_quality: {
          ...analyticsBase.summary.data_quality!,
          youtube_content_breakdown: undefined,
        },
      },
    });

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByText("YouTube Posts Schedule");
    expect(screen.getByTestId("metric-youtube-videos-value")).toHaveTextContent("--");
    expect(screen.getByTestId("metric-youtube-reels-value")).toHaveTextContent("--");
  });

  it("supports controlled platform tabs without mutating URL and allows hiding internal tabs", async () => {
    mockSeasonSocialFetch(analyticsBase);
    const onPlatformTabChange = vi.fn();
    window.history.replaceState({}, "", "/shows/show-1/s6/social/official");

    const { rerender } = render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        platformTab="overview"
        onPlatformTabChange={onPlatformTabChange}
      />,
    );

    const platformTabs = await screen.findByRole("navigation");
    fireEvent.click(within(platformTabs).getByRole("button", { name: platformTabName("YouTube") }));
    expect(onPlatformTabChange).toHaveBeenCalledWith("youtube");
    expect(window.location.search).not.toContain("social_platform=youtube");

    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        platformTab="youtube"
        onPlatformTabChange={onPlatformTabChange}
        hidePlatformTabs={true}
      />,
    );

    await screen.findByText("YouTube Posts Schedule");
    expect(screen.queryByRole("navigation")).not.toBeInTheDocument();
  });

  it("supports Post, Comment, and Completeness heatmap metrics", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />
    );

    await screen.findByTestId("weekly-heatmap-row-1");
    expect(screen.getByTestId("weekly-heatmap-total-1")).toHaveTextContent("4 posts");
    expect(screen.getByTestId("weekly-heatmap-comments-total-1")).toHaveTextContent("8 comments");

    fireEvent.click(screen.getByRole("button", { name: "Comment Count" }));
    expect(screen.getByTestId("weekly-heatmap-total-1")).toHaveTextContent("4 posts");

    fireEvent.click(screen.getByRole("button", { name: "Completeness" }));
    const tile = screen.getByTestId("weekly-heatmap-day-1-0").firstElementChild;
    expect(tile?.className).toContain("bg-red-600");
  });

  it("renders data quality badges and supports density query toggle", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const coverageLabel = await screen.findByText("Coverage");
    const coverageCard = coverageLabel.closest("div");
    expect(coverageCard).not.toBeNull();
    expect(within(coverageCard as HTMLElement).getByText("40.0%")).toBeInTheDocument();
    expect(screen.getByText("2h ago")).toBeInTheDocument();

    const comfortableButton = screen.getByRole("button", { name: "Comfortable" });
    expect(comfortableButton.className).toContain("bg-white");
    expect(window.location.search).not.toContain("social_density=");

    fireEvent.click(screen.getByRole("button", { name: "Compact" }));
    expect(window.location.search).toContain("social_density=compact");

    fireEvent.click(screen.getByRole("button", { name: "Comfortable" }));
    expect(window.location.search).not.toContain("social_density=");

    const tile = screen.getByTestId("weekly-heatmap-day-1-0").firstElementChild;
    expect(tile?.className).toContain("w-full");
  });

  it("shows weekly flag chips and can hide them via alerts toggle", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByText("zero activity");
    fireEvent.click(screen.getByRole("button", { name: "Alerts On" }));
    expect(window.location.search).toContain("social_alerts=off");
    expect(screen.queryByText("zero activity")).not.toBeInTheDocument();
  });

  it("hides drop and comment gap weekly pills", async () => {
    mockSeasonSocialFetch({
      ...analyticsBase,
      weekly_flags: [
        { week_index: 1, code: "zero_activity", severity: "info", message: "No posts." },
        { week_index: 1, code: "spike", severity: "warn", message: "Spike." },
        { week_index: 1, code: "drop", severity: "warn", message: "Drop." },
        { week_index: 1, code: "comment_gap", severity: "warn", message: "Gap." },
      ],
    });

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByText("zero activity");
    expect(screen.getByText("spike")).toBeInTheDocument();
    expect(screen.queryByText("drop")).not.toBeInTheDocument();
    expect(screen.queryByText("comment gap")).not.toBeInTheDocument();
  });

  it("renders episode-oriented weekly table with metric lines under each platform and total progress", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />
    );

    expect(await screen.findByRole("columnheader", { name: "Episode" })).toBeInTheDocument();
    expect(await screen.findByRole("columnheader", { name: "PROGRESS" })).toBeInTheDocument();
    expect(screen.queryByText(/saved to DB/i)).not.toBeInTheDocument();
    const weekOneLink = await screen.findByRole("link", { name: /S6\.E1/i });
    expect(weekOneLink).toBeInTheDocument();
    expect(screen.getAllByText(/\d{1,2}\/\d{1,2}\/\d{2} - \d{1,2}\/\d{1,2}\/\d{2}/).length).toBeGreaterThan(0);

    const weekOneRow = weekOneLink.closest("tr");
    expect(weekOneRow).not.toBeNull();
    const weekOne = within(weekOneRow as HTMLElement);
    expect(weekOne.getByText("Week 1")).toBeInTheDocument();
    expect(weekOne.getByTestId("weekly-platform-metrics-instagram-1")).toHaveTextContent("1 post");
    expect(weekOne.getByTestId("weekly-platform-metrics-instagram-1")).toHaveTextContent("100 likes");
    expect(weekOne.getByTestId("weekly-platform-metrics-instagram-1")).toHaveTextContent("5 comments");
    expect(weekOne.getByTestId("weekly-platform-metrics-instagram-1")).toHaveTextContent("1 hashtag");
    expect(weekOne.getByTestId("weekly-platform-metrics-instagram-1")).toHaveTextContent("1 mention");
    expect(weekOne.getByTestId("weekly-platform-metrics-instagram-1")).toHaveTextContent("1 tag");
    await waitFor(() => {
      expect(weekOne.getByTestId("weekly-total-metrics-1")).toHaveTextContent("4 posts");
      expect(weekOne.getByTestId("weekly-total-metrics-1")).toHaveTextContent("1,000 likes");
      expect(weekOne.getByTestId("weekly-total-metrics-1")).toHaveTextContent("20 comments");
      expect(weekOne.getByTestId("weekly-total-metrics-1")).toHaveTextContent("2 hashtags");
      expect(weekOne.getByTestId("weekly-total-metrics-1")).toHaveTextContent("3 mentions");
      expect(weekOne.getByTestId("weekly-total-metrics-1")).toHaveTextContent("1 tag");
    });
    expect(weekOne.getByTestId("weekly-total-progress-1")).toHaveTextContent("90.0%");
    const weekOneMissingMetrics = weekOne.getByTestId("weekly-missing-metrics-1");
    expect(weekOneMissingMetrics).toHaveTextContent("0 posts");
    expect(weekOneMissingMetrics).toHaveTextContent("0 likes");
    expect(weekOneMissingMetrics).toHaveTextContent("12 comments");
    expect(weekOneMissingMetrics).toHaveTextContent("-- hashtags");
    expect(weekOneMissingMetrics).toHaveTextContent("-- mentions");
    expect(weekOneMissingMetrics).toHaveTextContent("-- tags");

    const weekTwoRow = (await screen.findByRole("link", { name: /S6\.E2/i })).closest("tr");
    expect(weekTwoRow).not.toBeNull();
    const weekTwo = within(weekTwoRow as HTMLElement);
    expect(weekTwo.getByTestId("weekly-total-progress-2")).toHaveTextContent("-");
    await waitFor(() => {
      expect(weekTwo.getByTestId("weekly-total-metrics-2")).toHaveTextContent("0 posts");
      expect(weekTwo.getByTestId("weekly-total-metrics-2")).toHaveTextContent("0 likes");
      expect(weekTwo.getByTestId("weekly-total-metrics-2")).toHaveTextContent("0 comments");
      expect(weekTwo.getByTestId("weekly-total-metrics-2")).toHaveTextContent("0 hashtags");
      expect(weekTwo.getByTestId("weekly-total-metrics-2")).toHaveTextContent("0 mentions");
      expect(weekTwo.getByTestId("weekly-total-metrics-2")).toHaveTextContent("0 tags");
    });
    expect(weekTwo.queryByTestId("weekly-missing-metrics-2")).not.toBeInTheDocument();
    expect(screen.getAllByRole("button", { name: "Sync All" })).toHaveLength(2);
  });

  it("persists selected progress metrics in the social_metrics query param", async () => {
    mockSeasonSocialFetch(analyticsBase);

    const { rerender } = render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const metricsFilter = await screen.findByTestId("weekly-bravo-metric-filter");
    const weekOneMetricsLine = await screen.findByTestId("weekly-total-metrics-1");
    await waitFor(() => {
      expect(weekOneMetricsLine).toHaveTextContent("2 hashtags");
    });
    expect(new URLSearchParams(window.location.search).get("social_metrics")).toBeNull();

    fireEvent.click(within(metricsFilter).getByRole("button", { name: "Hashtags" }));
    await waitFor(() => {
      const metricsParam = new URLSearchParams(window.location.search).get("social_metrics");
      expect(metricsParam).toBe("posts,likes,comments,mentions,tags");
    });
    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );
    await waitFor(() => {
      expect(weekOneMetricsLine).not.toHaveTextContent(/hashtags/i);
    });

    fireEvent.click(within(metricsFilter).getByRole("button", { name: "Hashtags" }));
    await waitFor(() => {
      const metricsParam = new URLSearchParams(window.location.search).get("social_metrics");
      expect(metricsParam).toBeNull();
    });
    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );
    await waitFor(() => {
      expect(weekOneMetricsLine).toHaveTextContent("2 hashtags");
    });
  });

  it("persists social_metric_mode in the URL and switches comments between total and saved values", async () => {
    window.history.replaceState(
      {},
      "",
      "/admin/trr-shows/show-1/seasons/6?tab=social&social_metric_mode=saved",
    );
    mockSeasonSocialFetch(analyticsBase);

    const { rerender } = render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const weekOneMetricsLine = await screen.findByTestId("weekly-total-metrics-1");
    expect(new URLSearchParams(window.location.search).get("social_metric_mode")).toBe("saved");
    expect(weekOneMetricsLine).toHaveTextContent("8 comments");

    fireEvent.click(screen.getByRole("button", { name: "Total" }));
    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );
    await waitFor(() => {
      expect(new URLSearchParams(window.location.search).get("social_metric_mode")).toBeNull();
      expect(weekOneMetricsLine).toHaveTextContent("20 comments");
    });

    fireEvent.click(screen.getByRole("button", { name: "Saved" }));
    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );
    await waitFor(() => {
      expect(new URLSearchParams(window.location.search).get("social_metric_mode")).toBe("saved");
      expect(weekOneMetricsLine).toHaveTextContent("8 comments");
    });
  });

  it("supports Select All / Deselect all metric controls", async () => {
    mockSeasonSocialFetch(analyticsBase);

    const { rerender } = render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const weekOneMetricsLine = await screen.findByTestId("weekly-total-metrics-1");
    const selectAllButton = await screen.findByRole("button", { name: /select all/i });
    fireEvent.click(selectAllButton);
    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );
    await waitFor(() => {
      expect(new URLSearchParams(window.location.search).get("social_metrics")).toContain(
        "collaborators",
      );
      expect(weekOneMetricsLine).toHaveTextContent("4 posts");
      expect(weekOneMetricsLine).toHaveTextContent("1,000 likes");
    });

    const deselectAllButton = await screen.findByRole("button", { name: /deselect all/i });
    fireEvent.click(deselectAllButton);
    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );
    await waitFor(() => {
      expect(new URLSearchParams(window.location.search).get("social_metrics")).toBe("none");
      expect(weekOneMetricsLine).toHaveTextContent("No metrics selected");
    });
  });

  it("fetches week detail payloads when detail metrics are selected", async () => {
    const fetchMock = mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByTestId("weekly-total-metrics-1");
    await waitFor(() => {
      const weekDetailCalls = fetchMock.mock.calls.filter(([input]) =>
        String(input).includes("/social/analytics/week/"),
      ).length;
      expect(weekDetailCalls).toBeGreaterThan(0);
    });
  });

  it("limits week detail fanout concurrency to two in-flight requests", async () => {
    const analyticsWithFourWeeks: AnalyticsPayload = {
      ...analyticsBase,
      weekly: [
        ...analyticsBase.weekly,
        {
          ...analyticsBase.weekly[0],
          week_index: 3,
          label: "Week 3",
          start: "2026-01-21T00:00:00Z",
          end: "2026-01-27T23:59:59Z",
        },
        {
          ...analyticsBase.weekly[0],
          week_index: 4,
          label: "Week 4",
          start: "2026-01-28T00:00:00Z",
          end: "2026-02-03T23:59:59Z",
        },
      ],
      weekly_platform_posts: [
        ...analyticsBase.weekly_platform_posts,
        {
          ...analyticsBase.weekly_platform_posts[0],
          week_index: 3,
          label: "Week 3",
          start: "2026-01-21T00:00:00Z",
          end: "2026-01-27T23:59:59Z",
        },
        {
          ...analyticsBase.weekly_platform_posts[0],
          week_index: 4,
          label: "Week 4",
          start: "2026-01-28T00:00:00Z",
          end: "2026-02-03T23:59:59Z",
        },
      ],
      weekly_platform_engagement: [
        ...analyticsBase.weekly_platform_engagement,
        {
          ...analyticsBase.weekly_platform_engagement[0],
          week_index: 3,
          label: "Week 3",
          start: "2026-01-21T00:00:00Z",
          end: "2026-01-27T23:59:59Z",
        },
        {
          ...analyticsBase.weekly_platform_engagement[0],
          week_index: 4,
          label: "Week 4",
          start: "2026-01-28T00:00:00Z",
          end: "2026-02-03T23:59:59Z",
        },
      ],
      weekly_daily_activity: [
        ...analyticsBase.weekly_daily_activity,
        {
          ...analyticsBase.weekly_daily_activity[0],
          week_index: 3,
          label: "Week 3",
          start: "2026-01-21T00:00:00Z",
          end: "2026-01-27T23:59:59Z",
        },
        {
          ...analyticsBase.weekly_daily_activity[0],
          week_index: 4,
          label: "Week 4",
          start: "2026-01-28T00:00:00Z",
          end: "2026-02-03T23:59:59Z",
        },
      ],
    };

    const weekDetailResolvers = new Map<number, () => void>();
    let startedWeekDetails = 0;
    let inFlightWeekDetails = 0;
    let maxInFlightWeekDetails = 0;

    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) {
        return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      }
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsWithFourWeeks);
      const weekDetailMatch = /\/social\/analytics\/week\/(\d+)\?/.exec(url);
      if (weekDetailMatch) {
        const weekIndex = Number(weekDetailMatch[1]);
        startedWeekDetails += 1;
        inFlightWeekDetails += 1;
        maxInFlightWeekDetails = Math.max(maxInFlightWeekDetails, inFlightWeekDetails);
        return new Promise<Response>((resolve) => {
          weekDetailResolvers.set(weekIndex, () => {
            inFlightWeekDetails = Math.max(0, inFlightWeekDetails - 1);
            resolve(jsonResponse(defaultWeekDetailResponse(weekIndex)));
          });
        });
      }
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes("/social/runs/summary?")) return jsonResponse({ summaries: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByTestId("weekly-total-metrics-1");
    await waitFor(() => {
      expect(startedWeekDetails).toBe(2);
    });
    expect(maxInFlightWeekDetails).toBeLessThanOrEqual(2);

    act(() => {
      weekDetailResolvers.get(1)?.();
    });
    await waitFor(() => {
      expect(startedWeekDetails).toBeGreaterThanOrEqual(3);
    });

    act(() => {
      for (const resolve of weekDetailResolvers.values()) {
        resolve();
      }
      weekDetailResolvers.clear();
    });
  });

  it("stages initial primary social refresh under a concurrency cap of two before deferred reads begin", async () => {
    // After the snapshot refactor, bootstrap is a single snapshot request rather
    // than three individual fetches with a concurrency cap.  This test now verifies
    // the component makes exactly one snapshot request for the initial load and
    // that secondary/individual endpoint requests are not issued separately.
    let snapshotCalls = 0;
    let individualAnalyticsCalls = 0;

    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/snapshots/invalidate")) {
        return jsonResponse({ ok: true });
      }
      if (url.includes("/social/analytics/snapshot?")) {
        snapshotCalls += 1;
        return jsonResponse(
          buildSnapshotEnvelope(analyticsBase),
        );
      }
      if (url.includes("/social/analytics?")) {
        individualAnalyticsCalls += 1;
        return jsonResponse(analyticsBase);
      }
      if (url.includes("/social/analytics/week/")) {
        return jsonResponse(defaultWeekDetailResponse(1));
      }
      // Any other individual endpoints should not be called directly
      if (url.includes("/social/targets?") || url.includes("/social/runs?") || url.includes("/social/jobs?")) {
        return jsonResponse({ targets: [], runs: [], jobs: [] });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByTestId("weekly-heatmap-row-1");
    expect(snapshotCalls).toBe(1);
    expect(individualAnalyticsCalls).toBe(0);
  });

  it("fetches week detail payloads in hashtags view even when only posts/likes/comments metrics are selected", async () => {
    window.history.replaceState(
      {},
      "",
      "/shows/show-1/s6/social/official?social_view=hashtags&social_metrics=posts,likes,comments",
    );
    const fetchMock = mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="hashtags"
      />,
    );

    await screen.findByTestId("hashtag-insights-total-uses");
    await waitFor(() => {
      const weekDetailCalls = fetchMock.mock.calls.filter(([input]) =>
        String(input).includes("/social/analytics/week/"),
      ).length;
      expect(weekDetailCalls).toBeGreaterThan(0);
    });
  });

  it("skips week detail payload fetches when only posts/likes/comments metrics are selected", async () => {
    window.history.replaceState(
      {},
      "",
      "/shows/show-1/s6/social/official?social_metrics=posts,likes,comments",
    );
    const fetchMock = mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const weekOneMetricsLine = await screen.findByTestId("weekly-total-metrics-1");
    expect(weekOneMetricsLine).toHaveTextContent("4 posts");
    expect(weekOneMetricsLine).toHaveTextContent("1,000 likes");
    expect(weekOneMetricsLine).toHaveTextContent("20 comments");
    expect(weekOneMetricsLine).not.toHaveTextContent(/hashtags|mentions|tags/i);

    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 50));
    });

    const weekDetailCalls = fetchMock.mock.calls.filter(([input]) =>
      String(input).includes("/social/analytics/week/"),
    ).length;
    expect(weekDetailCalls).toBe(0);
  });

  it("shows -- fallback for detail metrics while week detail data is loading", async () => {
    const weekDetailResolvers = new Map<number, () => void>();
    const deferredFetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) {
        return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      }
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      const weekDetailMatch = /\/social\/analytics\/week\/(\d+)\?/.exec(url);
      if (weekDetailMatch) {
        const weekIndex = Number(weekDetailMatch[1]);
        return new Promise<Response>((resolve) => {
          weekDetailResolvers.set(weekIndex, () => resolve(jsonResponse(defaultWeekDetailResponse(weekIndex))));
        });
      }
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes("/social/runs/summary?")) return jsonResponse({ summaries: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(deferredFetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const weekOneMetricsLine = await screen.findByTestId("weekly-total-metrics-1");
    await waitFor(() => {
      expect(weekOneMetricsLine).toHaveTextContent("-- hashtags");
      expect(weekOneMetricsLine).toHaveTextContent("-- mentions");
      expect(weekOneMetricsLine).toHaveTextContent("-- tags");
    });

    act(() => {
      weekDetailResolvers.get(1)?.();
      weekDetailResolvers.get(2)?.();
    });

    await waitFor(() => {
      expect(weekOneMetricsLine).toHaveTextContent("2 hashtags");
      expect(weekOneMetricsLine).toHaveTextContent("3 mentions");
      expect(weekOneMetricsLine).toHaveTextContent("1 tag");
    });
  });

  it("shows -- collaborators fallback token when collaborators metric is selected and detail data is pending", async () => {
    window.history.replaceState(
      {},
      "",
      "/shows/show-1/s6/social/official?social_metrics=posts,likes,comments,hashtags,mentions,tags,collaborators",
    );

    const weekDetailResolvers = new Map<number, () => void>();
    const deferredFetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      if (url.includes("/social/ingest/worker-health")) {
        return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      }
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      const weekDetailMatch = /\/social\/analytics\/week\/(\d+)\?/.exec(url);
      if (weekDetailMatch) {
        const weekIndex = Number(weekDetailMatch[1]);
        return new Promise<Response>((resolve) => {
          weekDetailResolvers.set(weekIndex, () => resolve(jsonResponse(defaultWeekDetailResponse(weekIndex))));
        });
      }
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes("/social/runs/summary?")) return jsonResponse({ summaries: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(deferredFetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const weekOneMetricsLine = await screen.findByTestId("weekly-total-metrics-1");
    await waitFor(() => {
      expect(weekOneMetricsLine).toHaveTextContent("-- collaborators");
    });
  });

  it("renders week date ranges under weekly heatmap headers", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByTestId("weekly-heatmap-row-1");
    const dateLabels = screen.getAllByText(/Jan \d{1,2} to Jan \d{1,2}/);
    expect(dateLabels.length).toBeGreaterThan(0);
  });

  it("shows Up-to-Date when platform coverage reaches 100%", async () => {
    const analyticsUpToDate: AnalyticsPayload = {
      ...analyticsBase,
      weekly_platform_posts: analyticsBase.weekly_platform_posts.map((row) =>
        row.week_index === 1
          ? {
              ...row,
              comments: {
                instagram: 5,
                youtube: 5,
                tiktok: 5,
                twitter: 5,
              },
              reported_comments: {
                ...(row.reported_comments ?? {
                  instagram: 0,
                  youtube: 0,
                  tiktok: 0,
                  twitter: 0,
                }),
                instagram: 5,
                youtube: 5,
                tiktok: 5,
                twitter: 5,
              },
              total_comments: 20,
              total_reported_comments: 20,
              comments_saved_pct: 100.0,
            }
          : row,
      ),
    };
    mockSeasonSocialFetch(analyticsUpToDate);
    window.history.replaceState({}, "", "/shows/show-1/s6/social/official?social_metrics=posts,comments,likes");

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const upToDateLabels = await screen.findAllByText("Up-to-Date");
    expect(upToDateLabels.length).toBeGreaterThan(0);
    const weekOneRow = (await screen.findByRole("link", { name: /S6\.E1/i })).closest("tr");
    expect(weekOneRow).not.toBeNull();
    const weekOne = within(weekOneRow as HTMLElement);
    expect(weekOne.getByTestId("weekly-total-progress-1")).toHaveTextContent("100.0%");
    expect(weekOne.queryByTestId("weekly-missing-metrics-1")).not.toBeInTheDocument();
    expect(screen.getAllByRole("button", { name: "Sync All" })).toHaveLength(2);
  });

  it("flags stale active runs older than 45 minutes with pending/retrying counts", async () => {
    const staleTime = new Date(Date.now() - 120 * 60 * 1000).toISOString();
    const runId = "run-stale-001";
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) {
        return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      }
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/runs/summary?")) return jsonResponse({ summaries: [] });
      if (url.includes("/social/runs?")) {
        return jsonResponse({
          runs: [
            {
              id: runId,
              status: "running",
              created_at: staleTime,
              updated_at: staleTime,
            },
          ],
        });
      }
      if (url.includes("/social/jobs?")) {
        return jsonResponse({
          jobs: [
            {
              id: "job-1",
              run_id: runId,
              platform: "instagram",
              status: "pending",
              created_at: staleTime,
              updated_at: staleTime,
            },
            {
              id: "job-2",
              run_id: runId,
              platform: "youtube",
              status: "retrying",
              created_at: staleTime,
              updated_at: staleTime,
            },
          ],
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await waitFor(() => {
      expect(screen.getByText(/Potentially stalled ingest runs/i)).toBeInTheDocument();
    });
    expect(screen.getByText(/pending \d+ · retrying \d+/)).toBeInTheDocument();
  });

  it("does not flag active runs newer than the stale threshold", async () => {
    const freshTime = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) {
        return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      }
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/runs/summary?")) return jsonResponse({ summaries: [] });
      if (url.includes("/social/runs?")) {
        return jsonResponse({
          runs: [
            {
              id: "run-fresh-001",
              status: "running",
              created_at: freshTime,
              updated_at: freshTime,
            },
          ],
        });
      }
      if (url.includes("/social/jobs?")) {
        return jsonResponse({
          jobs: [
            {
              id: "job-fresh-1",
              run_id: "run-fresh-001",
              platform: "instagram",
              status: "pending",
              created_at: freshTime,
              updated_at: freshTime,
            },
          ],
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByRole("link", { name: /Week 1/i });
    expect(screen.queryByText(/Potentially stalled ingest runs/i)).not.toBeInTheDocument();
  });

  it("disables weekly Run Week and Sync All actions when queue workers are unhealthy", async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) {
        return jsonResponse({
          queue_enabled: true,
          healthy: false,
          healthy_workers: 0,
          reason: "no_healthy_workers",
        });
      }
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes("/social/runs/summary?")) return jsonResponse({ summaries: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    expect(screen.queryAllByRole("button", { name: "Run Week" })).toHaveLength(0);
    expect(screen.queryAllByRole("button", { name: "Sync All" })).toHaveLength(0);
  });

  it("hydrates from cached social snapshot and suppresses transient timeout banners", async () => {
    const cacheKey = "trr:season-social-analytics:v1:show-1:6:season-1:network:all:all";
    window.localStorage.setItem(
      cacheKey,
      JSON.stringify({
        version: 1,
        saved_at: "2026-02-24T11:00:00.000Z",
        analytics: analyticsBase,
        runs: [],
        targets: [],
        last_updated: "2026-02-24T11:00:00.000Z",
        section_last_success_at: {
          analytics: "2026-02-24T11:00:00.000Z",
          targets: "2026-02-24T11:00:00.000Z",
          runs: "2026-02-24T11:00:00.000Z",
        },
      }),
    );

    // After the snapshot refactor, the component makes a single snapshot request.
    // When it fails with a transient error (timed out), the component shows the
    // stale fallback message instead of the raw error messages.
    // The snapshot fetch is deferred so that the localStorage cache-hydration
    // effect has time to populate sectionLastSuccessAt before errors are set.
    let rejectSnapshot: ((error: Error) => void) | null = null;
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/snapshots/invalidate")) return jsonResponse({ ok: true });
      if (url.includes("/social/analytics/snapshot?")) {
        return new Promise<Response>((_resolve, reject) => {
          rejectSnapshot = reject;
        });
      }
      if (url.includes("/social/analytics/week/")) {
        return jsonResponse(defaultWeekDetailResponse(1));
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    // Wait for the cache hydration to render the cached analytics
    await screen.findByText("Weekly Trend");

    // Now reject the snapshot to simulate a timeout error
    await act(async () => {
      rejectSnapshot?.(new Error("Social analytics snapshot request timed out"));
    });

    await waitFor(() => {
      expect(
        screen.getByText("Showing last successful social data while live refresh retries."),
      ).toBeInTheDocument();
    });
    // With the snapshot architecture, the snapshot error propagates to all four
    // section error slots (analytics, targets, runs, jobs) plus workerHealthError,
    // sharedStatusError, and runSummaryError.  analytics/targets/runs section errors
    // with cached staleAt dates route to the stale-fallback banner; other error slots
    // (jobs section, worker health, shared status, run summary) render the raw
    // message individually.  The important invariant is the stale-fallback banner
    // appears, confirming the cached analytics/targets/runs errors are suppressed.
  });

  it("hydrates from cached social snapshot and shows backend saturation stale fallback copy", async () => {
    const cacheKey = "trr:season-social-analytics:v1:show-1:6:season-1:network:all:all";
    window.localStorage.setItem(
      cacheKey,
      JSON.stringify({
        version: 1,
        saved_at: "2026-02-24T11:00:00.000Z",
        analytics: analyticsBase,
        runs: [],
        targets: [],
        last_updated: "2026-02-24T11:00:00.000Z",
        section_last_success_at: {
          analytics: "2026-02-24T11:00:00.000Z",
          targets: "2026-02-24T11:00:00.000Z",
          runs: "2026-02-24T11:00:00.000Z",
        },
      }),
    );

    // After the snapshot refactor, the component makes a single snapshot request.
    // When it returns 503 with a backend-saturated error, the component should
    // show the saturation-specific stale fallback message.
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/snapshots/invalidate")) return jsonResponse({ ok: true });
      if (url.includes("/social/analytics/snapshot?")) {
        return {
          ok: false,
          status: 503,
          headers: { get: (name: string) => (name.toLowerCase() === "retry-after" ? "2" : null) },
          json: async () => ({
            error: "Local TRR-Backend is saturated. Showing last successful data while retrying.",
            code: "BACKEND_SATURATED",
            retryable: true,
            retry_after_seconds: 2,
            upstream_status: 503,
            upstream_detail: "connection pool exhausted",
          }),
        } as Response;
      }
      if (url.includes("/social/analytics/week/")) {
        return jsonResponse(defaultWeekDetailResponse(1));
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByText("Weekly Trend");
    await waitFor(() => {
      expect(
        screen.getByText("Local TRR-Backend is saturated. Showing last successful social data while retrying."),
      ).toBeInTheDocument();
    });
    expect(screen.queryByText("connection pool exhausted")).not.toBeInTheDocument();
  });

  it("uses platform-specific day values and shows YouTube posts schedule label", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />
    );

    await screen.findByTestId("weekly-heatmap-row-1");
    const platformTabs = screen.getByRole("navigation");
    fireEvent.click(within(platformTabs).getByRole("button", { name: platformTabName("YouTube") }));

    await screen.findByText("YouTube Posts Schedule");
    expect(screen.getByTestId("weekly-heatmap-total-1")).toHaveTextContent("1 posts");
  });

  it("shows compatibility message when daily schedule payload is missing", async () => {
    const analyticsWithoutDaily = {
      ...analyticsBase,
      weekly_daily_activity: [],
    } satisfies AnalyticsPayload;

    mockSeasonSocialFetch(analyticsWithoutDaily);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />
    );

    expect(await screen.findByTestId("weekly-heatmap-unavailable")).toHaveTextContent(
      "Daily schedule unavailable for the current view."
    );
  });

  it("switches rendered sections by analyticsView", async () => {
    mockSeasonSocialFetch(analyticsBase);

    const { rerender } = render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="advanced"
      />,
    );

    await screen.findByRole("button", { name: "Ingest + Export" });
    expect(screen.queryByText("Top Sentiment Drivers")).not.toBeInTheDocument();
    expect(screen.queryByText("Weekly Trend")).not.toBeInTheDocument();

    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="sentiment"
      />,
    );

    await screen.findByText("Top Sentiment Drivers");
    expect(screen.getByRole("button", { name: "Ingest + Export" })).toBeInTheDocument();
    expect(screen.getByText("Viewer Discussion Highlights")).toBeInTheDocument();
    expect(screen.getByText("Cast Mention Comparison (Prototype)")).toBeInTheDocument();
    expect(screen.getByText("Viewer Attitude by Platform")).toBeInTheDocument();

    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="bravo"
      />,
    );

    await screen.findByText("Weekly Trend");
    const ingestButton = screen.getByRole("button", { name: "Ingest + Export" });
    const weeklyTrendHeading = screen.getByRole("heading", { name: "Weekly Trend" });
    expect(ingestButton).toBeInTheDocument();
    expect(
      Boolean(ingestButton.compareDocumentPosition(weeklyTrendHeading) & Node.DOCUMENT_POSITION_FOLLOWING),
    ).toBe(true);

    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="reddit"
      />,
    );

    expect(await screen.findByTestId("reddit-sources-manager")).toBeInTheDocument();
    expect(screen.queryByText("Weekly Trend")).not.toBeInTheDocument();
    expect(screen.queryByText("Current Run")).not.toBeInTheDocument();
    expect(screen.queryByText("Season Details")).not.toBeInTheDocument();
    expect(screen.queryByText("Filters")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Overview" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: platformTabName("Instagram") })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: platformTabName("TikTok") })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: platformTabName("Twitter/X") })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: platformTabName("YouTube") })).not.toBeInTheDocument();
  });

  it("switches from bravo to reddit even when bravo refresh requests are still pending", async () => {
    // After the snapshot refactor, the component makes a single snapshot request.
    // When switching from bravo to reddit while the snapshot is pending,
    // the reddit view should render without waiting for the bravo snapshot.
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/snapshots/invalidate")) return jsonResponse({ ok: true });
      if (url.includes("/social/analytics/snapshot?")) {
        // Bravo snapshot hangs forever
        return new Promise<Response>(() => {});
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });

    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    const { rerender } = render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="bravo"
      />,
    );

    // Wait for the snapshot request to be issued
    await waitFor(() => {
      const snapshotCalls = fetchMock.mock.calls.filter(([input]) =>
        String(input).includes("/social/analytics/snapshot?"),
      ).length;
      expect(snapshotCalls).toBeGreaterThan(0);
    });

    const snapshotCallsBefore = fetchMock.mock.calls.filter(([input]) =>
      String(input).includes("/social/analytics/snapshot?"),
    ).length;

    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="reddit"
      />,
    );

    expect(await screen.findByTestId("reddit-sources-manager")).toBeInTheDocument();
    expect(screen.queryByText("Current Run")).not.toBeInTheDocument();

    await act(async () => {
      await Promise.resolve();
    });

    // No additional snapshot calls should be issued after switching to reddit
    const snapshotCallsAfter = fetchMock.mock.calls.filter(([input]) =>
      String(input).includes("/social/analytics/snapshot?"),
    ).length;
    expect(snapshotCallsAfter).toBe(snapshotCallsBefore);
  });

  it("restarts bravo refresh pipeline when returning from reddit after stale bravo requests", async () => {
    // After the snapshot refactor, the component makes a single snapshot request.
    // The first bravo snapshot hangs, then we switch to reddit, then back to bravo.
    // A new snapshot request should be issued on return to bravo.
    let snapshotCalls = 0;
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/snapshots/invalidate")) return jsonResponse({ ok: true });
      if (url.includes("/social/analytics/snapshot?")) {
        snapshotCalls += 1;
        if (snapshotCalls === 1) {
          // First bravo snapshot hangs
          return new Promise<Response>(() => {});
        }
        // Subsequent calls resolve successfully
        return jsonResponse(buildSnapshotEnvelope(analyticsBase));
      }
      if (url.includes("/social/analytics/week/")) {
        return jsonResponse(defaultWeekDetailResponse(1));
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });

    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    const { rerender } = render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="bravo"
      />,
    );

    await waitFor(() => {
      expect(snapshotCalls).toBeGreaterThan(0);
    });

    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="reddit"
      />,
    );

    expect(await screen.findByTestId("reddit-sources-manager")).toBeInTheDocument();

    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="bravo"
      />,
    );

    await waitFor(() => {
      expect(snapshotCalls).toBeGreaterThan(1);
    });
  });

  it("renders advanced run health and benchmark panel", async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes("/social/runs/summary?")) {
        return jsonResponse({
          summaries: [
            {
              run_id: "run-1",
              status: "completed",
              duration_seconds: 180,
              success_rate_pct: 75,
            },
          ],
        });
      }
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="advanced"
      />,
    );

    await screen.findByText("Run Health");
    expect(screen.getByText("75.0%")).toBeInTheDocument();
    expect(screen.getByText("3m 0s")).toBeInTheDocument();
    expect(screen.getByText("Consistency & Momentum")).toBeInTheDocument();
  });

  it("groups failures and renders latest five failure events in run health", async () => {
    const runId = "run-fail-1";
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/runs/summary?")) {
        return jsonResponse({
          summaries: [{ run_id: runId, status: "failed", duration_seconds: 240, success_rate_pct: 42.5 }],
        });
      }
      if (url.includes("/social/runs?")) {
        return jsonResponse({
          runs: [{ id: runId, status: "failed", created_at: "2026-02-24T18:00:00Z" }],
        });
      }
      if (url.includes("/social/jobs?")) {
        return jsonResponse({
          jobs: [
            {
              id: "job-a",
              run_id: runId,
              platform: "youtube",
              status: "failed",
              job_type: "comments",
              error_message: "Rate limited",
              created_at: "2026-02-24T18:04:00Z",
              config: { stage: "comments" },
              job_error_code: "RATE_LIMIT",
            },
            {
              id: "job-b",
              run_id: runId,
              platform: "youtube",
              status: "failed",
              job_type: "comments",
              error_message: "Rate limited",
              created_at: "2026-02-24T18:03:00Z",
              config: { stage: "comments" },
              job_error_code: "RATE_LIMIT",
            },
            {
              id: "job-c",
              run_id: runId,
              platform: "instagram",
              status: "failed",
              job_type: "posts",
              error_message: "Parser mismatch",
              created_at: "2026-02-24T18:02:00Z",
              config: { stage: "posts" },
              job_error_code: "PARSER",
            },
            {
              id: "job-d",
              run_id: runId,
              platform: "twitter",
              status: "retrying",
              job_type: "comments",
              error_message: "Network timeout",
              created_at: "2026-02-24T18:01:00Z",
              config: { stage: "comments" },
              job_error_code: "NETWORK",
            },
            {
              id: "job-e",
              run_id: runId,
              platform: "tiktok",
              status: "failed",
              job_type: "posts",
              error_message: "Auth rejected",
              created_at: "2026-02-24T18:00:00Z",
              config: { stage: "posts" },
              job_error_code: "AUTH",
            },
            {
              id: "job-f",
              run_id: runId,
              platform: "instagram",
              status: "failed",
              job_type: "comments",
              error_message: "Unknown error",
              created_at: "2026-02-24T17:59:00Z",
              config: { stage: "comments" },
              job_error_code: "UNKNOWN",
            },
          ],
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="advanced"
      />,
    );

    await screen.findByText("Run Health");
    fireEvent.change(await screen.findByRole("combobox", { name: "Run" }), {
      target: { value: runId },
    });

    await waitFor(() => {
      expect(screen.getByText("Failure Groups")).toBeInTheDocument();
      expect(screen.getByText("Latest 5 Failure Events")).toBeInTheDocument();
    });
    expect(await screen.findByText(/RATE_LIMIT\s*·\s*comments\s*·\s*2/i)).toBeInTheDocument();
    const latestFailures = screen.getByTestId("run-health-latest-failures");
    await waitFor(() => {
      expect(within(latestFailures).getAllByRole("listitem")).toHaveLength(5);
    });
  });

  it("does not crash when benchmark delta payload is partially missing", async () => {
    const analyticsWithPartialBenchmark = {
      ...analyticsBase,
      benchmark: {
        ...analyticsBase.benchmark!,
        previous_week: {
          ...analyticsBase.benchmark!.previous_week,
          delta_pct: undefined,
        },
      },
    } as unknown as AnalyticsPayload;
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsWithPartialBenchmark);
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes("/social/runs/summary?")) return jsonResponse({ summaries: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="advanced"
      />,
    );

    await screen.findByText("Consistency & Momentum");
    expect(screen.getAllByText("N/A").length).toBeGreaterThan(0);
    expect(screen.queryByText("Something went wrong")).not.toBeInTheDocument();
  });

  it("renders leaderboard thumbnails for content and discussion cards", async () => {
    const analyticsWithThumbs: AnalyticsPayload = {
      ...analyticsBase,
      leaderboards: {
        bravo_content: [
          {
            platform: "instagram",
            source_id: "ig-1",
            text: "Official trailer post",
            engagement: 25,
            url: "https://example.com/ig-1",
            timestamp: "2026-01-07T00:00:00Z",
            thumbnail_url: "https://images.test/content-thumb.jpg",
          },
        ],
        viewer_discussion: [
          {
            platform: "instagram",
            source_id: "ig-comment-1",
            text: "Viewer reaction",
            engagement: 11,
            url: "https://example.com/ig-comment-1",
            timestamp: "2026-01-07T00:00:00Z",
            sentiment: "positive",
            thumbnail_url: "https://images.test/discussion-thumb.jpg",
          },
        ],
      },
    };
    mockSeasonSocialFetch(analyticsWithThumbs);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="bravo"
      />,
    );

    expect(await screen.findByText("Bravo Content Leaderboard")).toBeInTheDocument();
    expect(screen.getByAltText("Instagram leaderboard thumbnail")).toHaveAttribute(
      "src",
      "https://images.test/content-thumb.jpg",
    );
    expect(screen.getByAltText("Instagram discussion thumbnail")).toHaveAttribute(
      "src",
      "https://images.test/discussion-thumb.jpg",
    );
  });

  it("canonicalizes legacy hosted leaderboard thumbnails onto the R2 public host before rendering", async () => {
    const analyticsWithLegacyHostedThumbs: AnalyticsPayload = {
      ...analyticsBase,
      leaderboards: {
        bravo_content: [
          {
            platform: "instagram",
            source_id: "ig-legacy-hosted",
            text: "Hosted Instagram card",
            engagement: 25,
            url: "https://example.com/ig-legacy-hosted",
            timestamp: "2026-01-07T00:00:00Z",
            thumbnail_url: "https://d111111abcdef8.cloudfront.net/social/instagram/show/6/week-0/post/thumb.jpg",
          },
        ],
        viewer_discussion: [
          {
            platform: "twitter",
            source_id: "tw-legacy-hosted",
            text: "Hosted discussion card",
            engagement: 11,
            url: "https://example.com/tw-legacy-hosted",
            timestamp: "2026-01-07T00:00:00Z",
            sentiment: "positive",
            thumbnail_url: "https://d111111abcdef8.cloudfront.net/social/twitter/show/6/week-2/post/thumb.jpg",
          },
        ],
      },
    };
    mockSeasonSocialFetch(analyticsWithLegacyHostedThumbs);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="bravo"
      />,
    );

    expect(await screen.findByText("Bravo Content Leaderboard")).toBeInTheDocument();
    expect(screen.getByAltText("Instagram leaderboard thumbnail")).toHaveAttribute(
      "src",
      "https://pub-a3c452f3df0d40319f7c585253a4776c.r2.dev/social/instagram/show/6/week-0/post/thumb.jpg",
    );
    expect(screen.getByAltText("Twitter/X discussion thumbnail")).toHaveAttribute(
      "src",
      "https://pub-a3c452f3df0d40319f7c585253a4776c.r2.dev/social/twitter/show/6/week-2/post/thumb.jpg",
    );
  });

  it("renders video thumbnail placeholders for leaderboard cards instead of broken img tags", async () => {
    const analyticsWithVideoThumbs: AnalyticsPayload = {
      ...analyticsBase,
      leaderboards: {
        bravo_content: [
          {
            platform: "twitter",
            source_id: "tw-1",
            text: "Video clip",
            engagement: 42,
            url: "https://x.com/example/status/1",
            timestamp: "2026-01-07T00:00:00Z",
            thumbnail_url: "https://video.twimg.com/ext_tw_video/12345/pu/vid/avc1/1280x720/main.mp4?tag=12",
          },
        ],
        viewer_discussion: [
          {
            platform: "twitter",
            source_id: "tw-comment-1",
            text: "Quote tweet reaction",
            engagement: 14,
            url: "https://x.com/example/status/2",
            timestamp: "2026-01-07T00:00:00Z",
            sentiment: "positive",
            thumbnail_url: "https://cdn.test/social/twitter/x/thumbnail.mp4",
          },
        ],
      },
    };
    mockSeasonSocialFetch(analyticsWithVideoThumbs);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="bravo"
      />,
    );

    expect(await screen.findByText("Bravo Content Leaderboard")).toBeInTheDocument();
    const leaderboardButton = screen.getByRole("button", { name: "Open leaderboard media lightbox" });
    const discussionButton = screen.getByRole("button", { name: "Open discussion media lightbox" });

    expect(within(leaderboardButton).queryByRole("img")).not.toBeInTheDocument();
    expect(within(discussionButton).queryByRole("img")).not.toBeInTheDocument();
    expect(within(leaderboardButton).getByText("Video")).toBeInTheDocument();
    expect(within(discussionButton).getByText("Video")).toBeInTheDocument();
  });

  it("opens leaderboard media in lightbox and shows social stats in metadata", async () => {
    const analyticsWithThumbs: AnalyticsPayload = {
      ...analyticsBase,
      leaderboards: {
        bravo_content: [
          {
            platform: "instagram",
            source_id: "ig-1",
            text: "Official trailer post",
            engagement: 25,
            url: "https://example.com/ig-1",
            timestamp: "2026-01-07T00:00:00Z",
            thumbnail_url: "https://images.test/content-thumb.jpg",
          },
        ],
        viewer_discussion: [
          {
            platform: "instagram",
            source_id: "ig-comment-1",
            text: "Viewer reaction",
            engagement: 11,
            url: "https://example.com/ig-comment-1",
            timestamp: "2026-01-07T00:00:00Z",
            sentiment: "positive",
            thumbnail_url: "https://images.test/discussion-thumb.jpg",
          },
        ],
      },
    };
    mockSeasonSocialFetch(analyticsWithThumbs);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="bravo"
      />,
    );

    await screen.findByText("Bravo Content Leaderboard");
    fireEvent.click(screen.getByRole("button", { name: "Open leaderboard media lightbox" }));
    fireEvent.click(await screen.findByRole("button", { name: /show metadata|hide metadata/i }));
    const statsHeader = screen.getByText("Social Stats");
    const statsPanel = statsHeader.closest("div");
    expect(statsPanel).not.toBeNull();
    if (statsPanel) {
      expect(within(statsPanel).getByText("Platform")).toBeInTheDocument();
      expect(within(statsPanel).getByText("Engagement")).toBeInTheDocument();
      expect(within(statsPanel).getByText("25")).toBeInTheDocument();
    }
  });

  it("renders season hashtag analytics from week detail posts and respects platform scope", async () => {
    const analyticsWithHashtags: AnalyticsPayload = {
      ...analyticsBase,
    };

    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) {
        return jsonResponse(analyticsWithHashtags);
      }
      const weekDetailMatch = /\/social\/analytics\/week\/(\d+)\?/.exec(url);
      if (weekDetailMatch) {
        const weekIndex = Number(weekDetailMatch[1]);
        if (weekIndex === 1) {
          return jsonResponse({
            platforms: {
              instagram: {
                posts: [
                  {
                    source_id: "ig-w1-1",
                    hashtags: ["RHOSLC", "RHOSLC", "TeamLisa"],
                    text: "Premiere #RHOSLC #RHOSLC #TeamLisa",
                  },
                ],
              },
              youtube: {
                posts: [
                  {
                    source_id: "yt-w1-1",
                    hashtags: ["RHOSLC"],
                    text: "Sneak peek #RHOSLC",
                  },
                ],
              },
              tiktok: { posts: [] },
              twitter: {
                posts: [
                  {
                    source_id: "tw-w1-1",
                    text: "Fans are loud tonight #Drama",
                  },
                ],
              },
            },
          });
        }
        return jsonResponse({
          platforms: {
            instagram: {
              posts: [
                {
                  source_id: "ig-w2-1",
                  hashtags: ["TeamLisa"],
                  text: "Aftershow #TeamLisa",
                },
              ],
            },
            youtube: {
              posts: [
                {
                  source_id: "yt-w2-1",
                  hashtags: ["AFTERSHOW", "RHOSLC"],
                  text: "Weekly recap #AFTERSHOW #RHOSLC",
                },
              ],
            },
            tiktok: { posts: [] },
            twitter: { posts: [] },
          },
        });
      }
      if (url.includes("/social/targets?")) {
        return jsonResponse({
          targets: [
            { platform: "instagram", hashtags: ["rhoslc", "TeamLisa"], accounts: [], is_active: true },
            { platform: "youtube", hashtags: ["rhoslc"], accounts: [], is_active: true },
          ],
        });
      }
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    const { rerender } = render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="hashtags"
        platformTab="overview"
      />,
    );

    await screen.findByRole("heading", { name: "Hashtags" });
    expect(screen.queryByText("Configured Hashtags")).not.toBeInTheDocument();
    await waitFor(() => {
      expect(screen.getByTestId("hashtag-insights-total-uses")).toHaveTextContent("8");
      expect(screen.getByTestId("hashtag-insights-unique-tags")).toHaveTextContent("4");
      expect(screen.getByTestId("hashtag-insights-top-tag")).toHaveTextContent("#RHOSLC");
      expect(screen.getByTestId("hashtag-insights-peak-week")).toHaveTextContent("Week 1");
    });

    const topLeaderboardRow = screen.getByTestId("hashtag-leaderboard-row-0");
    expect(topLeaderboardRow).toHaveTextContent("#RHOSLC");
    expect(topLeaderboardRow).toHaveTextContent("4 uses");
    expect(topLeaderboardRow).toHaveTextContent("50.0%");
    expect(screen.getByTestId("hashtag-weekly-usage-row-1")).toHaveTextContent("5 uses");
    expect(screen.getByTestId("hashtag-platform-usage-row-instagram")).toHaveTextContent("4 uses");
    expect(screen.getByTestId("hashtag-platform-usage-row-youtube")).toHaveTextContent("3 uses");

    rerender(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
        analyticsView="hashtags"
        platformTab="youtube"
      />,
    );

    await screen.findByTestId("hashtag-insights-total-uses");
    await waitFor(() => {
      expect(screen.getByTestId("hashtag-insights-total-uses")).toHaveTextContent("3");
      expect(screen.getByTestId("hashtag-insights-unique-tags")).toHaveTextContent("2");
      expect(screen.getByTestId("hashtag-insights-top-tag")).toHaveTextContent("#RHOSLC");
      expect(screen.getByTestId("hashtag-insights-peak-week")).toHaveTextContent("Week 2");
    });

    const youtubeTopRow = screen.getByTestId("hashtag-leaderboard-row-0");
    expect(youtubeTopRow).toHaveTextContent("#RHOSLC");
    expect(youtubeTopRow).toHaveTextContent("2 uses");
    expect(screen.queryByText("#TEAMLISA")).not.toBeInTheDocument();
    expect(screen.getByTestId("hashtag-platform-usage-row-youtube")).toHaveTextContent("3 uses");

    const weekDetailCalls = fetchMock.mock.calls.filter(([input]) => String(input).includes("/social/analytics/week/"));
    expect(weekDetailCalls.length).toBeGreaterThan(0);
  });

  it("keeps analytics visible when targets fetch fails", async () => {
    // After the snapshot refactor, partial failures (targets fail while analytics
    // succeeds) no longer occur since the snapshot endpoint bundles all data.
    // This test now verifies that analytics data remains visible after an initial
    // successful load, and that the snapshot includes targets as an empty array
    // (representing the backend returning no targets).
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/snapshots/invalidate")) return jsonResponse({ ok: true });
      if (url.includes("/social/analytics/snapshot?")) {
        return jsonResponse(
          buildSnapshotEnvelope(analyticsBase, { targets: [] }),
        );
      }
      if (url.includes("/social/analytics/week/")) {
        return jsonResponse(defaultWeekDetailResponse(1));
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByText("Content Volume");
    const contentVolumeCard = screen.getByText("Content Volume").closest("article");
    expect(contentVolumeCard).not.toBeNull();
    expect(within(contentVolumeCard as HTMLElement).getByText("10")).toBeInTheDocument();
    expect(screen.getByTestId("metric-comments-saved-pct-value")).toHaveTextContent("40.0%");
    expect(screen.getByText("of Comments Saved")).toBeInTheDocument();
    expect(screen.getByTestId("metric-comments-saved-actual-value")).toHaveTextContent("8/20*");
    expect(screen.getByText("Comments (Saved/Actual)")).toBeInTheDocument();
  });

  it("renders runs and targets when analytics request fails", async () => {
    // After the snapshot refactor, the snapshot endpoint bundles all data.
    // A snapshot with null analytics but valid targets and runs verifies
    // that non-analytics sections render even when analytics is absent.
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/snapshots/invalidate")) return jsonResponse({ ok: true });
      if (url.includes("/social/analytics/snapshot?")) {
        return jsonResponse(
          buildSnapshotEnvelope(null, {
            targets: [{ platform: "youtube", accounts: ["bravo"], hashtags: [], keywords: [], is_active: true }],
            runs: [
              {
                id: "run-1-abcdef",
                status: "completed",
                created_at: "2026-02-17T10:00:00Z",
              },
            ],
          }),
        );
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    // With null analytics in the snapshot, the component should still render
    // the targets and runs sections
    await waitFor(() => {
      expect(screen.getByText("Classification Rules")).toBeInTheDocument();
    });
    expect(screen.getByText("YouTube:", { exact: false })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "@bravo" })).toBeInTheDocument();
    const runSelect = screen.getByRole("combobox", { name: /Run/i });
    expect(within(runSelect).getByRole("option", { name: /run-1-ab/i })).toBeInTheDocument();
  });

  it("scopes configured targets to the active platform tab and explains zero-result run logs", async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) {
        return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      }
      if (url.includes("/social/analytics?")) {
        return jsonResponse(analyticsBase);
      }
      const weekDetailMatch = /\/social\/analytics\/week\/(\d+)\?/.exec(url);
      if (weekDetailMatch) {
        return jsonResponse(defaultWeekDetailResponse(Number(weekDetailMatch[1])));
      }
      if (url.includes("/social/targets?")) {
        return jsonResponse({
          targets: [
            { platform: "instagram", accounts: ["bravotv", "bravowwhl"], hashtags: [], keywords: [], is_active: true },
            { platform: "tiktok", accounts: ["bravotv"], hashtags: [], keywords: [], is_active: true },
          ],
        });
      }
      if (url.includes("/social/profiles/")) {
        return jsonResponse({ avatar_url: "https://images.test/avatar.jpg", profile_url: null });
      }
      if (url.includes("/social/runs/summary?")) {
        return jsonResponse({ summaries: [] });
      }
      if (url.includes("/social/runs?")) {
        return jsonResponse({
          runs: [
            {
              id: "run-1-abcdef",
              status: "completed",
              created_at: "2026-03-07T04:56:52Z",
              started_at: "2026-03-07T04:56:54Z",
              completed_at: "2026-03-07T04:57:54Z",
            },
          ],
        });
      }
      if (url.includes("/social/jobs?")) {
        return jsonResponse({
          jobs: [
            {
              id: "job-posts",
              run_id: "run-1-abcdef",
              platform: "instagram",
              job_type: "posts",
              status: "completed",
              items_found: 479,
              created_at: "2026-03-07T04:56:53Z",
              started_at: "2026-03-07T04:56:53Z",
              completed_at: "2026-03-07T04:57:53Z",
              config: { account: "bravotv", stage: "posts" },
              metadata: {
                stage_counters: { posts: 479, comments: 0 },
                persist_counters: { posts_upserted: 0, comments_upserted: 0 },
                activity: { phase: "posts_end", pages_scanned: 40, posts_checked: 479, matched_posts: 0 },
              },
            },
            {
              id: "job-comments",
              run_id: "run-1-abcdef",
              platform: "instagram",
              job_type: "comments",
              status: "completed",
              items_found: 5,
              created_at: "2026-03-07T04:56:54Z",
              started_at: "2026-03-07T04:56:54Z",
              completed_at: "2026-03-07T04:56:57Z",
              config: { account: "bravotv", stage: "comments" },
              metadata: {
                stage_counters: { posts: 5, comments: 0 },
                persist_counters: { posts_upserted: 5, comments_upserted: 0 },
                activity: { phase: "comments_end", pages_scanned: 0, posts_checked: 5, matched_posts: 5 },
                retrieval_meta: { comments_auth_failed: true, incomplete_comment_fetches: 5 },
              },
            },
          ],
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const classificationRulesHeading = await screen.findByText("Classification Rules");
    const classificationRulesCard = classificationRulesHeading.closest("div");
    expect(classificationRulesCard).not.toBeNull();
    const classificationRulesScope = within(classificationRulesCard as HTMLElement);
    expect(classificationRulesScope.getByText("Instagram:", { exact: false })).toBeInTheDocument();
    expect(classificationRulesScope.getAllByRole("link", { name: "@bravotv" })).toHaveLength(2);
    expect(classificationRulesScope.getByRole("link", { name: "@bravowwhl" })).toBeInTheDocument();
    expect(classificationRulesScope.getByText("TikTok:", { exact: false })).toBeInTheDocument();
    fireEvent.change(await screen.findByRole("combobox", { name: "Run" }), {
      target: { value: "run-1-abcdef" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Ingest + Export" }));
    expect(await screen.findByText("Last Run Log")).toBeInTheDocument();
    expect(screen.getByText(/Candidate posts were scanned, but none matched the selected run window\./i)).toBeInTheDocument();
    expect(
      screen.getByText(/Comment fetch was blocked on 5 matched posts by an Instagram auth\/challenge response\./i),
    ).toBeInTheDocument();

    const platformTabs = screen.getByRole("navigation");
    fireEvent.click(within(platformTabs).getByRole("button", { name: platformTabName("Instagram") }));

    await waitFor(() => {
      expect(screen.getByText("Instagram Classification Rules")).toBeInTheDocument();
    });
    const instagramRulesCard = screen.getByText("Instagram Classification Rules").closest("div");
    expect(instagramRulesCard).not.toBeNull();
    expect(within(instagramRulesCard as HTMLElement).getByRole("link", { name: "@bravotv" })).toBeInTheDocument();
    expect(within(instagramRulesCard as HTMLElement).getByRole("link", { name: "@bravowwhl" })).toBeInTheDocument();
  });

  it("exits loading and remains interactive when analytics request times out", async () => {
    // After the snapshot refactor, the component makes a single snapshot request.
    // When it times out (via fetchAdminWithTimeout), the error is caught and
    // displayed as section errors. We simulate this by throwing the timeout
    // message directly from the mock instead of relying on fake timers + abort.
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/snapshots/invalidate")) return jsonResponse({ ok: true });
      if (url.includes("/social/analytics/snapshot?")) {
        throw new Error("Social analytics snapshot request timed out");
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    // The component should exit loading and display the timeout error message.
    // The snapshot error propagates to multiple error slots (section errors,
    // workerHealthError, sharedStatusError, runSummaryError) which each render
    // the message, so use getAllByText to handle multiple matches.
    await waitFor(() => {
      expect(screen.queryByText("Loading social analytics...")).not.toBeInTheDocument();
    });
    const timeoutMatches = screen.getAllByText(/Social analytics snapshot request timed out/i);
    expect(timeoutMatches.length).toBeGreaterThan(0);
  });

  it("defers season secondary reads until primary bootstrap is usable and caps secondary concurrency", async () => {
    // After the snapshot refactor, the component makes a single snapshot request
    // that bundles analytics, targets, runs, run_summaries, worker_health,
    // shared_status, and jobs. There is no separate secondary phase.
    // This test now verifies that the snapshot includes all data in one request
    // and that the component renders "Weekly Trend" after the snapshot resolves.
    let resolveSnapshot: ((value: Response) => void) | null = null;
    const requestedUrls: string[] = [];

    const fetchMock = vi.fn((input: RequestInfo | URL) => {
      const url = String(input);
      requestedUrls.push(url);

      if (url.includes("/snapshots/invalidate")) {
        return Promise.resolve(jsonResponse({ ok: true }));
      }
      if (url.includes("/social/analytics/snapshot?")) {
        return new Promise<Response>((resolve) => {
          resolveSnapshot = resolve;
        });
      }
      if (url.includes("/social/analytics/week/")) {
        return Promise.resolve(jsonResponse(defaultWeekDetailResponse(1)));
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    // Before the snapshot resolves, "Weekly Trend" should not be visible
    await waitFor(() => {
      expect(resolveSnapshot).not.toBeNull();
    });
    expect(screen.queryByText("Weekly Trend")).not.toBeInTheDocument();

    // No separate secondary requests should be issued
    expect(requestedUrls.some((url) => url.includes("/social/runs/summary?"))).toBe(false);
    expect(requestedUrls.some((url) => url.includes("/social/ingest/health-dot"))).toBe(false);
    expect(requestedUrls.some((url) => url.includes("/social/shared-status?"))).toBe(false);

    // Resolve the snapshot with all data bundled
    await act(async () => {
      resolveSnapshot?.(jsonResponse(buildSnapshotEnvelope(analyticsBase)));
    });

    await screen.findByText("Weekly Trend");
  });

  it("includes season_id hint in social landing requests", async () => {
    const requestedUrls: string[] = [];
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      requestedUrls.push(url);
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByTestId("weekly-heatmap-row-1");
    const socialRequests = requestedUrls.filter(
      (url) =>
        url.includes("/social/analytics?") || url.includes("/social/runs?") || url.includes("/social/targets?"),
    );
    expect(socialRequests.length).toBeGreaterThan(0);
    expect(socialRequests.every((url) => url.includes("season_id=season-1"))).toBe(true);
  });

  it("completes the initial load under React StrictMode", async () => {
    const requestedUrls: string[] = [];
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      requestedUrls.push(url);

      if (url.includes("/social/ingest/worker-health")) {
        return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      }
      if (url.includes("/social/analytics?")) {
        return jsonResponse(analyticsBase);
      }
      if (url.includes("/social/targets?")) {
        return jsonResponse({ targets: [] });
      }
      if (url.includes("/social/runs?")) {
        return jsonResponse({ runs: [] });
      }
      if (url.includes("/social/runs/summary?")) {
        return jsonResponse({ summaries: [] });
      }
      if (url.includes("/social/jobs?")) {
        return jsonResponse({ jobs: [] });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <React.StrictMode>
        <SeasonSocialAnalyticsSection
          showId="show-1"
          seasonNumber={6}
          seasonId="season-1"
          showName="Test Show"
        />
      </React.StrictMode>,
    );

    await screen.findByTestId("weekly-heatmap-row-1");
    expect(screen.queryByTestId("social-analytics-skeleton")).not.toBeInTheDocument();
    expect(requestedUrls.some((url) => url.includes("/social/analytics?"))).toBe(true);
  });

  it("shows stale-data timestamp when analytics refresh fails after a successful load", async () => {
    // After the snapshot refactor, the component makes a single snapshot request.
    // The first snapshot succeeds, then switching platform tab triggers a second
    // snapshot request that fails. The component should display the error message
    // alongside a stale-data timestamp while keeping the old data visible.
    let snapshotCalls = 0;
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/snapshots/invalidate")) return jsonResponse({ ok: true });
      if (url.includes("/social/analytics/snapshot?")) {
        snapshotCalls += 1;
        if (snapshotCalls === 1) {
          return jsonResponse(buildSnapshotEnvelope(analyticsBase));
        }
        return {
          ok: false,
          status: 503,
          headers: { get: () => null },
          json: async () => ({ error: "analytics unavailable" }),
        } as Response;
      }
      if (url.includes("/social/analytics/week/")) {
        return jsonResponse(defaultWeekDetailResponse(1));
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", fetchMock as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByTestId("weekly-heatmap-row-1");
    fireEvent.click(screen.getByRole("button", { name: platformTabName("YouTube") }));

    // With the snapshot architecture, a failed snapshot sets the same error message
    // on all four section error slots (analytics, targets, runs, jobs), producing
    // multiple DOM nodes that match /analytics unavailable/i.  Use findAllByText
    // to handle the multiplicity.
    const unavailableMatches = await screen.findAllByText(/analytics unavailable/i);
    expect(unavailableMatches.length).toBeGreaterThan(0);
    // Each surfaced section error with a staleAt anchor renders the stale timestamp;
    // analytics, targets, and runs all have staleAt from the first successful load.
    const staleMatches = await screen.findAllByText(/Showing last successful data from/i);
    expect(staleMatches.length).toBeGreaterThan(0);
    expect(screen.getByTestId("weekly-heatmap-row-1")).toBeInTheDocument();
  });

  it("shows strict run-scoped jobs empty state when no run is selected", async () => {
    mockSeasonSocialFetch(analyticsBase);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    await screen.findByText("Ingest Job Status");
    fireEvent.click(screen.getByRole("button", { name: /Ingest Job Status.*Show/i }));
    expect(
      await screen.findByText("No run selected. Pick a run above or use Ingest + Export to start one."),
    ).toBeInTheDocument();
  });

  it("loads jobs for the selected run id", async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) {
        return jsonResponse(analyticsBase);
      }
      if (url.includes("/social/targets?")) {
        return jsonResponse({ targets: [] });
      }
      if (url.includes("/social/runs?")) {
        return jsonResponse({
          runs: [
            {
              id: "run-1-abcdef",
              status: "completed",
              created_at: "2026-02-17T10:00:00Z",
            },
          ],
        });
      }
      if (url.includes("/social/jobs?")) {
        return jsonResponse({
          jobs: [
            {
              id: "job-1",
              run_id: "run-1-abcdef",
              platform: "instagram",
              status: "completed",
              job_type: "posts",
            },
          ],
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    fireEvent.change(await screen.findByRole("combobox", { name: "Run" }), {
      target: { value: "run-1-abcdef" },
    });

    await waitFor(() => {
      expect(screen.getByRole("combobox", { name: /Run/i })).toHaveValue("run-1-abcdef");
    });

    await waitFor(() => {
      expect(
        fetchMock.mock.calls.some((call) => String(call[0]).includes("run_id=run-1-abcdef")),
      ).toBe(true);
      expect(
        fetchMock.mock.calls.some(
          (call) =>
            String(call[0]).includes("/social/jobs?") && String(call[0]).includes("season_id=season-1"),
        ),
      ).toBe(true);
    });
  });

  it("keeps existing jobs visible when a jobs refresh fails transiently", async () => {
    let failJobsRefresh = false;
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) {
        return jsonResponse(analyticsBase);
      }
      if (url.includes("/social/targets?")) {
        return jsonResponse({ targets: [] });
      }
      if (url.includes("/social/runs?")) {
        return jsonResponse({
          runs: [
            {
              id: "run-1-abcdef",
              status: "completed",
              created_at: "2026-02-17T10:00:00Z",
            },
          ],
        });
      }
      if (url.includes("/social/runs/summary?")) {
        return jsonResponse({ summaries: [] });
      }
      if (url.includes("/social/jobs?")) {
        if (failJobsRefresh) {
          return new Response(JSON.stringify({ error: "temporary jobs outage" }), {
            status: 503,
            headers: { "Content-Type": "application/json" },
          });
        }
        return jsonResponse({
          jobs: [
            {
              id: "job-1",
              run_id: "run-1-abcdef",
              platform: "instagram",
              status: "completed",
              job_type: "posts",
              items_found: 123,
            },
          ],
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    fireEvent.change(await screen.findByRole("combobox", { name: "Run" }, { timeout: 45_000 }), {
      target: { value: "run-1-abcdef" },
    });

    await waitFor(() => {
      expect(screen.getByRole("combobox", { name: /Run/i })).toHaveValue("run-1-abcdef");
      expect(
        fetchMock.mock.calls.some(
          (call) =>
            String(call[0]).includes("/social/jobs?") && String(call[0]).includes("run_id=run-1-abcdef"),
        ),
      ).toBe(true);
    });

    fireEvent.click(screen.getByRole("button", { name: /Ingest Job Status.*Show/i }));
    const jobsSection = screen.getByText("Ingest Job Status").closest("section");
    expect(jobsSection).not.toBeNull();
    const jobsScope = within(jobsSection as HTMLElement);
    fireEvent.click(jobsScope.getByRole("button", { name: "Refresh Jobs" }));
    expect(await jobsScope.findByText("Done", {}, { timeout: 10_000 })).toBeInTheDocument();
    expect(
      jobsScope.getByText((content) => content.includes("123 items") || content.includes("123 posts")),
    ).toBeInTheDocument();

    failJobsRefresh = true;
    fireEvent.click(screen.getByRole("button", { name: "Refresh Jobs" }));

    expect(await screen.findByText(/temporary jobs outage/i, {}, { timeout: 45_000 })).toBeInTheDocument();
    expect(
      jobsScope.getByText((content) => content.includes("123 items") || content.includes("123 posts")),
    ).toBeInTheDocument();
  }, 15_000);

  it("uses incremental sync strategy by default for ingest payload", async () => {
    const runId = "80423aa2-83ae-4f44-8aa4-dd5e8f8d39eb";
    const capturedPayloads: Array<Record<string, unknown>> = [];
    const ingestUrls: string[] = [];
    const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/cast-role-members?")) return jsonResponse([]);
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/runs?")) {
        return jsonResponse({
          runs: [
            {
              id: runId,
              status: "running",
              summary: { total_jobs: 2, completed_jobs: 0, failed_jobs: 0, active_jobs: 2, items_found_total: 0 },
            },
          ],
        });
      }
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes("/social/ingest") && (init?.method ?? "GET") === "POST") {
        ingestUrls.push(url);
        if (typeof init?.body === "string") {
          capturedPayloads.push(JSON.parse(init.body) as Record<string, unknown>);
        }
        return jsonResponse({ run_id: runId, stages: ["posts", "comments"], queued_or_started_jobs: 2 });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    fireEvent.click(await screen.findByRole("button", { name: "Ingest + Export" }));
    fireEvent.click(screen.getByRole("button", { name: /Run Season Sync \(All\)/i }));

    await waitFor(() => {
      expect(capturedPayloads.length).toBeGreaterThan(0);
    });
    expect(capturedPayloads[0]?.sync_strategy).toBe("incremental");
    expect(capturedPayloads[0]?.allow_inline_dev_fallback).toBe(false);
    expect(ingestUrls[0]).toContain("season_id=season-1");
  });

  it("supports day-specific ingest runs", async () => {
    const runId = "80423aa2-83ae-4f44-8aa4-dd5e8f8d39eb";
    const capturedPayloads: Array<Record<string, unknown>> = [];
    const syncSessionId = "44444444-4444-4444-8444-444444444444";
    const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      const weekDetailMatch = /\/social\/analytics\/week\/(\d+)\?/.exec(url);
      if (weekDetailMatch) {
        return jsonResponse(defaultWeekDetailResponse(Number(weekDetailMatch[1])));
      }
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes(`/social/sync-sessions/${syncSessionId}/stream`)) {
        return syncSessionStreamResponse({
          sync_session: {
            sync_session_id: syncSessionId,
            season_id: "season-1",
            status: "pass_running",
            current_pass_kind: "posts_and_comments",
            current_pass_attempt: 1,
            current_run_id: runId,
            pass_sequence: 1,
            completeness_snapshot: { up_to_date: false },
            current_run: { id: runId, status: "running", summary: { total_jobs: 2 } },
          },
          run_progress: null,
        });
      }
      if (url.includes(`/social/sync-sessions/${syncSessionId}`)) {
        return jsonResponse({
          sync_session_id: syncSessionId,
          season_id: "season-1",
          status: "pass_running",
          current_pass_kind: "posts_and_comments",
          current_pass_attempt: 1,
          current_run_id: runId,
          pass_sequence: 1,
          completeness_snapshot: { up_to_date: false },
          current_run: { id: runId, status: "running", summary: { total_jobs: 2 } },
        });
      }
      if (url.includes("/social/sync-sessions") && (init?.method ?? "GET") === "POST") {
        if (typeof init?.body === "string") {
          capturedPayloads.push(JSON.parse(init.body) as Record<string, unknown>);
        }
        return jsonResponse({
          status: "created",
          sync_session_id: syncSessionId,
          current_pass_kind: "posts_and_comments",
          current_pass_attempt: 1,
          current_run_id: runId,
          completeness_snapshot: { up_to_date: false },
          current_run: { id: runId, status: "running", summary: { total_jobs: 2 } },
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    fireEvent.click(await screen.findByRole("button", { name: "Ingest + Export" }));
    await screen.findByText("Daily Run");
    fireEvent.change(screen.getByLabelText(/Day/i), {
      target: { value: "2026-01-09" },
    });
    fireEvent.click(screen.getByRole("button", { name: /Run Selected Day/i }));

    await waitFor(() => {
      expect(capturedPayloads.length).toBeGreaterThan(0);
    });
    const dayPayload = capturedPayloads[0];
    expect(typeof dayPayload.date_start).toBe("string");
    expect(typeof dayPayload.date_end).toBe("string");
    const start = new Date(String(dayPayload.date_start));
    const end = new Date(String(dayPayload.date_end));
    expect(Number.isNaN(start.getTime())).toBe(false);
    expect(Number.isNaN(end.getTime())).toBe(false);
    expect(start.toISOString()).toBe("2026-01-09T05:00:00.000Z");
    expect(end.toISOString()).toBe("2026-01-10T04:59:59.999Z");
    expect(end.getTime()).toBeGreaterThan(start.getTime());
    expect(end.getTime() - start.getTime()).toBeLessThanOrEqual(24 * 60 * 60 * 1000);
  });

  it("supports week-specific platform ingest runs from Ingest + Export", async () => {
    const runId = "run-week-platform-1";
    const capturedPayloads: Array<Record<string, unknown>> = [];
    const syncSessionId = "88888888-8888-4888-8888-888888888888";
    const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes(`/social/sync-sessions/${syncSessionId}/stream`)) {
        return syncSessionStreamResponse({
          sync_session: {
            sync_session_id: syncSessionId,
            season_id: "season-1",
            status: "pass_running",
            current_pass_kind: "posts_and_comments",
            current_pass_attempt: 1,
            current_run_id: runId,
            pass_sequence: 1,
            completeness_snapshot: { up_to_date: false },
            current_run: { id: runId, status: "running", summary: { total_jobs: 2 } },
          },
          run_progress: null,
        });
      }
      if (url.includes(`/social/sync-sessions/${syncSessionId}`)) {
        return jsonResponse({
          sync_session_id: syncSessionId,
          season_id: "season-1",
          status: "pass_running",
          current_pass_kind: "posts_and_comments",
          current_pass_attempt: 1,
          current_run_id: runId,
          pass_sequence: 1,
          completeness_snapshot: { up_to_date: false },
          current_run: { id: runId, status: "running", summary: { total_jobs: 2 } },
        });
      }
      if (url.includes("/social/sync-sessions") && (init?.method ?? "GET") === "POST") {
        if (typeof init?.body === "string") {
          capturedPayloads.push(JSON.parse(init.body) as Record<string, unknown>);
        }
        return jsonResponse({
          status: "created",
          sync_session_id: syncSessionId,
          current_pass_kind: "posts_and_comments",
          current_pass_attempt: 1,
          current_run_id: runId,
          completeness_snapshot: { up_to_date: false },
          current_run: { id: runId, status: "running", summary: { total_jobs: 2 } },
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    fireEvent.click(await screen.findByRole("button", { name: "Ingest + Export" }));
    await screen.findByText("Weekly Run");
    fireEvent.change(screen.getByRole("combobox", { name: /^Week$/i }), {
      target: { value: "2" },
    });
    const platformSelects = screen.getAllByRole("combobox", { name: /Platform/i });
    fireEvent.change(platformSelects[0], { target: { value: "youtube" } });
    fireEvent.click(screen.getByRole("button", { name: /Run Selected Week/i }));

    await waitFor(() => {
      expect(capturedPayloads.length).toBeGreaterThan(0);
    });
    const payload = capturedPayloads[0];
    expect(payload.platforms).toEqual(["youtube"]);
    expect(payload.date_start).toBe("2026-01-14T00:00:00Z");
    expect(payload.date_end).toBe("2026-01-20T23:59:59Z");
  });

  it("sends full_refresh strategy when full refresh mode is selected", async () => {
    const runId = "80423aa2-83ae-4f44-8aa4-dd5e8f8d39eb";
    const capturedPayloads: Array<Record<string, unknown>> = [];
    const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/cast-role-members?")) return jsonResponse([]);
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes("/social/ingest") && (init?.method ?? "GET") === "POST") {
        if (typeof init?.body === "string") {
          capturedPayloads.push(JSON.parse(init.body) as Record<string, unknown>);
        }
        return jsonResponse({ run_id: runId, stages: ["posts", "comments"], queued_or_started_jobs: 2 });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    fireEvent.click(await screen.findByRole("button", { name: "Ingest + Export" }));
    await screen.findByText("Sync Mode");
    fireEvent.change(screen.getByRole("combobox", { name: /Sync Mode/i }), {
      target: { value: "full_refresh" },
    });
    fireEvent.click(screen.getByRole("button", { name: /Run Season Sync \(All\)/i }));

    await waitFor(() => {
      expect(capturedPayloads.length).toBeGreaterThan(0);
    });
    expect(capturedPayloads[0]?.sync_strategy).toBe("full_refresh");
    expect(capturedPayloads[0]?.allow_inline_dev_fallback).toBe(false);
  });

  it("uses Sync X label when twitter platform filter is active", async () => {
    mockSeasonSocialFetch(analyticsBase);
    window.history.replaceState({}, "", "/shows/show-1/s6/social/official?social_platform=twitter");

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const weekOneRow = (await screen.findByRole("link", { name: /S6\.E1/i })).closest("tr");
    expect(weekOneRow).not.toBeNull();
    expect(within(weekOneRow as HTMLElement).getByRole("button", { name: "Sync X" })).toBeInTheDocument();
  });

  it("Sync Instagram sends uncapped comment and reply limits for the selected window", async () => {
    const runId = "run-instagram-uncapped";
    const capturedPayloads: Array<Record<string, unknown>> = [];
    const syncSessionId = "55555555-5555-4555-8555-555555555555";
    const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/social/analytics/week/")) return jsonResponse(defaultWeekDetailResponse(1));
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes(`/social/sync-sessions/${syncSessionId}/stream`)) {
        return syncSessionStreamResponse({
          sync_session: {
            sync_session_id: syncSessionId,
            season_id: "season-1",
            status: "pass_running",
            current_pass_kind: "posts_and_comments",
            current_pass_attempt: 1,
            current_run_id: runId,
            pass_sequence: 1,
            completeness_snapshot: { up_to_date: false },
            current_run: { id: runId, status: "running", summary: { total_jobs: 2 } },
          },
          run_progress: null,
        });
      }
      if (url.includes(`/social/sync-sessions/${syncSessionId}`)) {
        return jsonResponse({
          sync_session_id: syncSessionId,
          season_id: "season-1",
          status: "pass_running",
          current_pass_kind: "posts_and_comments",
          current_pass_attempt: 1,
          current_run_id: runId,
          pass_sequence: 1,
          completeness_snapshot: { up_to_date: false },
          current_run: { id: runId, status: "running", summary: { total_jobs: 2 } },
        });
      }
      if (url.includes("/social/sync-sessions") && (init?.method ?? "GET") === "POST") {
        if (typeof init?.body === "string") {
          capturedPayloads.push(JSON.parse(init.body) as Record<string, unknown>);
        }
        return jsonResponse({
          status: "created",
          sync_session_id: syncSessionId,
          current_pass_kind: "posts_and_comments",
          current_pass_attempt: 1,
          current_run_id: runId,
          completeness_snapshot: { up_to_date: false },
          current_run: { id: runId, status: "running", summary: { total_jobs: 2 } },
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);
    window.history.replaceState({}, "", "/shows/show-1/s6/social/official?social_platform=instagram");

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const weekOneRow = (await screen.findByRole("link", { name: /S6\.E1/i })).closest("tr");
    expect(weekOneRow).not.toBeNull();
    fireEvent.click(within(weekOneRow as HTMLElement).getByRole("button", { name: "Sync Instagram" }));

    await waitFor(() => {
      expect(capturedPayloads.length).toBeGreaterThan(0);
    });

    const payload = capturedPayloads[0];
    expect(payload.platforms).toEqual(["instagram"]);
    expect(payload.max_posts_per_target).toBe(0);
    expect(payload.max_comments_per_post).toBe(0);
    expect(payload.max_replies_per_post).toBe(0);
    expect(payload.date_start).toBe("2026-01-07T00:00:00Z");
    expect(payload.date_end).toBe("2026-01-13T23:59:59Z");
  });

  it("Sync All triggers posts_and_comments ingest for the selected week", async () => {
    const runId = "80423aa2-83ae-4f44-8aa4-dd5e8f8d39eb";
    const capturedPayloads: Array<Record<string, unknown>> = [];
    const ingestUrls: string[] = [];
    const syncSessionId = "66666666-6666-4666-8666-666666666666";
    const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/social/analytics/week/")) return jsonResponse(defaultWeekDetailResponse(1));
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes(`/social/sync-sessions/${syncSessionId}/stream`)) {
        return syncSessionStreamResponse({
          sync_session: {
            sync_session_id: syncSessionId,
            season_id: "season-1",
            status: "pass_running",
            current_pass_kind: "posts_and_comments",
            current_pass_attempt: 1,
            current_run_id: runId,
            pass_sequence: 1,
            completeness_snapshot: { up_to_date: false },
            current_run: { id: runId, status: "running", summary: { total_jobs: 2 } },
          },
          run_progress: null,
        });
      }
      if (url.includes(`/social/sync-sessions/${syncSessionId}`)) {
        return jsonResponse({
          sync_session_id: syncSessionId,
          season_id: "season-1",
          status: "pass_running",
          current_pass_kind: "posts_and_comments",
          current_pass_attempt: 1,
          current_run_id: runId,
          pass_sequence: 1,
          completeness_snapshot: { up_to_date: false },
          current_run: { id: runId, status: "running", summary: { total_jobs: 2 } },
        });
      }
      if (url.includes("/social/sync-sessions") && (init?.method ?? "GET") === "POST") {
        ingestUrls.push(url);
        if (typeof init?.body === "string") {
          capturedPayloads.push(JSON.parse(init.body) as Record<string, unknown>);
        }
        return jsonResponse({
          status: "created",
          sync_session_id: syncSessionId,
          current_pass_kind: "posts_and_comments",
          current_pass_attempt: 1,
          current_run_id: runId,
          completeness_snapshot: { up_to_date: false },
          current_run: { id: runId, status: "running", summary: { total_jobs: 2 } },
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const weekOneRow = (await screen.findByRole("link", { name: /S6\.E1/i })).closest("tr");
    expect(weekOneRow).not.toBeNull();
    const syncButton = within(weekOneRow as HTMLElement).getByRole("button", { name: "Sync All" });
    fireEvent.click(syncButton);

    await waitFor(() => {
      expect(capturedPayloads.length).toBeGreaterThan(0);
    });

    const payload = capturedPayloads[0];
    expect(payload.sync_strategy).toBe("incremental");
    expect(payload.date_start).toBe("2026-01-07T00:00:00Z");
    expect(payload.date_end).toBe("2026-01-13T23:59:59Z");
    expect(payload.platforms).toBeUndefined();
    expect(ingestUrls[0]).toContain("season_id=season-1");
  });

  it("Sync All does not short-circuit when comments are already up-to-date", async () => {
    const capturedPayloads: Array<Record<string, unknown>> = [];
    const syncSessionId = "77777777-7777-4777-8777-777777777777";
    const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/social/analytics/week/")) return jsonResponse(defaultWeekDetailResponse(1));
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/runs?")) return jsonResponse({ runs: [] });
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes(`/social/sync-sessions/${syncSessionId}/stream`)) {
        return syncSessionStreamResponse({
          sync_session: {
            sync_session_id: syncSessionId,
            season_id: "season-1",
            status: "pass_running",
            current_pass_kind: "posts_and_comments",
            current_pass_attempt: 1,
            current_run_id: "run-sync-metrics",
            pass_sequence: 1,
            completeness_snapshot: { up_to_date: false },
            current_run: { id: "run-sync-metrics", status: "running", summary: { total_jobs: 1 } },
          },
          run_progress: null,
        });
      }
      if (url.includes(`/social/sync-sessions/${syncSessionId}`)) {
        return jsonResponse({
          sync_session_id: syncSessionId,
          season_id: "season-1",
          status: "pass_running",
          current_pass_kind: "posts_and_comments",
          current_pass_attempt: 1,
          current_run_id: "run-sync-metrics",
          pass_sequence: 1,
          completeness_snapshot: { up_to_date: false },
          current_run: { id: "run-sync-metrics", status: "running", summary: { total_jobs: 1 } },
        });
      }
      if (url.includes("/social/sync-sessions") && (init?.method ?? "GET") === "POST") {
        if (typeof init?.body === "string") {
          capturedPayloads.push(JSON.parse(init.body) as Record<string, unknown>);
        }
        return jsonResponse({
          status: "created",
          sync_session_id: syncSessionId,
          current_pass_kind: "posts_and_comments",
          current_pass_attempt: 1,
          current_run_id: "run-sync-metrics",
          completeness_snapshot: { up_to_date: false },
          current_run: { id: "run-sync-metrics", status: "running", summary: { total_jobs: 1 } },
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const weekOneRow = (await screen.findByRole("link", { name: /S6\.E1/i })).closest("tr");
    expect(weekOneRow).not.toBeNull();
    const syncButton = within(weekOneRow as HTMLElement).getByRole("button", { name: "Sync All" });
    fireEvent.click(syncButton);

    await waitFor(() => {
      expect(capturedPayloads).toHaveLength(1);
    });
    expect(capturedPayloads[0]?.date_start).toBe("2026-01-07T00:00:00Z");
    expect(capturedPayloads[0]?.date_end).toBe("2026-01-13T23:59:59Z");
  });

  it("formats worker-unavailable proxy detail into actionable guidance", () => {
    const message = formatIngestErrorMessage({
      error: "Failed to run social ingest (SOCIAL_WORKER_UNAVAILABLE)",
      code: "UPSTREAM_ERROR",
      upstream_status: 503,
      upstream_detail_code: "SOCIAL_WORKER_UNAVAILABLE",
      upstream_detail: {
        code: "SOCIAL_WORKER_UNAVAILABLE",
        message: "No healthy social ingest workers are reporting heartbeats.",
        worker_health: { healthy: false, reason: "no_healthy_workers" },
      },
    });

    expect(message).toContain("Start the remote social executor and retry");
    expect(message).toContain("no_healthy_workers");
  });

  it("formats remote-worker-required proxy detail into remote executor guidance", () => {
    const message = formatIngestErrorMessage({
      error: "Failed to run social ingest (SOCIAL_REMOTE_WORKER_REQUIRED)",
      code: "UPSTREAM_ERROR",
      upstream_status: 503,
      upstream_detail_code: "SOCIAL_REMOTE_WORKER_REQUIRED",
      upstream_detail: {
        code: "SOCIAL_REMOTE_WORKER_REQUIRED",
        message: "Remote worker execution is required for platform(s): instagram",
        required_platforms: ["instagram"],
      },
    });

    expect(message).toContain("remote-only");
    expect(message).toContain("configured remote executor");
  });

  it("merges preview platform statuses without hiding active comment runs behind stale mirror state", () => {
    const statuses = buildPreviewPlatformStatuses(
      {
        season_id: "season-1",
        show_id: "show-1",
        season_number: 6,
        source_scope: "bravo",
        platforms: ["instagram"],
        window: { start: "2026-01-01T00:00:00Z", end: "2026-01-07T00:00:00Z", timezone: "America/New_York" },
        total_saved_comments: 0,
        total_reported_comments: 10,
        coverage_pct: 0,
        up_to_date: false,
        stale_posts_count: 1,
        posts_scanned: 1,
        by_platform: {
          instagram: {
            saved_comments: 0,
            reported_comments: 10,
            coverage_pct: 0,
            up_to_date: false,
            stale_posts_count: 1,
            posts_scanned: 1,
            sync_status: "running",
            comment_sync_status: {
              status: "running",
              expected_count: 10,
              fetched_count: 0,
              upserted_count: 0,
              failure_reason: "instagram_comment_gap",
            },
            media_mirror_status: {
              status: "not_needed",
              source_count: 0,
              mirrored_count: 0,
            },
            stale: false,
            active_job_summary: {
              sync_status: "running",
              dominant_stage: "comments",
              job_count: 2,
              stage_statuses: { comments: { status: "running", job_count: 2 } },
            },
          },
        },
        evaluated_at: "2026-01-07T12:00:00Z",
        sync_status: "running",
        comment_sync_status: { status: "running", expected_count: 10, fetched_count: 0, upserted_count: 0 },
        media_mirror_status: { status: "not_needed", source_count: 0, mirrored_count: 0 },
        stale: false,
      },
      {
        season_id: "season-1",
        show_id: "show-1",
        season_number: 6,
        source_scope: "bravo",
        platforms: ["instagram"],
        window: { start: "2026-01-01T00:00:00Z", end: "2026-01-07T00:00:00Z", timezone: "America/New_York" },
        posts_scanned: 1,
        needs_mirror_count: 1,
        mirrored_count: 0,
        failed_count: 0,
        partial_count: 1,
        pending_count: 0,
        by_platform: {
          instagram: {
            posts_scanned: 1,
            needs_mirror_count: 1,
            mirrored_count: 0,
            failed_count: 0,
            partial_count: 1,
            pending_count: 0,
            sync_status: "partial",
            comment_sync_status: {
              status: "idle",
              expected_count: 0,
              fetched_count: 0,
              upserted_count: 0,
            },
            media_mirror_status: {
              status: "partial",
              source_count: 1,
              mirrored_count: 0,
              pending_count: 0,
              failed_count: 0,
              partial_count: 1,
              failure_reason: "instagram_post_media_mirror_gap",
            },
            stale: true,
            last_refresh_reason: "instagram_post_media_mirror_gap",
          },
        },
        evaluated_at: "2026-01-07T12:00:00Z",
        sync_status: "partial",
        comment_sync_status: { status: "idle", expected_count: 0, fetched_count: 0, upserted_count: 0 },
        media_mirror_status: { status: "partial", source_count: 1, mirrored_count: 0, partial_count: 1 },
        stale: true,
      },
    );

    const instagram = statuses.find((entry) => entry.platform === "instagram");
    expect(instagram?.status.sync_status).toBe("running");
    expect(instagram?.status.stale).toBe(false);
    expect(instagram?.status.active_job_summary?.dominant_stage).toBe("comments");
    expect(instagram?.status.last_refresh_reason).toBe("instagram_comment_gap");
  });

  it("formats posts-stage zero-scan outcomes with auth, rate-limit, and provider-specific guidance", () => {
    expect(
      formatJobOutcomeNote({
        id: "job-auth",
        platform: "instagram",
        status: "failed",
        job_type: "posts",
        job_error_code: "AUTH",
        metadata: {
          activity: { posts_checked: 0 },
          stage_counters: { posts: 0, comments: 0 },
          persist_counters: { posts_upserted: 0, comments_upserted: 0 },
          retrieval_meta: { comment_fail_reasons: ["auth_required"] },
        },
      } as never),
    ).toContain("authentication or checkpoint verification");

    expect(
      formatJobOutcomeNote({
        id: "job-rate",
        platform: "tiktok",
        status: "failed",
        job_type: "posts",
        job_error_code: "RATE_LIMIT",
        metadata: {
          activity: { posts_checked: 0 },
          stage_counters: { posts: 0, comments: 0 },
          persist_counters: { posts_upserted: 0, comments_upserted: 0 },
          retrieval_meta: { comment_fail_reasons: ["rate_limited"] },
        },
      } as never),
    ).toContain("throttled this shard");

    expect(
      formatJobOutcomeNote({
        id: "job-provider",
        platform: "twitter",
        status: "failed",
        job_type: "posts",
        job_error_code: "UPSTREAM_ERROR",
        error_message: "provider exploded",
        metadata: {
          activity: { posts_checked: 0 },
          stage_counters: { posts: 0, comments: 0 },
          persist_counters: { posts_upserted: 0, comments_upserted: 0 },
        },
      } as never),
    ).toContain("provider failed before any posts were scanned");
  });

  it("renders rich run labels in the run selector", async () => {
    const runId = "80423aa2-83ae-4f44-8aa4-dd5e8f8d39eb";
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) {
        return jsonResponse(analyticsBase);
      }
      if (url.includes("/social/targets?")) {
        return jsonResponse({ targets: [] });
      }
      if (url.includes("/social/jobs?")) {
        return jsonResponse({ jobs: [] });
      }
      if (url.includes("/social/runs?")) {
        return jsonResponse({
          runs: [
            {
              id: runId,
              status: "running",
              created_at: "2026-02-17T19:57:13Z",
              config: {
                date_start: "2026-01-07T00:00:00Z",
                date_end: "2026-01-13T23:59:59Z",
                platforms: "all",
              },
              summary: {
                total_jobs: 8,
                completed_jobs: 1,
                failed_jobs: 0,
                active_jobs: 7,
                items_found_total: 0,
              },
            },
          ],
        });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    const runSelect = await screen.findByRole("combobox", { name: /Run/i });
    const matchingOption = await within(runSelect).findByRole("option", { name: /80423aa2/i });
    expect(matchingOption.textContent).toContain("Week 1");
    expect(matchingOption.textContent).toContain("All Platforms");
    expect(matchingOption.textContent).toContain("Running 1/8");
    expect(matchingOption.textContent).toContain("0 items");
  });

  it("does not emit false completion while run status remains active with transient empty jobs", async () => {
    const runId = "80423aa2-83ae-4f44-8aa4-dd5e8f8d39eb";
    let runJobsCalls = 0;
    const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = String(input);

      if (url.includes("/social/ingest/worker-health")) return jsonResponse({ queue_enabled: false, healthy: true, healthy_workers: 1, reason: null });
      if (url.includes("/social/analytics?")) return jsonResponse(analyticsBase);
      if (url.includes("/cast-role-members?")) return jsonResponse([]);
      if (url.includes("/social/targets?")) return jsonResponse({ targets: [] });
      if (url.includes("/social/runs?")) {
        return jsonResponse({
          runs: [
            {
              id: runId,
              status: "running",
              summary: {
                total_jobs: 8,
                completed_jobs: 1,
                failed_jobs: 0,
                active_jobs: 7,
                items_found_total: 0,
              },
            },
          ],
        });
      }
      if (url.includes("/social/jobs?") && url.includes(`run_id=${runId}`)) {
        runJobsCalls += 1;
        if (runJobsCalls === 1) {
          return jsonResponse({
            jobs: [
              {
                id: "job-1",
                run_id: runId,
                platform: "instagram",
                status: "running",
                job_type: "posts",
              },
            ],
          });
        }
        return jsonResponse({ jobs: [] });
      }
      if (url.includes("/social/jobs?")) return jsonResponse({ jobs: [] });
      if (url.includes("/social/ingest") && (init?.method ?? "GET") === "POST") {
        return jsonResponse({ run_id: runId, stages: ["posts", "comments"], queued_or_started_jobs: 8 });
      }
      throw new Error(`Unexpected fetch URL: ${url}`);
    });
    vi.stubGlobal("fetch", wrapWithSnapshotSupport(fetchMock) as unknown as typeof fetch);

    render(
      <SeasonSocialAnalyticsSection
        showId="show-1"
        seasonNumber={6}
        seasonId="season-1"
        showName="Test Show"
      />,
    );

    fireEvent.click(await screen.findByRole("button", { name: "Ingest + Export" }));
    vi.useFakeTimers();
    fireEvent.click(screen.getByRole("button", { name: /Run Season Sync \(All\)/i }));

    await act(async () => {
      await vi.advanceTimersByTimeAsync(3000);
    });
    expect(runJobsCalls).toBeGreaterThan(0);
    expect(
      fetchMock.mock.calls.some(
        (call) =>
          String(call[0]).includes("/social/runs?") && String(call[0]).includes(`run_id=${runId}`),
      ),
    ).toBe(true);

    await act(async () => {
      await vi.advanceTimersByTimeAsync(7000);
    });
    expect(screen.queryByText(/Ingest complete/i)).not.toBeInTheDocument();
  });
});
