import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

describe("person gallery thumbnail wiring", () => {
  it("uses 3:4 cards and computed thumbnail positioning", () => {
    const filePath = path.resolve(
      __dirname,
      "../src/app/admin/trr-shows/people/[personId]/PersonPageClient.tsx",
    );
    const contents = fs.readFileSync(filePath, "utf8");

    const aspectCount = contents.match(/aspect-\[3\/4\]/g)?.length ?? 0;
    expect(aspectCount).toBeGreaterThanOrEqual(2);
    expect(contents).toMatch(/resolveThumbnailPresentation\(/);
    expect(contents).toMatch(/objectPosition:\s*presentation\.objectPosition/);
    expect(contents).toMatch(/transform:\s*presentation\.zoom/);
    expect(contents).toMatch(/object-cover/);
    expect(contents).toMatch(/cursor-zoom-in/);
    expect(contents).toMatch(/select-none/);
    expect(contents).not.toMatch(/exactViewportStyle/);
  });

  it("uses candidate-based URL resolution for detail views", () => {
    const filePath = path.resolve(
      __dirname,
      "../src/app/admin/trr-shows/people/[personId]/PersonPageClient.tsx",
    );
    const contents = fs.readFileSync(filePath, "utf8");

    expect(contents).toMatch(
      /getPersonPhotoDetailUrl[\s\S]*firstImageUrlCandidate\(getPersonPhotoDetailUrlCandidates\(photo\)\)/,
    );
    expect(contents).toMatch(/const cardCandidates = useMemo\(\(\) => getPersonPhotoCardUrlCandidates\(photo\), \[photo\]\)/);
  });
});
