import { beforeEach, describe, expect, it, vi } from "vitest";
import { captureExpectedConsoleWarn } from "./helpers/expected-console";

const {
  getCoveredShowsMock,
  listPrimaryPersonExternalIdsByPersonIdsMock,
  listEffectivePersonSocialHandlesByPersonIdsMock,
  listShowExternalIdsByIdsMock,
  listRedditCommunitiesMock,
  loadSharedAccountSourcesFromBackendMock,
  fetchSocialBackendJsonMock,
  fetchAdminBackendJsonMock,
  queryMock,
} = vi.hoisted(() => ({
  getCoveredShowsMock: vi.fn(),
  listPrimaryPersonExternalIdsByPersonIdsMock: vi.fn(),
  listEffectivePersonSocialHandlesByPersonIdsMock: vi.fn(),
  listShowExternalIdsByIdsMock: vi.fn(),
  listRedditCommunitiesMock: vi.fn(),
  loadSharedAccountSourcesFromBackendMock: vi.fn(),
  fetchSocialBackendJsonMock: vi.fn(),
  fetchAdminBackendJsonMock: vi.fn(),
  queryMock: vi.fn(),
}));

vi.mock("@/lib/server/admin/covered-shows-repository", () => ({
  getCoveredShows: getCoveredShowsMock,
}));

vi.mock("@/lib/server/trr-api/trr-shows-repository", () => ({
  listEffectivePersonSocialHandlesByPersonIds:
    listEffectivePersonSocialHandlesByPersonIdsMock,
}));

vi.mock("@/lib/server/trr-api/admin-external-id-reads", () => ({
  listPrimaryPersonExternalIdsByPersonIds: listPrimaryPersonExternalIdsByPersonIdsMock,
  listShowExternalIdsByIds: listShowExternalIdsByIdsMock,
}));

vi.mock("@/lib/server/trr-api/social-admin-proxy", () => ({
  fetchSocialBackendJson: fetchSocialBackendJsonMock,
  SOCIAL_PROXY_DEFAULT_TIMEOUT_MS: 25_000,
  SOCIAL_PROXY_PROGRESS_TIMEOUT_MS: 30_000,
}));

vi.mock("@/lib/server/admin/reddit-sources-repository", () => ({
  listRedditCommunities: listRedditCommunitiesMock,
}));

vi.mock("@/lib/server/admin/shared-account-sources", () => ({
  loadSharedAccountSourcesFromBackend: loadSharedAccountSourcesFromBackendMock,
}));

vi.mock("@/lib/server/trr-api/admin-read-proxy", () => ({
  ADMIN_READ_PROXY_SHORT_TIMEOUT_MS: 5_000,
  fetchAdminBackendJson: fetchAdminBackendJsonMock,
}));

vi.mock("@/lib/server/postgres", () => ({
  query: queryMock,
  queryWithStatementTimeout: queryMock,
}));

import {
  getSocialLandingPayload,
  getSocialLandingPayloadResult,
} from "@/lib/server/admin/social-landing-repository";

const delay = (ms: number) =>
  new Promise<void>((resolve) => {
    setTimeout(resolve, ms);
  });

const findSocialBladeGrowthDataQueryCall = (): [string, unknown[]] => {
  const call = queryMock.mock.calls.find(([sql]) =>
    String(sql).includes("FROM pipeline.socialblade_growth_data"),
  );
  if (!call) {
    throw new Error("Expected pipeline.socialblade_growth_data query");
  }
  return call as [string, unknown[]];
};

describe("social landing repository", () => {
  beforeEach(() => {
    getCoveredShowsMock.mockReset();
    listPrimaryPersonExternalIdsByPersonIdsMock.mockReset();
    listEffectivePersonSocialHandlesByPersonIdsMock.mockReset();
    listShowExternalIdsByIdsMock.mockReset();
    listRedditCommunitiesMock.mockReset();
    loadSharedAccountSourcesFromBackendMock.mockReset();
    fetchSocialBackendJsonMock.mockReset();
    fetchAdminBackendJsonMock.mockReset();
    queryMock.mockReset();

    getCoveredShowsMock.mockResolvedValue([
      {
        id: "covered-1",
        trr_show_id: "show-rhoslc",
        show_name: "The Real Housewives of Salt Lake City",
        canonical_slug: "the-real-housewives-of-salt-lake-city",
        alternative_names: ["RHOSLC"],
        show_total_episodes: 100,
        created_at: "2026-01-01T00:00:00Z",
        created_by_firebase_uid: "admin",
      },
      {
        id: "covered-2",
        trr_show_id: "show-wwhl",
        show_name: "Watch What Happens Live with Andy Cohen",
        canonical_slug: "watch-what-happens-live-with-andy-cohen",
        alternative_names: ["WWHL"],
        show_total_episodes: 1000,
        created_at: "2026-01-01T00:00:00Z",
        created_by_firebase_uid: "admin",
      },
    ]);

    listRedditCommunitiesMock.mockResolvedValue([
      {
        id: "community-1",
        trr_show_id: "show-rhoslc",
        trr_show_name: "The Real Housewives of Salt Lake City",
        subreddit: "BravoRealHousewives",
        display_name: "Bravo RH",
        notes: null,
        post_flairs: [],
        analysis_flairs: [],
        analysis_all_flairs: [],
        is_show_focused: false,
        network_focus_targets: [],
        franchise_focus_targets: [],
        episode_title_patterns: [],
        post_flair_categories: {},
        post_flairs_updated_at: null,
        is_active: true,
        created_by_firebase_uid: "admin",
        created_at: "2026-01-01T00:00:00Z",
        updated_at: "2026-01-01T00:00:00Z",
      },
      {
        id: "community-2",
        trr_show_id: "show-wwhl",
        trr_show_name: "Watch What Happens Live with Andy Cohen",
        subreddit: "WWHL",
        display_name: null,
        notes: null,
        post_flairs: [],
        analysis_flairs: [],
        analysis_all_flairs: [],
        is_show_focused: false,
        network_focus_targets: [],
        franchise_focus_targets: [],
        episode_title_patterns: [],
        post_flair_categories: {},
        post_flairs_updated_at: null,
        is_active: true,
        created_by_firebase_uid: "admin",
        created_at: "2026-01-01T00:00:00Z",
        updated_at: "2026-01-01T00:00:00Z",
      },
      {
        id: "community-3",
        trr_show_id: "show-wwhl",
        trr_show_name: "Watch What Happens Live with Andy Cohen",
        subreddit: "AndyCohenArchive",
        display_name: null,
        notes: null,
        post_flairs: [],
        analysis_flairs: [],
        analysis_all_flairs: [],
        is_show_focused: false,
        network_focus_targets: [],
        franchise_focus_targets: [],
        episode_title_patterns: [],
        post_flair_categories: {},
        post_flairs_updated_at: null,
        is_active: false,
        created_by_firebase_uid: "admin",
        created_at: "2026-01-01T00:00:00Z",
        updated_at: "2026-01-01T00:00:00Z",
      },
    ]);

    fetchSocialBackendJsonMock.mockImplementation(async (path: string) => {
      if (path === "/landing-scrape-job-health") {
        return {
          window_hours: 8,
          window_started_at: null,
          generated_at: null,
          total_jobs: 0,
          active_jobs: 0,
          failed_jobs: 0,
          failure_signal_jobs: 0,
          in_failed_sql_transaction_hits: 0,
          latest_failure_at: null,
        };
      }

      if (path === "/landing-progress-rollup") {
        return { rows: [] };
      }

      if (path === "/landing-socialblade-progress-counts") {
        return { rows: [] };
      }

      if (path === "/landing-socialblade-rows") {
        const options = fetchSocialBackendJsonMock.mock.calls.at(-1)?.[1] as
          | { body?: string }
          | undefined;
        const body = JSON.parse(options?.body ?? "{}") as {
          platforms?: string[];
          person_ids?: string[];
          account_handles?: string[];
        };
        const result = await queryMock(
          `
            SELECT
              id::text AS id,
              person_id::text AS person_id,
              platform,
              account_handle,
              scraped_at,
              updated_at,
              created_at,
              stats_refreshed,
              raw_response->>'socialblade_url' AS socialblade_url
            FROM pipeline.socialblade_growth_data
            WHERE platform = ANY($1::text[])
              AND (
                person_id = ANY($2::uuid[])
                OR (
                  account_handle = ANY($3::text[])
                )
              )
            ORDER BY
              platform ASC,
              account_handle ASC,
              person_id ASC NULLS LAST,
              updated_at DESC NULLS LAST,
              scraped_at DESC NULLS LAST,
              created_at DESC NULLS LAST,
              id ASC
          `,
          [body.platforms ?? [], body.person_ids ?? [], body.account_handles ?? []],
        );
        return { rows: Array.isArray(result?.rows) ? result.rows : [] };
      }

      if (path.startsWith("/shared/sources")) {
        return {
          sources: [
            {
              id: "source-1",
              platform: "instagram",
              source_scope: "network",
              account_handle: "bravotv",
              is_active: true,
              scrape_priority: 10,
            },
            {
              id: "source-2",
              platform: "instagram",
              source_scope: "network",
              account_handle: "bravodailydish",
              is_active: true,
              scrape_priority: 9,
            },
            {
              id: "source-3",
              platform: "instagram",
              source_scope: "network",
              account_handle: "wwhlbravo",
              is_active: true,
              scrape_priority: 8,
            },
            {
              id: "source-4",
              platform: "tiktok",
              source_scope: "network",
              account_handle: "bravowwhl",
              is_active: false,
              scrape_priority: 8,
            },
            {
              id: "source-5",
              platform: "youtube",
              source_scope: "network",
              account_handle: "wwhl",
              is_active: false,
              scrape_priority: 8,
            },
          ],
        };
      }

      if (path.startsWith("/shared/ingest/runs")) {
        return [
          {
            id: "run-1",
            status: "completed",
            created_at: "2026-04-01T12:00:00.000Z",
            ingest_mode: "shared_account_async",
          },
        ];
      }

      if (path.startsWith("/shared/review-queue")) {
        return {
          items: [
            {
              id: "review-1",
              platform: "instagram",
              source_id: "source-3",
              source_account: "wwhlbravo",
              review_reason: "unmatched_show",
              review_status: "open",
            },
          ],
        };
      }

      if (path.startsWith("/profiles/") && path.endsWith("/summary")) {
        const parts = path.split("/");
        const platform = parts[2] ?? "";
        const handle = decodeURIComponent(parts[3] ?? "");
        return {
          summary_detail: "lite",
          platform,
          account_handle: handle,
          total_posts: 100,
          materialized_total_posts: 80,
          catalog_total_posts: 60,
          live_catalog_total_posts: 60,
        };
      }

      throw new Error(`Unhandled social path: ${path}`);
    });

    loadSharedAccountSourcesFromBackendMock.mockImplementation(
      async (_adminContext: unknown, options: { sourceScope: string }) => {
        const payload = await fetchSocialBackendJsonMock("/shared/sources", {
          queryString: `source_scope=${options.sourceScope}&include_inactive=true`,
        });
        return {
          source_scope: options.sourceScope,
          using_defaults: false,
          sources: Array.isArray(payload?.sources) ? payload.sources : [],
        };
      },
    );

    listShowExternalIdsByIdsMock.mockImplementation(
      async (showIds: readonly string[]) =>
        new Map(
          showIds.map((showId) => {
            if (showId === "show-wwhl") {
              return [
                showId,
                {
                  instagram_id: "bravowwhl",
                  twitter_id: "BravoWWHL",
                  facebook_id: "WatchWhatHappensLive",
                },
              ] as const;
            }
            return [showId, {}] as const;
          }),
        ),
    );

    fetchAdminBackendJsonMock.mockImplementation(async (path: string, options?: { body?: string }) => {
      if (path === "/admin/shows/cast-summary") {
        const showIds = JSON.parse(options?.body ?? "{\"show_ids\":[]}") as { show_ids?: string[] };
        return {
          status: 200,
          data: {
            shows: (showIds.show_ids ?? []).map((showId) => {
              if (showId === "show-rhoslc") {
                return {
                  show_id: showId,
                  cast_members: [
                    {
                      person_id: "person-heather",
                      full_name: "Heather Gay",
                    },
                  ],
                };
              }
              if (showId === "show-wwhl") {
                return {
                  show_id: showId,
                  cast_members: [
                    {
                      person_id: "person-andy",
                      full_name: "Andy Cohen",
                    },
                    {
                      person_id: "person-producer",
                      full_name: "Producer Without Handles",
                    },
                  ],
                };
              }
              return {
                show_id: showId,
                cast_members: [],
              };
            }),
          },
        };
      }

      if (path.includes("/admin/trr-api/shows/show-rhoslc/cast")) {
        return {
          status: 200,
          data: {
            cast_members: [
              {
                id: "cast-1",
                show_id: "show-rhoslc",
                person_id: "person-heather",
                show_name: "The Real Housewives of Salt Lake City",
                cast_member_name: "Heather Gay",
                role: "Self",
                billing_order: 1,
                credit_category: "cast",
                source_type: "tmdb",
                full_name: "Heather Gay",
                known_for: null,
                photo_url: null,
                created_at: "2026-01-01T00:00:00Z",
                updated_at: "2026-01-01T00:00:00Z",
              },
              {
                id: "cast-2",
                show_id: "show-rhoslc",
                person_id: "person-producer",
                show_name: "The Real Housewives of Salt Lake City",
                cast_member_name: "Producer Without Handles",
                role: "Producer",
                billing_order: 2,
                credit_category: "crew",
                source_type: "tmdb",
                full_name: "Producer Without Handles",
                known_for: null,
                photo_url: null,
                created_at: "2026-01-01T00:00:00Z",
                updated_at: "2026-01-01T00:00:00Z",
              },
            ],
          },
        };
      }

      if (path.includes("/admin/trr-api/shows/show-wwhl/cast")) {
        return {
          status: 200,
          data: {
            cast_members: [
              {
                id: "cast-3",
                show_id: "show-wwhl",
                person_id: "person-andy",
                show_name: "Watch What Happens Live with Andy Cohen",
                cast_member_name: "Andy Cohen",
                role: "Host",
                billing_order: 1,
                credit_category: "cast",
                source_type: "tmdb",
                full_name: "Andy Cohen",
                known_for: null,
                photo_url: null,
                created_at: "2026-01-01T00:00:00Z",
                updated_at: "2026-01-01T00:00:00Z",
              },
            ],
          },
        };
      }

      throw new Error(`Unhandled admin path: ${path}`);
    });

    listPrimaryPersonExternalIdsByPersonIdsMock.mockImplementation(
      async (personIds: readonly string[]) =>
        new Map(
          personIds.map((personId) => {
            if (personId === "person-heather") {
              return [
                personId,
                [
                  {
                    id: 1,
                    source_id: "instagram",
                    external_id: "heathergay",
                    is_primary: true,
                    valid_from: null,
                    valid_to: null,
                    observed_at: null,
                  },
                  {
                    id: 2,
                    source_id: "twitter",
                    external_id: "HeatherGay29",
                    is_primary: true,
                    valid_from: null,
                    valid_to: null,
                    observed_at: null,
                  },
                ],
              ] as const;
            }

            if (personId === "person-andy") {
              return [
                personId,
                [
                  {
                    id: 3,
                    source_id: "instagram",
                    external_id: "andycohen",
                    is_primary: true,
                    valid_from: null,
                    valid_to: null,
                    observed_at: null,
                  },
                  {
                    id: 4,
                    source_id: "youtube",
                    external_id: "@andycohen",
                    is_primary: true,
                    valid_from: null,
                    valid_to: null,
                    observed_at: null,
                  },
                  {
                    id: 6,
                    source_id: "threads",
                    external_id: "andycohen",
                    is_primary: true,
                    valid_from: null,
                    valid_to: null,
                    observed_at: null,
                  },
                ],
              ] as const;
            }

            if (personId === "person-producer") {
              return [
                personId,
                [
                  {
                    id: 5,
                    source_id: "imdb",
                    external_id: "nm1234567",
                    is_primary: true,
                    valid_from: null,
                    valid_to: null,
                    observed_at: null,
                  },
                ],
              ] as const;
            }

            return [personId, []] as const;
          }),
        ),
    );

    listEffectivePersonSocialHandlesByPersonIdsMock.mockResolvedValue(new Map());
    queryMock.mockResolvedValue({ rows: [] });
  });

  it("forwards verified admin context when loading fallback person social handles", async () => {
    const adminContext = {
      uid: "firebase-admin-1",
      email: "admin@example.com",
      verifiedAt: 42,
    };

    await getSocialLandingPayloadResult(adminContext);

    expect(listEffectivePersonSocialHandlesByPersonIdsMock).toHaveBeenCalledWith(
      expect.any(Array),
      { adminContext },
    );
  });

  it("builds networks, shows, and people with WWHL handle filtering", async () => {
    const payload = await getSocialLandingPayload();

    expect(payload.network_sets).toHaveLength(1);
    expect(payload.shared_pipeline.sources).toHaveLength(5);
    expect(payload.scrape_job_health).toEqual(
      expect.objectContaining({
        window_hours: 8,
        failed_jobs: 0,
        in_failed_sql_transaction_hits: 0,
      }),
    );

    const networkSet = payload.network_sets[0];
    expect(networkSet.key).toBe("network");
    expect(networkSet.title).toBe("Network");
    expect(networkSet.handles).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          platform: "instagram",
          handle: "bravotv",
        }),
        expect.objectContaining({
          platform: "instagram",
          handle: "bravowwhl",
          href: "/social/instagram/bravowwhl",
        }),
      ]),
    );
    expect(networkSet.handles).not.toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          platform: "youtube",
          handle: "wwhl",
        }),
      ]),
    );

    const rhoslc = payload.show_sets.find((show) =>
      show.show_name.includes("Salt Lake City"),
    );
    expect(rhoslc).toMatchObject({
      fallback_note: null,
    });
    expect(rhoslc?.handles).toHaveLength(0);
    expect(rhoslc?.hashtag_suggestions).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          hashtag: "#TheRealHousewivesofSaltLakeCity",
          account_handle: "bravotv",
        }),
      ]),
    );

    const wwhl = payload.show_sets.find((show) =>
      show.show_name.includes("Watch What Happens Live"),
    );
    expect(wwhl?.handles).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          platform: "instagram",
          handle: "bravowwhl",
        }),
        expect.objectContaining({
          platform: "facebook",
          handle: "watchwhathappenslive",
        }),
      ]),
    );

    expect(payload.people_profiles.map((person) => person.full_name)).toEqual([
      "Andy Cohen",
      "Heather Gay",
    ]);
    expect(payload.person_targets.map((person) => person.full_name)).toEqual([
      "Andy Cohen",
      "Heather Gay",
      "Producer Without Handles",
    ]);

    const andy = payload.people_profiles.find(
      (person) => person.full_name === "Andy Cohen",
    );
    expect(andy?.shows).toEqual([
      expect.objectContaining({
        show_name: "Watch What Happens Live with Andy Cohen",
      }),
    ]);
    expect(andy?.handles).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          platform: "instagram",
          handle: "andycohen",
        }),
        expect.objectContaining({
          platform: "threads",
          handle: "andycohen",
        }),
        expect.objectContaining({
          platform: "youtube",
          display_label: "@andycohen",
        }),
      ]),
    );

    const heather = payload.people_profiles.find(
      (person) => person.full_name === "Heather Gay",
    );
    expect(heather?.shows).toEqual([
      expect.objectContaining({
        show_name: "The Real Housewives of Salt Lake City",
      }),
    ]);
    expect(heather?.handles).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          platform: "instagram",
          handle: "heathergay",
        }),
        expect.objectContaining({
          platform: "twitter",
          handle: "heathergay29",
        }),
      ]),
    );
    expect(payload.reddit_dashboard).toEqual({
      active_community_count: expect.any(Number),
      archived_community_count: expect.any(Number),
      show_count: expect.any(Number),
    });
  });
  it("loads unauthenticated social progress through the backend rollup without direct SQL", async () => {
    const defaultSocialBackend = fetchSocialBackendJsonMock.getMockImplementation();
    if (!defaultSocialBackend) throw new Error("Missing default social backend mock");
    fetchSocialBackendJsonMock.mockImplementation(async (path: string, options?: unknown) => {
      if (path === "/landing-progress-rollup") {
        return {
          rows: [
            {
              platform: "instagram",
              account_handle: "bravotv",
              saved_count: 7,
              scraped_count: 9,
              socialblade_supported: true,
              socialblade_scraped_count: 1,
              socialblade_saved_count: 1,
              following_saved_count: 25,
              following_total_count: 30,
              comments_saved_count: 100,
              comments_total_count: 120,
              media_saved_count: 4,
              media_total_count: 6,
            },
          ],
          cache_status: "miss",
          generated_at: "2026-07-13T12:00:00.000Z",
          stale: false,
        };
      }
      return defaultSocialBackend(path, options);
    });

    const result = await getSocialLandingPayloadResult();

    const progressCall = fetchSocialBackendJsonMock.mock.calls.find(
      ([path]) => path === "/landing-progress-rollup",
    );
    const progressOptions = progressCall?.[1] as
      | { body?: string; method?: string; adminContext?: unknown }
      | undefined;
    const progressBody = JSON.parse(progressOptions?.body ?? "{}") as {
      platforms?: string[];
      account_handles?: string[];
    };

    expect(progressOptions?.method).toBe("POST");
    expect(progressOptions?.adminContext).toBeUndefined();
    expect(progressBody.platforms?.length).toBe(progressBody.account_handles?.length);
    expect(progressBody.account_handles).toEqual(expect.arrayContaining(["bravotv"]));
    expect(
      queryMock.mock.calls.some(([sql]) => String(sql).includes("landing_social_progress")),
    ).toBe(false);
    expect(result.cacheable).toBe(true);
    expect(result.payload.social_progress_status).toEqual({
      source: "backend",
      cache_status: "miss",
      generated_at: "2026-07-13T12:00:00.000Z",
      stale: false,
    });
    expect(result.payload.network_sets[0]?.handles).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          platform: "instagram",
          handle: "bravotv",
          progress: expect.objectContaining({
            lanes: expect.arrayContaining([
              expect.objectContaining({
                key: "comments",
                saved_count: 100,
                scraped_count: 120,
                total_count: 120,
              }),
              expect.objectContaining({
                key: "socialblade",
                status: "ready",
                saved_count: 26,
                scraped_count: 26,
                total_count: 31,
              }),
            ]),
          }),
        }),
      ]),
    );
  });

  it("loads authenticated social progress from the cached backend rollup", async () => {
    const defaultSocialBackend = fetchSocialBackendJsonMock.getMockImplementation();
    if (!defaultSocialBackend) throw new Error("Missing default social backend mock");
    fetchSocialBackendJsonMock.mockImplementation(async (path: string, options?: unknown) => {
      if (path === "/landing-summary") {
        return {
          covered_shows: await getCoveredShowsMock(),
          reddit_dashboard: {
            active_community_count: 2,
            archived_community_count: 1,
            show_count: 2,
          },
        };
      }
      if (path === "/landing-progress-rollup") {
        return {
          rows: [
            {
              platform: "instagram",
              account_handle: "bravotv",
              saved_count: 7,
              scraped_count: 9,
              socialblade_supported: true,
              socialblade_scraped_count: 1,
              socialblade_saved_count: 1,
              following_saved_count: 25,
              following_total_count: 30,
              comments_saved_count: 100,
              comments_total_count: 120,
              media_saved_count: 4,
              media_total_count: 6,
            },
          ],
        };
      }
      return defaultSocialBackend(path, options);
    });

    const result = await getSocialLandingPayloadResult({
      uid: "admin-user",
      email: "admin@example.test",
      verifiedAt: 1_776_000_000,
    });

    const rollupCall = fetchSocialBackendJsonMock.mock.calls.find(
      ([path]) => path === "/landing-progress-rollup",
    );
    const rollupOptions = rollupCall?.[1] as { body?: string; method?: string } | undefined;
    const rollupBody = JSON.parse(rollupOptions?.body ?? "{}") as {
      platforms?: string[];
      account_handles?: string[];
    };

    expect(
      queryMock.mock.calls.some(([sql]) =>
        String(sql).includes("landing_social_progress"),
      ),
    ).toBe(false);
    expect(rollupOptions?.method).toBe("POST");
    expect(rollupBody.platforms?.length).toBe(rollupBody.account_handles?.length);
    expect(rollupBody.account_handles).toEqual(expect.arrayContaining(["bravotv"]));
    const bravotvHandle = result.payload.network_sets[0]?.handles.find(
      (handle) => handle.platform === "instagram" && handle.handle === "bravotv",
    );
    if (!bravotvHandle?.progress) {
      throw new Error("Expected bravotv progress from the backend rollup");
    }
    const postsLane = bravotvHandle.progress.lanes.find((lane) => lane.key === "posts");
    const commentsLane = bravotvHandle.progress.lanes.find((lane) => lane.key === "comments");
    const mediaLane = bravotvHandle.progress.lanes.find((lane) => lane.key === "media");
    if (!postsLane || !commentsLane || !mediaLane) {
      throw new Error("Expected posts, comments, and media progress lanes");
    }

    expect(postsLane).toEqual(
      expect.objectContaining({
        key: "posts",
        saved_count: 7,
        scraped_count: 9,
        total_count: 9,
      }),
    );
    expect(commentsLane).toEqual(
      expect.objectContaining({
        key: "comments",
        saved_count: 100,
        scraped_count: 120,
        total_count: 120,
      }),
    );
    expect(commentsLane.scraped_percent).toBeGreaterThan(0);
    expect(mediaLane).toEqual(
      expect.objectContaining({
        key: "media",
        saved_count: 4,
        scraped_count: 6,
        total_count: 6,
      }),
    );
    expect(mediaLane.saved_percent).toBeLessThan(mediaLane.scraped_percent);
    expect(result.payload.network_sets[0]?.handles).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          platform: "instagram",
          handle: "bravotv",
          progress: expect.objectContaining({
            saved_count: 7,
            scraped_count: 9,
            lanes: expect.arrayContaining([
              expect.objectContaining({
                key: "comments",
                saved_count: 100,
                total_count: 120,
              }),
            ]),
          }),
        }),
      ]),
    );
  });

  it("includes recent scrape job health for the social landing badge", async () => {
    const defaultSocialBackend = fetchSocialBackendJsonMock.getMockImplementation();
    if (!defaultSocialBackend) throw new Error("Missing default social backend mock");
    fetchSocialBackendJsonMock.mockImplementation(async (path: string, options?: unknown) => {
      if (path === "/landing-scrape-job-health") {
        return {
          generated_at: "2026-05-18T12:00:00.000Z",
          window_started_at: "2026-05-18T04:00:00.000Z",
          total_jobs: "9",
          active_jobs: "1",
          failed_jobs: "2",
          failure_signal_jobs: "3",
          in_failed_sql_transaction_hits: "1",
          latest_failure_at: "2026-05-18T11:45:00.000Z",
        };
      }
      return defaultSocialBackend(path, options);
    });

    const payload = await getSocialLandingPayload();

    expect(payload.scrape_job_health).toEqual({
      window_hours: 8,
      generated_at: "2026-05-18T12:00:00.000Z",
      window_started_at: "2026-05-18T04:00:00.000Z",
      total_jobs: 9,
      active_jobs: 1,
      failed_jobs: 2,
      failure_signal_jobs: 3,
      in_failed_sql_transaction_hits: 1,
      latest_failure_at: "2026-05-18T11:45:00.000Z",
    });
    expect(fetchSocialBackendJsonMock).toHaveBeenCalledWith(
      "/landing-scrape-job-health",
      expect.objectContaining({
        fallbackError: "Failed to load social landing scrape-job health",
        retries: 1,
        timeoutMs: 25_000,
      }),
    );
    expect(
      queryMock.mock.calls.some(([sql]) =>
        String(sql).includes("landing_social_scrape_job_health"),
      ),
    ).toBe(false);
  });

  it("degrades scrape job health to the empty summary when the backend read fails", async () => {
    const expectedWarn = captureExpectedConsoleWarn(
      /^\[social-landing\] Failed to load scrape job health /,
    );
    const defaultSocialBackend = fetchSocialBackendJsonMock.getMockImplementation();
    if (!defaultSocialBackend) throw new Error("Missing default social backend mock");
    fetchSocialBackendJsonMock.mockImplementation(async (path: string, options?: unknown) => {
      if (path === "/landing-scrape-job-health") {
        throw new Error("health backend unavailable");
      }
      return defaultSocialBackend(path, options);
    });

    const payload = await getSocialLandingPayload();

    expect(payload.scrape_job_health).toEqual({
      window_hours: 8,
      window_started_at: null,
      generated_at: null,
      total_jobs: 0,
      active_jobs: 0,
      failed_jobs: 0,
      failure_signal_jobs: 0,
      in_failed_sql_transaction_hits: 0,
      latest_failure_at: null,
    });
    expectedWarn.restore();
  });

  it("labels assigned YouTube playlist show handles with playlist metadata", async () => {
    loadSharedAccountSourcesFromBackendMock.mockImplementation(
      async (_adminContext: unknown, options: { sourceScope: string }) => ({
        source_scope: options.sourceScope,
        using_defaults: false,
        sources:
          options.sourceScope === "network"
            ? [
            {
              id: "source-playlist-1",
              platform: "youtube",
              source_scope: "network",
              account_handle: "plcsqhums6noyf7gnzgoo7uxurccmtmh1v",
              is_active: true,
              scrape_priority: 8,
              metadata: {
                assigned_show_id: "show-rhoslc",
                source_type: "playlist",
                youtube_source_type: "playlist",
                playlist_id: "PLCsQHuMS6NoyF7gnzgOo7UxUrCcMtMH1v",
                profile_snapshot: {
                  display_name: "The Traitors Official Playlist",
                },
              },
            },
              ]
            : [],
      }),
    );

    const payload = await getSocialLandingPayload();
    const rhoslc = payload.show_sets.find((show) =>
      show.show_name.includes("Salt Lake City"),
    );

    expect(rhoslc?.handles).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          platform: "youtube",
          handle: "plcsqhums6noyf7gnzgoo7uxurccmtmh1v",
          display_label: "The Traitors Official Playlist",
        }),
      ]),
    );
  });

  it("starts independent first-wave landing reads while shared sources are still loading", async () => {
    let resolveSharedSources!: () => void;
    let sharedSourcesStarted!: () => void;
    const sharedSourcesStartedPromise = new Promise<void>((resolve) => {
      sharedSourcesStarted = resolve;
    });
    const sharedSourcesPromise = new Promise<{
      source_scope: string;
      sources: [];
      using_defaults: false;
    }>((resolve) => {
      resolveSharedSources = () => resolve({ source_scope: "network", sources: [], using_defaults: false });
    });

    fetchSocialBackendJsonMock.mockImplementation(async (path: string) => {
      if (path.startsWith("/shared/ingest/runs")) {
        return [];
      }
      if (path.startsWith("/shared/review-queue")) {
        return { items: [] };
      }
      if (path === "/landing-socialblade-rows") {
        return { rows: [] };
      }
      if (path === "/landing-socialblade-progress-counts") {
        return { rows: [] };
      }
      if (path.startsWith("/profiles/") && path.endsWith("/summary")) {
        return {
          summary_detail: "lite",
          total_posts: 0,
          materialized_total_posts: 0,
          catalog_total_posts: 0,
          live_catalog_total_posts: 0,
        };
      }
      throw new Error(`Unhandled social path: ${path}`);
    });
    loadSharedAccountSourcesFromBackendMock.mockImplementation(async () => {
      sharedSourcesStarted();
      return sharedSourcesPromise;
    });
    listShowExternalIdsByIdsMock.mockResolvedValue(new Map());
    fetchAdminBackendJsonMock.mockResolvedValue({
      status: 200,
      data: { shows: [] },
    });

    const resultPromise = getSocialLandingPayloadResult();
    await sharedSourcesStartedPromise;
    await delay(0);

    expect(listShowExternalIdsByIdsMock).toHaveBeenCalledWith(
      ["show-rhoslc", "show-wwhl"],
      { adminContext: undefined },
    );
    expect(fetchAdminBackendJsonMock).toHaveBeenCalledWith(
      "/admin/shows/cast-summary",
      expect.objectContaining({
        timeoutMs: 5_000,
      }),
    );
    expect(loadSharedAccountSourcesFromBackendMock).toHaveBeenCalledWith(
      undefined,
      expect.objectContaining({ sourceScope: "network", includeInactive: true }),
    );

    resolveSharedSources();
    const result = await resultPromise;

    expect(result.payload.network_sets).toEqual([
      expect.objectContaining({
        key: "bravo-tv",
        handles: [],
      }),
    ]);
    expect(result.cacheable).toBe(true);
  });

  it("starts social progress before cast SocialBlade rows resolve", async () => {
    const events: string[] = [];
    let resolveCastSocialBladeRows!: () => void;
    const castSocialBladeRowsPromise = new Promise<{ rows: [] }>((resolve) => {
      resolveCastSocialBladeRows = () => resolve({ rows: [] });
    });
    const defaultSocialBackend = fetchSocialBackendJsonMock.getMockImplementation();
    if (!defaultSocialBackend) throw new Error("Missing default social backend mock");

    fetchSocialBackendJsonMock.mockImplementation(async (path: string, options?: unknown) => {
      if (path === "/landing-socialblade-rows") {
        events.push("cast-socialblade-started");
        return castSocialBladeRowsPromise;
      }
      if (path === "/landing-progress-rollup") {
        events.push("social-progress-started");
        return { rows: [] };
      }
      return defaultSocialBackend(path, options);
    });

    const resultPromise = getSocialLandingPayloadResult();
    while (!events.includes("cast-socialblade-started")) {
      await delay(0);
    }
    await delay(0);

    expect(events).toContain("social-progress-started");
    expect(events.indexOf("social-progress-started")).toBeGreaterThan(
      events.indexOf("cast-socialblade-started"),
    );

    resolveCastSocialBladeRows();
    const result = await resultPromise;

    expect(result.payload.cast_socialblade_shows).toEqual([]);
  });

  it("marks shared sources unavailable when the backend adapter read fails", async () => {
    const expectedWarn = captureExpectedConsoleWarn(
      /^\[social-landing\] Failed to load shared sources /,
    );
    loadSharedAccountSourcesFromBackendMock.mockRejectedValue(
      new Error("TRR-Backend request timed out."),
    );

    const result = await getSocialLandingPayloadResult();

    expect(result.cacheable).toBe(false);
    expect(result.payload.shared_source_sets).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          source_scope: "network",
          sources: [],
        }),
      ]),
    );
    expect(result.payload.shared_source_status).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          source_scope: "network",
          load_source: "backend",
          backend_endpoint:
            "/admin/socials/shared-account-sources?source_scope=network&include_inactive=true",
        }),
      ]),
    );
    expectedWarn.expectCalled();
  });

  it("places show-assigned shared sources on the show instead of the Bravo network", async () => {
    getCoveredShowsMock.mockResolvedValue([
      {
        id: "covered-traitors",
        trr_show_id: "show-traitors",
        show_name: "The Traitors",
        canonical_slug: "the-traitors",
        alternative_names: [],
        show_total_episodes: 40,
        poster_url: null,
      },
    ]);
    fetchSocialBackendJsonMock.mockImplementation(async (path: string) => {
      if (path.startsWith("/shared/sources")) {
        return {
          sources: [
            {
              id: "source-bravo",
              platform: "instagram",
              source_scope: "network",
              account_handle: "bravotv",
              is_active: true,
              scrape_priority: 10,
              metadata: {},
            },
            {
              id: "source-bravo-tiktok",
              platform: "tiktok",
              source_scope: "network",
              account_handle: "bravotv",
              is_active: false,
              scrape_priority: 40,
              metadata: {},
            },
            {
              id: "source-daily-dish-threads",
              platform: "threads",
              source_scope: "network",
              account_handle: "bravodailydish",
              is_active: true,
              scrape_priority: 50,
              metadata: {},
            },
            {
              id: "source-traitors",
              platform: "twitter",
              source_scope: "network",
              account_handle: "thetraitorsus",
              is_active: true,
              scrape_priority: 85,
              metadata: {
                assigned_show_id: "show-traitors",
                profile_kind: "show_official",
                network_name: "The Traitors",
              },
            },
          ],
        };
      }
      if (path.startsWith("/shared/ingest/runs")) return [];
      if (path.startsWith("/shared/review-queue")) return { items: [] };
      if (path === "/landing-scrape-job-health") {
        return {
          window_hours: 8,
          window_started_at: null,
          generated_at: null,
          total_jobs: 0,
          active_jobs: 0,
          failed_jobs: 0,
          failure_signal_jobs: 0,
          in_failed_sql_transaction_hits: 0,
          latest_failure_at: null,
        };
      }
      if (path === "/landing-progress-rollup") {
        return {
          rows: [
            {
              platform: "instagram",
              account_handle: "bravotv",
              saved_count: 90,
              scraped_count: 75,
            },
            {
              platform: "instagram",
              account_handle: "thetraitorsus",
              saved_count: 442,
              scraped_count: 442,
            },
            {
              platform: "tiktok",
              account_handle: "thetraitorsus",
              saved_count: 275,
              scraped_count: 275,
            },
            {
              platform: "twitter",
              account_handle: "thetraitorsus",
              saved_count: 5227,
              scraped_count: 285,
            },
          ],
        };
      }
      if (path.startsWith("/profiles/") && path.endsWith("/summary")) {
        const [platform, rawHandle] = path
          .replace(/^\/profiles\//, "")
          .replace(/\/summary$/, "")
          .split("/");
        const handle = decodeURIComponent(rawHandle ?? "");
        const counts: Record<string, { saved: number; scraped: number; total: number }> = {
          "instagram:bravotv": { saved: 90, scraped: 75, total: 100 },
          "instagram:thetraitorsus": { saved: 442, scraped: 442, total: 442 },
          "tiktok:thetraitorsus": { saved: 275, scraped: 275, total: 275 },
          "twitter:thetraitorsus": { saved: 5227, scraped: 285, total: 5227 },
        };
        const progress = counts[`${platform}:${handle}`] ?? {
          saved: 0,
          scraped: 0,
          total: 0,
        };
        return {
          summary_detail: "lite",
          platform,
          account_handle: handle,
          total_posts: progress.total,
          materialized_total_posts: progress.saved,
          catalog_total_posts: progress.scraped,
          live_catalog_total_posts: progress.scraped,
        };
      }
      throw new Error(`Unhandled social path: ${path}`);
    });
    listShowExternalIdsByIdsMock.mockResolvedValue(
      new Map([
        [
          "show-traitors",
          {
            instagram_handle: "thetraitorsus",
            tiktok_handle: "thetraitorsus",
          },
        ],
      ]),
    );
    const result = await getSocialLandingPayloadResult();
    const networkSet = result.payload.network_sets[0];
    const traitors = result.payload.show_sets.find(
      (show) => show.show_name === "The Traitors",
    );

    expect(result.cacheable).toBe(true);
    expect(networkSet.key).toBe("network");
    expect(networkSet.handles).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ platform: "instagram", handle: "bravotv" }),
      ]),
    );
    expect(networkSet.handles).not.toEqual(
      expect.arrayContaining([
        expect.objectContaining({ platform: "twitter", handle: "thetraitorsus" }),
      ]),
    );
    expect(networkSet.handles).not.toEqual(
      expect.arrayContaining([
        expect.objectContaining({ platform: "tiktok", handle: "bravotv" }),
      ]),
    );
    expect(result.payload.shared_source_sets[0].sources).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ platform: "instagram", account_handle: "bravotv" }),
        expect.objectContaining({ platform: "threads", account_handle: "bravodailydish" }),
      ]),
    );
    expect(result.payload.shared_source_sets[0].sources).not.toEqual(
      expect.arrayContaining([
        expect.objectContaining({ platform: "tiktok", account_handle: "bravotv" }),
      ]),
    );
    expect(result.payload.shared_source_sets[0].sources).not.toEqual(
      expect.arrayContaining([
        expect.objectContaining({ platform: "twitter", account_handle: "thetraitorsus" }),
      ]),
    );
    expect(traitors?.fallback_note).toBeNull();
    expect(traitors?.handles).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ platform: "instagram", handle: "thetraitorsus" }),
        expect.objectContaining({ platform: "tiktok", handle: "thetraitorsus" }),
        expect.objectContaining({ platform: "twitter", handle: "thetraitorsus" }),
      ]),
    );
    expect(traitors?.handles).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          platform: "twitter",
          handle: "thetraitorsus",
          progress: {
            saved_count: 5227,
            scraped_count: 285,
            total_count: 5227,
            saved_percent: 100,
            scraped_percent: 5.5,
            last_catalog_run_at: null,
            last_catalog_run_status: null,
            lanes: expect.arrayContaining([
              expect.objectContaining({
                key: "socialblade",
                label: "Following List",
                status: "missing",
              }),
              expect.objectContaining({
                key: "posts",
                saved_count: 5227,
                scraped_count: 285,
                total_count: 5227,
              }),
              expect.objectContaining({
                key: "comments",
              }),
              expect.objectContaining({
                key: "media",
              }),
            ]),
          },
        }),
      ]),
    );
    expect(networkSet.handles).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          platform: "instagram",
          handle: "bravotv",
          progress: expect.objectContaining({
            saved_count: 90,
            scraped_count: 75,
            total_count: 90,
          }),
        }),
      ]),
    );
  });

  it("scopes network shared sources by stable network-set identity", async () => {
    getCoveredShowsMock.mockResolvedValue([
      {
        id: "covered-traitors",
        trr_show_id: "show-traitors",
        show_name: "The Traitors",
        canonical_slug: "the-traitors",
        alternative_names: [],
        show_total_episodes: 40,
        poster_url: null,
      },
    ]);
    fetchAdminBackendJsonMock.mockResolvedValue({
      status: 200,
      data: {
        shows: [
          {
            show_id: "show-traitors",
            cast_members: [],
          },
        ],
      },
    });
    listShowExternalIdsByIdsMock.mockResolvedValue(
      new Map([["show-traitors", { instagram_handle: "thetraitorsus" }]]),
    );
    fetchSocialBackendJsonMock.mockImplementation(
      async (path: string, options?: { queryString?: string }) => {
        if (path.startsWith("/shared/sources")) {
          if (!options?.queryString?.startsWith("source_scope=network")) {
            return { sources: [] };
          }
          return {
            sources: [
              {
                id: "source-bravo",
                platform: "instagram",
                source_scope: "network",
                account_handle: "bravotv",
                is_active: true,
                scrape_priority: 10,
                metadata: {
                  network_set_id: "Bravo Primary",
                  network_id: "ignored-bravo-id",
                  network_key: "ignored-bravo-key",
                  network_title: "Bravo TV",
                },
              },
              {
                id: "source-peacock",
                platform: "instagram",
                source_scope: "network",
                account_handle: "peacock",
                is_active: true,
                scrape_priority: 20,
                metadata: {
                  network_id: "Peacock Network",
                  network_key: "ignored-peacock-key",
                  network_title: "Peacock",
                },
              },
              {
                id: "source-nbc",
                platform: "youtube",
                source_scope: "network",
                account_handle: "nbc",
                is_active: true,
                scrape_priority: 30,
                metadata: {
                  network_key: "NBC Broadcast",
                  network_title: "NBC",
                },
              },
              {
                id: "source-syndication",
                platform: "threads",
                source_scope: "syndication",
                account_handle: "syndicatedreality",
                is_active: true,
                scrape_priority: 40,
                metadata: {},
              },
              {
                id: "source-traitors",
                platform: "twitter",
                source_scope: "network",
                account_handle: "thetraitorsus",
                is_active: true,
                scrape_priority: 50,
                metadata: {
                  network_set_id: "Bravo Primary",
                  assigned_show_id: "show-traitors",
                  network_title: "Bravo TV",
                },
              },
            ],
          };
        }
        if (path.startsWith("/shared/ingest/runs")) return [];
        if (path.startsWith("/shared/review-queue")) return { items: [] };
        if (path === "/landing-socialblade-progress-counts") return { rows: [] };
        if (path.startsWith("/profiles/") && path.endsWith("/summary")) {
          return {
            summary_detail: "lite",
            total_posts: 0,
            materialized_total_posts: 0,
            catalog_total_posts: 0,
            live_catalog_total_posts: 0,
          };
        }
        throw new Error(`Unhandled social path: ${path}`);
      },
    );

    const result = await getSocialLandingPayloadResult();
    const networkSetsByKey = new Map(
      result.payload.network_sets.map((set) => [set.key, set]),
    );
    const sharedNetworkSets = result.payload.shared_source_sets.filter(
      (set) => set.source_scope === "network",
    );
    const sharedNetworkSetsByKey = new Map(
      sharedNetworkSets.map((set) => [set.key, set]),
    );

    expect([...networkSetsByKey.keys()]).toEqual([
      "bravo-primary",
      "nbc-broadcast",
      "peacock-network",
      "syndication",
    ]);
    expect(networkSetsByKey.get("bravo-primary")?.handles).toEqual([
      expect.objectContaining({ platform: "instagram", handle: "bravotv" }),
    ]);
    expect(networkSetsByKey.get("peacock-network")?.handles).toEqual([
      expect.objectContaining({ platform: "instagram", handle: "peacock" }),
    ]);
    expect(networkSetsByKey.get("bravo-primary")?.handles).not.toEqual(
      expect.arrayContaining([
        expect.objectContaining({ platform: "instagram", handle: "peacock" }),
        expect.objectContaining({ platform: "twitter", handle: "thetraitorsus" }),
      ]),
    );
    expect(sharedNetworkSets.map((set) => set.key)).toEqual([
      "bravo-primary",
      "nbc-broadcast",
      "peacock-network",
      "syndication",
    ]);
    expect(sharedNetworkSetsByKey.get("bravo-primary")?.sources).toEqual([
      expect.objectContaining({ id: "source-bravo" }),
    ]);
    expect(sharedNetworkSetsByKey.get("bravo-primary")?.sources).not.toEqual(
      expect.arrayContaining([
        expect.objectContaining({ id: "source-traitors" }),
      ]),
    );
  });

  it("keeps network-set keys stable when titles and source order change", async () => {
    getCoveredShowsMock.mockResolvedValue([]);
    fetchAdminBackendJsonMock.mockResolvedValue({
      status: 200,
      data: { shows: [] },
    });
    listShowExternalIdsByIdsMock.mockResolvedValue(new Map());
    let sources = [
      {
        id: "source-peacock",
        platform: "instagram",
        source_scope: "network",
        account_handle: "peacock",
        is_active: true,
        scrape_priority: 20,
        metadata: {
          network_set_id: "peacock-network",
          network_title: "Peacock Original",
        },
      },
      {
        id: "source-bravo",
        platform: "instagram",
        source_scope: "network",
        account_handle: "bravotv",
        is_active: true,
        scrape_priority: 10,
        metadata: {
          network_set_id: "bravo-network",
          network_title: "Bravo Original",
        },
      },
    ];
    fetchSocialBackendJsonMock.mockImplementation(
      async (path: string, options?: { queryString?: string }) => {
        if (path.startsWith("/shared/sources")) {
          if (!options?.queryString?.startsWith("source_scope=network")) {
            return { sources: [] };
          }
          return { sources };
        }
        if (path.startsWith("/shared/ingest/runs")) return [];
        if (path.startsWith("/shared/review-queue")) return { items: [] };
        if (path === "/landing-socialblade-progress-counts") return { rows: [] };
        if (path.startsWith("/profiles/") && path.endsWith("/summary")) {
          return {
            summary_detail: "lite",
            total_posts: 0,
            materialized_total_posts: 0,
            catalog_total_posts: 0,
            live_catalog_total_posts: 0,
          };
        }
        throw new Error(`Unhandled social path: ${path}`);
      },
    );

    const firstPayload = await getSocialLandingPayload();
    sources = [
      {
        ...sources[1],
        metadata: {
          network_set_id: "bravo-network",
          network_title: "Bravo Renamed",
        },
      },
      {
        ...sources[0],
        metadata: {
          network_set_id: "peacock-network",
          network_title: "Peacock Renamed",
        },
      },
    ];
    const secondPayload = await getSocialLandingPayload();

    expect(firstPayload.network_sets.map((set) => set.key)).toEqual([
      "bravo-network",
      "peacock-network",
    ]);
    expect(secondPayload.network_sets.map((set) => set.key)).toEqual([
      "bravo-network",
      "peacock-network",
    ]);
    expect(
      firstPayload.shared_source_sets
        .filter((set) => set.source_scope === "network")
        .map((set) => set.key),
    ).toEqual(["bravo-network", "peacock-network"]);
    expect(
      secondPayload.shared_source_sets
        .filter((set) => set.source_scope === "network")
        .map((set) => set.key),
    ).toEqual(["bravo-network", "peacock-network"]);
  });

  it("marks landing payloads not cacheable when show external-id handles fail to load", async () => {
    listShowExternalIdsByIdsMock.mockRejectedValue(new Error("pool exhausted"));

    const result = await getSocialLandingPayloadResult();

    expect(result.cacheable).toBe(false);
  });

  it("caps social landing show and people fanout concurrency to avoid saturating local admin reads", async () => {
    getCoveredShowsMock.mockResolvedValue(
      Array.from({ length: 5 }, (_, index) => ({
        id: `covered-${index + 1}`,
        trr_show_id: `show-${index + 1}`,
        show_name: `Show ${index + 1}`,
        canonical_slug: `show-${index + 1}`,
        alternative_names: [],
        show_total_episodes: 10,
        created_at: "2026-01-01T00:00:00Z",
        created_by_firebase_uid: "admin",
      })),
    );

    let showExternalIdBatchCalls = 0;
    listShowExternalIdsByIdsMock.mockImplementation(async (showIds: readonly string[]) => {
      showExternalIdBatchCalls += 1;
      return new Map(showIds.map((showId) => [showId, {}] as const));
    });

    let castSummaryBatchCalls = 0;
    fetchAdminBackendJsonMock.mockImplementation(async (path: string, options?: { body?: string }) => {
      castSummaryBatchCalls += 1;
      await delay(5);
      return {
        status: 200,
        data: {
          shows: (JSON.parse(options?.body ?? "{\"show_ids\":[]}") as { show_ids?: string[] }).show_ids?.map(
            (showId) => ({
              show_id: showId,
              cast_members: [
                {
                  person_id: `person-${showId}`,
                  full_name: `Person ${showId}`,
                },
              ],
            }),
          ) ?? [],
        },
      };
    });

    let personExternalIdBatchCalls = 0;
    let receivedPersonIds: readonly string[] = [];
    listPrimaryPersonExternalIdsByPersonIdsMock.mockImplementation(
      async (personIds: readonly string[]) => {
        personExternalIdBatchCalls += 1;
        receivedPersonIds = [...personIds];
        await delay(5);
        return new Map(
          personIds.map((personId) => [
            personId,
            [
              {
                id: Number(personId.replace(/\D/g, "")) || 1,
                source_id: "instagram",
                external_id: `${personId}-handle`,
                is_primary: true,
                valid_from: null,
                valid_to: null,
                observed_at: null,
              },
            ],
          ]),
        );
      },
    );
    let personFallbackHandleBatchCalls = 0;
    listEffectivePersonSocialHandlesByPersonIdsMock.mockImplementation(
      async (personIds: readonly string[]) => {
        personFallbackHandleBatchCalls += 1;
        return new Map(
          personIds.map((personId) => [
            personId,
            {
              person_id: personId,
              facebook_handle: null,
              instagram_handle: null,
              tiktok_handle: null,
              twitter_handle: null,
              youtube_handle: null,
            },
          ]),
        );
      },
    );

    const payload = await getSocialLandingPayload();

    expect(payload.show_sets).toHaveLength(5);
    expect(payload.people_profiles).toHaveLength(5);
    expect(castSummaryBatchCalls).toBe(1);
    expect(showExternalIdBatchCalls).toBe(1);
    expect(personExternalIdBatchCalls).toBe(1);
    expect(personFallbackHandleBatchCalls).toBe(1);
    expect(receivedPersonIds).toHaveLength(5);
  });

  it("includes cast members with fallback social handles even when primary external-id rows are missing", async () => {
    listPrimaryPersonExternalIdsByPersonIdsMock.mockImplementation(
      async (personIds: readonly string[]) =>
        new Map(personIds.map((personId) => [personId, []] as const)),
    );
    listEffectivePersonSocialHandlesByPersonIdsMock.mockResolvedValue(
      new Map([
        [
          "person-heather",
          {
            person_id: "person-heather",
            facebook_handle: null,
            instagram_handle: "heathergay",
            tiktok_handle: null,
            twitter_handle: "HeatherGay29",
            youtube_handle: null,
          },
        ],
        [
          "person-andy",
          {
            person_id: "person-andy",
            facebook_handle: null,
            instagram_handle: null,
            tiktok_handle: null,
            twitter_handle: null,
            youtube_handle: null,
          },
        ],
      ]),
    );

    const payload = await getSocialLandingPayload();

    expect(payload.people_profiles.map((person) => person.full_name)).toEqual([
      "Heather Gay",
    ]);
    expect(payload.people_profiles[0]?.handles).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          platform: "instagram",
          handle: "heathergay",
        }),
        expect.objectContaining({
          platform: "twitter",
          handle: "heathergay29",
        }),
      ]),
    );
  });

  it("includes a show when a cast member matches a SocialBlade row by person_id", async () => {
    queryMock.mockResolvedValue({
      rows: [
        {
          person_id: "person-heather",
          platform: "instagram",
          account_handle: "heathergay",
          scraped_at: "2026-04-20T12:00:00.000Z",
          updated_at: "2026-04-20T12:05:00.000Z",
          stats_refreshed: true,
          socialblade_url: "https://socialblade.com/instagram/user/heathergay",
        },
      ],
    });

    const payload = await getSocialLandingPayload();
    const [sql, params] = findSocialBladeGrowthDataQueryCall();

    expect(sql).toContain("WHERE platform = ANY($1::text[])");
    expect(sql).toContain("person_id = ANY($2::uuid[])");
    expect(sql).toMatch(/\baccount_handle\s*=\s*ANY\(\$3::text\[\]\)/);
    expect(sql).toContain("id::text AS id");
    expect(sql).toContain("ORDER BY");
    expect(sql).toContain("id ASC");
    expect(sql).not.toContain("WHERE lower(platform) = ANY");
    expect(sql).not.toContain("person_id::text = ANY");
    expect(sql).not.toContain("person_id IS NULL");
    expect(sql).not.toContain("regexp_replace");
    expect(sql).not.toContain("ltrim(account_handle");
    expect(sql).not.toContain("lower(account_handle");
    expect(sql).not.toContain("concat(");
    expect(params[0]).toEqual(["instagram", "tiktok", "youtube", "facebook"]);
    expect(params[2]).toContain("andycohen");
    expect(params[2]).toContain("@andycohen");
    expect(params[2]).toContain("user/andycohen");
    expect(params[2]).toContain("c/andycohen");
    expect(params[2]).toContain("channel/andycohen");
    expect(params[2]).toContain("userandycohen");

    expect(payload.cast_socialblade_shows).toEqual([
      expect.objectContaining({
        show_id: "show-rhoslc",
        show_name: "The Real Housewives of Salt Lake City",
        platform_counts: { instagram: 1 },
        cast_member_count: 1,
        latest_scraped_at: "2026-04-20T12:00:00.000Z",
        members: [
          expect.objectContaining({
            person_id: "person-heather",
            full_name: "Heather Gay",
            photo_url: null,
            accounts: [
              expect.objectContaining({
                platform: "instagram",
                handle: "heathergay",
                display_label: "@heathergay",
                account_href: "/social/instagram/heathergay",
                socialblade_url:
                  "https://socialblade.com/instagram/user/heathergay",
                stats_refreshed: true,
              }),
            ],
          }),
        ],
      }),
    ]);
  });

  it("does not emit stale person-linked SocialBlade rows for old handles", async () => {
    listPrimaryPersonExternalIdsByPersonIdsMock.mockImplementation(
      async (personIds: readonly string[]) =>
        new Map(
          personIds.map((personId) => {
            if (personId === "person-heather") {
              return [
                personId,
                [
                  {
                    id: 7,
                    source_id: "instagram",
                    external_id: "heathergaynew",
                    is_primary: true,
                    valid_from: null,
                    valid_to: null,
                    observed_at: null,
                  },
                ],
              ] as const;
            }
            return [personId, []] as const;
          }),
        ),
    );
    queryMock.mockResolvedValue({
      rows: [
        {
          person_id: "person-heather",
          platform: "instagram",
          account_handle: "heathergay",
          scraped_at: "2026-04-20T12:00:00.000Z",
          updated_at: "2026-04-20T12:05:00.000Z",
          stats_refreshed: true,
          socialblade_url: "https://socialblade.com/instagram/user/heathergay",
        },
      ],
    });

    const payload = await getSocialLandingPayload();

    expect(payload.cast_socialblade_shows).toEqual([]);
  });

  it("matches account-only SocialBlade rows by normalized platform and handle", async () => {
    queryMock.mockResolvedValue({
      rows: [
        {
          person_id: null,
          platform: "youtube",
          account_handle: "@AndyCohen",
          scraped_at: "2026-04-21T12:00:00.000Z",
          updated_at: "2026-04-21T12:05:00.000Z",
          stats_refreshed: false,
          socialblade_url: null,
        },
      ],
    });

    const payload = await getSocialLandingPayload();

    expect(payload.cast_socialblade_shows).toEqual([
      expect.objectContaining({
        show_id: "show-wwhl",
        platform_counts: { youtube: 1 },
        members: [
          expect.objectContaining({
            person_id: "person-andy",
            full_name: "Andy Cohen",
            accounts: [
              expect.objectContaining({
                platform: "youtube",
                handle: "andycohen",
                display_label: "andycohen",
                account_href: "/social/youtube/andycohen",
                stats_refreshed: false,
              }),
            ],
          }),
        ],
      }),
    ]);
  });

  it("fetches name-cased SocialBlade account handles while keeping plain-column SQL", async () => {
    const storedRows = [
      {
        person_id: null,
        platform: "instagram",
        account_handle: "@AndyCohen",
        scraped_at: "2026-04-21T12:00:00.000Z",
        updated_at: "2026-04-21T12:05:00.000Z",
        stats_refreshed: true,
        socialblade_url: "https://socialblade.com/instagram/user/AndyCohen",
      },
      {
        person_id: null,
        platform: "youtube",
        account_handle: "user/AndyCohen",
        scraped_at: "2026-04-21T12:10:00.000Z",
        updated_at: "2026-04-21T12:15:00.000Z",
        stats_refreshed: true,
        socialblade_url: "https://socialblade.com/youtube/user/AndyCohen",
      },
    ];
    queryMock.mockImplementation(async (_sql: string, params: unknown[]) => {
      if (
        String(_sql).includes("landing_social_progress") ||
        String(_sql).includes("landing_social_scrape_job_health")
      ) {
        return { rows: [] };
      }
      const accountHandleCandidates = params[2] as string[];
      return {
        rows: storedRows.filter((row) =>
          accountHandleCandidates.includes(row.account_handle),
        ),
      };
    });

    const payload = await getSocialLandingPayload();
    const [sql, params] = findSocialBladeGrowthDataQueryCall();

    expect(sql).toMatch(/\baccount_handle\s*=\s*ANY\(\$3::text\[\]\)/);
    expect(sql).not.toContain("lower(account_handle");
    expect(params[2]).toEqual(
      expect.arrayContaining(["@AndyCohen", "user/AndyCohen"]),
    );
    expect(payload.cast_socialblade_shows).toEqual([
      expect.objectContaining({
        show_id: "show-wwhl",
        platform_counts: { instagram: 1, youtube: 1 },
        members: [
          expect.objectContaining({
            person_id: "person-andy",
            full_name: "Andy Cohen",
            accounts: expect.arrayContaining([
              expect.objectContaining({
                platform: "instagram",
                handle: "andycohen",
                account_href: "/social/instagram/andycohen",
                socialblade_url:
                  "https://socialblade.com/instagram/user/AndyCohen",
              }),
              expect.objectContaining({
                platform: "youtube",
                handle: "andycohen",
                account_href: "/social/youtube/andycohen",
                socialblade_url: "https://socialblade.com/youtube/user/AndyCohen",
              }),
            ]),
          }),
        ],
      }),
    ]);
  });

  it("omits account-only SocialBlade rows for ambiguous current handles", async () => {
    listPrimaryPersonExternalIdsByPersonIdsMock.mockImplementation(
      async (personIds: readonly string[]) =>
        new Map(
          personIds.map((personId) => {
            if (personId === "person-andy" || personId === "person-producer") {
              return [
                personId,
                [
                  {
                    id: personId === "person-andy" ? 8 : 9,
                    source_id: "youtube",
                    external_id: "@sharedchannel",
                    is_primary: true,
                    valid_from: null,
                    valid_to: null,
                    observed_at: null,
                  },
                ],
              ] as const;
            }
            return [personId, []] as const;
          }),
        ),
    );
    queryMock.mockResolvedValue({
      rows: [
        {
          person_id: null,
          platform: "youtube",
          account_handle: "sharedchannel",
          scraped_at: "2026-04-21T12:00:00.000Z",
          updated_at: "2026-04-21T12:05:00.000Z",
          stats_refreshed: true,
          socialblade_url: "https://socialblade.com/youtube/user/sharedchannel",
        },
      ],
    });

    const payload = await getSocialLandingPayload();

    expect(payload.cast_socialblade_shows).toEqual([]);
  });

  it("allows person-specific SocialBlade rows for ambiguous current handles", async () => {
    listPrimaryPersonExternalIdsByPersonIdsMock.mockImplementation(
      async (personIds: readonly string[]) =>
        new Map(
          personIds.map((personId) => {
            if (personId === "person-andy" || personId === "person-producer") {
              return [
                personId,
                [
                  {
                    id: personId === "person-andy" ? 8 : 9,
                    source_id: "youtube",
                    external_id: "@sharedchannel",
                    is_primary: true,
                    valid_from: null,
                    valid_to: null,
                    observed_at: null,
                  },
                ],
              ] as const;
            }
            return [personId, []] as const;
          }),
        ),
    );
    queryMock.mockResolvedValue({
      rows: [
        {
          person_id: "person-andy",
          platform: "youtube",
          account_handle: "sharedchannel",
          scraped_at: "2026-04-21T12:00:00.000Z",
          updated_at: "2026-04-21T12:05:00.000Z",
          stats_refreshed: true,
          socialblade_url: "https://socialblade.com/youtube/user/sharedchannel",
        },
      ],
    });

    const payload = await getSocialLandingPayload();

    expect(payload.cast_socialblade_shows).toEqual([
      expect.objectContaining({
        show_id: "show-wwhl",
        platform_counts: { youtube: 1 },
        members: [
          expect.objectContaining({
            person_id: "person-andy",
            full_name: "Andy Cohen",
            accounts: [
              expect.objectContaining({
                platform: "youtube",
                handle: "sharedchannel",
                account_href: "/social/youtube/sharedchannel",
              }),
            ],
          }),
        ],
      }),
    ]);
  });

  it("assigns a matching handle row to the current cast member when row person_id is stale", async () => {
    queryMock.mockResolvedValue({
      rows: [
        {
          person_id: "person-stale-owner",
          platform: "youtube",
          account_handle: "andycohen",
          scraped_at: "2026-04-21T12:00:00.000Z",
          updated_at: "2026-04-21T12:05:00.000Z",
          stats_refreshed: true,
          socialblade_url: "https://socialblade.com/youtube/user/andycohen",
        },
      ],
    });

    const payload = await getSocialLandingPayload();

    expect(payload.cast_socialblade_shows).toEqual([
      expect.objectContaining({
        show_id: "show-wwhl",
        platform_counts: { youtube: 1 },
        members: [
          expect.objectContaining({
            person_id: "person-andy",
            full_name: "Andy Cohen",
            accounts: [
              expect.objectContaining({
                platform: "youtube",
                handle: "andycohen",
                account_href: "/social/youtube/andycohen",
                stats_refreshed: true,
              }),
            ],
          }),
        ],
      }),
    ]);
  });

  it("matches legacy account-only YouTube SocialBlade route handles to current cast handles", async () => {
    queryMock.mockResolvedValue({
      rows: [
        {
          person_id: null,
          platform: "youtube",
          account_handle: "user/AndyCohen",
          scraped_at: "2026-04-21T12:00:00.000Z",
          updated_at: "2026-04-21T12:05:00.000Z",
          stats_refreshed: true,
          socialblade_url: "https://socialblade.com/youtube/user/andycohen",
        },
      ],
    });

    const payload = await getSocialLandingPayload();

    expect(payload.cast_socialblade_shows).toEqual([
      expect.objectContaining({
        show_id: "show-wwhl",
        platform_counts: { youtube: 1 },
        members: [
          expect.objectContaining({
            person_id: "person-andy",
            full_name: "Andy Cohen",
            accounts: [
              expect.objectContaining({
                platform: "youtube",
                handle: "andycohen",
                display_label: "andycohen",
                account_href: "/social/youtube/andycohen",
                socialblade_url: "https://socialblade.com/youtube/user/andycohen",
                stats_refreshed: true,
              }),
            ],
          }),
        ],
      }),
    ]);
  });

  it("fetches mixed-case raw YouTube route candidates before payload matching", async () => {
    listEffectivePersonSocialHandlesByPersonIdsMock.mockResolvedValue(
      new Map([
        [
          "person-andy",
          {
            person_id: "person-andy",
            facebook_handle: null,
            instagram_handle: null,
            tiktok_handle: null,
            twitter_handle: null,
            youtube_handle: "user/AndyCohen",
          },
        ],
      ]),
    );
    const storedRows = [
      {
        person_id: null,
        platform: "youtube",
        account_handle: "user/AndyCohen",
        scraped_at: "2026-04-21T12:00:00.000Z",
        updated_at: "2026-04-21T12:05:00.000Z",
        stats_refreshed: true,
        socialblade_url: "https://socialblade.com/youtube/user/AndyCohen",
      },
    ];
    queryMock.mockImplementation(async (_sql: string, params: unknown[]) => {
      if (
        String(_sql).includes("landing_social_progress") ||
        String(_sql).includes("landing_social_scrape_job_health")
      ) {
        return { rows: [] };
      }
      const accountHandleCandidates = params[2] as string[];
      return {
        rows: storedRows.filter((row) =>
          accountHandleCandidates.includes(row.account_handle),
        ),
      };
    });

    const payload = await getSocialLandingPayload();
    const [, params] = findSocialBladeGrowthDataQueryCall();

    expect(params[2]).toContain("user/AndyCohen");
    expect(payload.cast_socialblade_shows).toEqual([
      expect.objectContaining({
        show_id: "show-wwhl",
        platform_counts: { youtube: 1 },
        members: [
          expect.objectContaining({
            person_id: "person-andy",
            full_name: "Andy Cohen",
            accounts: [
              expect.objectContaining({
                platform: "youtube",
                handle: "andycohen",
                display_label: "andycohen",
                account_href: "/social/youtube/andycohen",
                socialblade_url: "https://socialblade.com/youtube/user/AndyCohen",
                stats_refreshed: true,
              }),
            ],
          }),
        ],
      }),
    ]);
  });

  it("matches persisted stripped legacy YouTube SocialBlade handles to current cast handles", async () => {
    queryMock.mockResolvedValue({
      rows: [
        {
          person_id: null,
          platform: "youtube",
          account_handle: "userandycohen",
          scraped_at: "2026-04-21T12:00:00.000Z",
          updated_at: "2026-04-21T12:05:00.000Z",
          stats_refreshed: true,
          socialblade_url: "https://socialblade.com/youtube/user/andycohen",
        },
      ],
    });

    const payload = await getSocialLandingPayload();

    expect(payload.cast_socialblade_shows).toEqual([
      expect.objectContaining({
        show_id: "show-wwhl",
        platform_counts: { youtube: 1 },
        members: [
          expect.objectContaining({
            person_id: "person-andy",
            full_name: "Andy Cohen",
            accounts: [
              expect.objectContaining({
                platform: "youtube",
                handle: "andycohen",
                display_label: "andycohen",
                account_href: "/social/youtube/andycohen",
                socialblade_url: "https://socialblade.com/youtube/user/andycohen",
                stats_refreshed: true,
              }),
            ],
          }),
        ],
      }),
    ]);
  });

  it("prefers exact YouTube handles over colliding stripped legacy aliases", async () => {
    listPrimaryPersonExternalIdsByPersonIdsMock.mockImplementation(
      async (personIds: readonly string[]) =>
        new Map(
          personIds.map((personId) => {
            if (personId === "person-andy") {
              return [
                personId,
                [
                  {
                    id: 8,
                    source_id: "youtube",
                    external_id: "@andycohen",
                    is_primary: true,
                    valid_from: null,
                    valid_to: null,
                    observed_at: null,
                  },
                ],
              ] as const;
            }
            if (personId === "person-producer") {
              return [
                personId,
                [
                  {
                    id: 9,
                    source_id: "youtube",
                    external_id: "@userandycohen",
                    is_primary: true,
                    valid_from: null,
                    valid_to: null,
                    observed_at: null,
                  },
                ],
              ] as const;
            }
            return [personId, []] as const;
          }),
        ),
    );
    queryMock.mockResolvedValue({
      rows: [
        {
          person_id: null,
          platform: "youtube",
          account_handle: "userandycohen",
          scraped_at: "2026-04-21T12:00:00.000Z",
          updated_at: "2026-04-21T12:05:00.000Z",
          stats_refreshed: true,
          socialblade_url: "https://socialblade.com/youtube/user/userandycohen",
        },
      ],
    });

    const payload = await getSocialLandingPayload();

    expect(payload.cast_socialblade_shows).toEqual([
      expect.objectContaining({
        show_id: "show-wwhl",
        platform_counts: { youtube: 1 },
        members: [
          expect.objectContaining({
            person_id: "person-producer",
            full_name: "Producer Without Handles",
            accounts: [
              expect.objectContaining({
                platform: "youtube",
                handle: "userandycohen",
                account_href: "/social/youtube/userandycohen",
              }),
            ],
          }),
        ],
      }),
    ]);
  });

  it("chooses the newest SocialBlade row when duplicate handle rows match", async () => {
    queryMock.mockResolvedValue({
      rows: [
        {
          person_id: null,
          platform: "youtube",
          account_handle: "andycohen",
          scraped_at: "2026-04-20T12:00:00.000Z",
          updated_at: "2026-04-20T12:05:00.000Z",
          created_at: "2026-04-20T12:01:00.000Z",
          stats_refreshed: false,
          socialblade_url: "https://socialblade.com/youtube/user/andycohen-old",
        },
        {
          person_id: null,
          platform: "youtube",
          account_handle: "andycohen",
          scraped_at: "2026-04-21T12:00:00.000Z",
          updated_at: "2026-04-21T12:05:00.000Z",
          created_at: "2026-04-21T12:01:00.000Z",
          stats_refreshed: true,
          socialblade_url: "https://socialblade.com/youtube/user/andycohen-new",
        },
      ],
    });

    const payload = await getSocialLandingPayload();

    expect(
      payload.cast_socialblade_shows[0]?.members[0]?.accounts[0],
    ).toMatchObject({
      handle: "andycohen",
      socialblade_url: "https://socialblade.com/youtube/user/andycohen-new",
      scraped_at: "2026-04-21T12:00:00.000Z",
      stats_refreshed: true,
    });
  });

  it("prefers a person-specific SocialBlade row over a newer generic duplicate", async () => {
    queryMock.mockResolvedValue({
      rows: [
        {
          person_id: null,
          platform: "youtube",
          account_handle: "andycohen",
          scraped_at: "2026-04-23T12:00:00.000Z",
          updated_at: "2026-04-23T12:05:00.000Z",
          created_at: "2026-04-23T12:01:00.000Z",
          stats_refreshed: false,
          socialblade_url: "https://socialblade.com/youtube/user/andycohen-generic",
        },
        {
          person_id: "person-andy",
          platform: "youtube",
          account_handle: "andycohen",
          scraped_at: "2026-04-21T12:00:00.000Z",
          updated_at: "2026-04-21T12:05:00.000Z",
          created_at: "2026-04-21T12:01:00.000Z",
          stats_refreshed: true,
          socialblade_url: "https://socialblade.com/youtube/user/andycohen-specific",
        },
      ],
    });

    const payload = await getSocialLandingPayload();

    expect(
      payload.cast_socialblade_shows[0]?.members[0]?.accounts[0],
    ).toMatchObject({
      handle: "andycohen",
      socialblade_url: "https://socialblade.com/youtube/user/andycohen-specific",
      scraped_at: "2026-04-21T12:00:00.000Z",
      stats_refreshed: true,
    });
  });

  it("uses stable id order when duplicate SocialBlade rows have equal metadata", async () => {
    queryMock.mockResolvedValue({
      rows: [
        {
          id: "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb",
          person_id: null,
          platform: "youtube",
          account_handle: "andycohen",
          scraped_at: "2026-04-21T12:00:00.000Z",
          updated_at: "2026-04-21T12:05:00.000Z",
          created_at: "2026-04-21T12:01:00.000Z",
          stats_refreshed: false,
          socialblade_url: "https://socialblade.com/youtube/user/andycohen-b",
        },
        {
          id: "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
          person_id: null,
          platform: "youtube",
          account_handle: "andycohen",
          scraped_at: "2026-04-21T12:00:00.000Z",
          updated_at: "2026-04-21T12:05:00.000Z",
          created_at: "2026-04-21T12:01:00.000Z",
          stats_refreshed: true,
          socialblade_url: "https://socialblade.com/youtube/user/andycohen-a",
        },
      ],
    });

    const payload = await getSocialLandingPayload();

    expect(
      payload.cast_socialblade_shows[0]?.members[0]?.accounts[0],
    ).toMatchObject({
      handle: "andycohen",
      socialblade_url: "https://socialblade.com/youtube/user/andycohen-a",
      stats_refreshed: true,
    });
  });

  it("omits unsupported platforms and shows with no SocialBlade rows", async () => {
    queryMock.mockResolvedValue({
      rows: [
        {
          person_id: "person-heather",
          platform: "twitter",
          account_handle: "heathergay",
          scraped_at: "2026-04-22T12:00:00.000Z",
          updated_at: "2026-04-22T12:05:00.000Z",
          stats_refreshed: true,
          socialblade_url: "https://example.test/unsupported",
        },
        {
          person_id: null,
          platform: "facebook",
          account_handle: "unmatched-account",
          scraped_at: "2026-04-22T13:00:00.000Z",
          updated_at: "2026-04-22T13:05:00.000Z",
          stats_refreshed: true,
          socialblade_url: null,
        },
      ],
    });

    const payload = await getSocialLandingPayload();

    expect(payload.cast_socialblade_shows).toEqual([]);
  });

  it("returns an empty cast SocialBlade section when storage is unavailable without breaking the landing payload", async () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => undefined);
    queryMock.mockRejectedValue(new Error("relation does not exist"));

    const payload = await getSocialLandingPayload();

    expect(payload.cast_socialblade_shows).toEqual([]);
    expect(payload.network_sets).toHaveLength(1);
    expect(payload.show_sets).toHaveLength(2);
    expect(payload.people_profiles.map((person) => person.full_name)).toEqual([
      "Andy Cohen",
      "Heather Gay",
    ]);
    expect(warnSpy).toHaveBeenCalledWith(
      "[social-landing] Failed to load cast SocialBlade rows",
      expect.any(Error),
    );

    warnSpy.mockRestore();
  });

  it("marks the landing payload as not cacheable when cast summary loading fails closed", async () => {
    fetchAdminBackendJsonMock.mockRejectedValue(new Error("cast summary timeout"));

    const result = await getSocialLandingPayloadResult();

    expect(result.cacheable).toBe(false);
    expect(result.payload.cast_socialblade_shows).toEqual([]);
    expect(result.payload.people_profiles).toEqual([]);
  });

  it("marks the landing payload as not cacheable when SocialBlade storage loading fails closed", async () => {
    queryMock.mockRejectedValue(new Error("relation does not exist"));

    const result = await getSocialLandingPayloadResult();

    expect(result.cacheable).toBe(false);
    expect(result.payload.cast_socialblade_shows).toEqual([]);
    expect(result.payload.network_sets).toHaveLength(1);
    expect(result.payload.show_sets).toHaveLength(2);
  });

  it("falls back to local landing summary when the authenticated backend summary times out", async () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => undefined);
    fetchSocialBackendJsonMock.mockRejectedValueOnce(new Error("TRR-Backend request timed out."));

    const result = await getSocialLandingPayloadResult({
      uid: "admin-user",
      email: "admin@example.test",
      verifiedAt: 1_776_000_000,
    });

    expect(fetchSocialBackendJsonMock).toHaveBeenCalledWith(
      "/landing-summary",
      expect.objectContaining({
        fallbackError: "Failed to fetch social landing summary",
      }),
    );
    expect(getCoveredShowsMock).toHaveBeenCalled();
    expect(result.cacheable).toBe(false);
    expect(result.payload.show_sets).toHaveLength(2);
    expect(result.payload.reddit_dashboard).toEqual({
      active_community_count: 2,
      archived_community_count: 1,
      show_count: 2,
    });
    expect(warnSpy).toHaveBeenCalledWith(
      "[social-landing] Failed to load backend landing summary; using local fallback",
      expect.any(Error),
    );

    warnSpy.mockRestore();
  });
});
