import { afterEach, describe, expect, it } from "vitest";
import { NextRequest } from "next/server";
import { proxy } from "@/proxy";

const originalEnv = {
  NODE_ENV: process.env.NODE_ENV,
  ADMIN_APP_ORIGIN: process.env.ADMIN_APP_ORIGIN,
  ADMIN_APP_BASE_DOMAIN: process.env.ADMIN_APP_BASE_DOMAIN,
  ADMIN_APP_DERIVE_FROM_REQUEST_HOST: process.env.ADMIN_APP_DERIVE_FROM_REQUEST_HOST,
  ADMIN_APP_HOST_PREFIX: process.env.ADMIN_APP_HOST_PREFIX,
  ADMIN_APP_HOSTS: process.env.ADMIN_APP_HOSTS,
  ADMIN_ENFORCE_HOST: process.env.ADMIN_ENFORCE_HOST,
  ADMIN_STRICT_HOST_ROUTING: process.env.ADMIN_STRICT_HOST_ROUTING,
  PORTLESS_ADMIN_URL: process.env.PORTLESS_ADMIN_URL,
  PORTLESS_URL: process.env.PORTLESS_URL,
  TRR_LEGACY_LOCAL_ADMIN_FALLBACK: process.env.TRR_LEGACY_LOCAL_ADMIN_FALLBACK,
};

afterEach(() => {
  if (typeof originalEnv.NODE_ENV === "undefined") {
    delete process.env.NODE_ENV;
  } else {
    process.env.NODE_ENV = originalEnv.NODE_ENV;
  }
  if (typeof originalEnv.ADMIN_APP_ORIGIN === "undefined") {
    delete process.env.ADMIN_APP_ORIGIN;
  } else {
    process.env.ADMIN_APP_ORIGIN = originalEnv.ADMIN_APP_ORIGIN;
  }
  if (typeof originalEnv.ADMIN_APP_BASE_DOMAIN === "undefined") {
    delete process.env.ADMIN_APP_BASE_DOMAIN;
  } else {
    process.env.ADMIN_APP_BASE_DOMAIN = originalEnv.ADMIN_APP_BASE_DOMAIN;
  }
  if (typeof originalEnv.ADMIN_APP_DERIVE_FROM_REQUEST_HOST === "undefined") {
    delete process.env.ADMIN_APP_DERIVE_FROM_REQUEST_HOST;
  } else {
    process.env.ADMIN_APP_DERIVE_FROM_REQUEST_HOST = originalEnv.ADMIN_APP_DERIVE_FROM_REQUEST_HOST;
  }
  if (typeof originalEnv.ADMIN_APP_HOST_PREFIX === "undefined") {
    delete process.env.ADMIN_APP_HOST_PREFIX;
  } else {
    process.env.ADMIN_APP_HOST_PREFIX = originalEnv.ADMIN_APP_HOST_PREFIX;
  }
  if (typeof originalEnv.ADMIN_APP_HOSTS === "undefined") {
    delete process.env.ADMIN_APP_HOSTS;
  } else {
    process.env.ADMIN_APP_HOSTS = originalEnv.ADMIN_APP_HOSTS;
  }
  if (typeof originalEnv.ADMIN_ENFORCE_HOST === "undefined") {
    delete process.env.ADMIN_ENFORCE_HOST;
  } else {
    process.env.ADMIN_ENFORCE_HOST = originalEnv.ADMIN_ENFORCE_HOST;
  }
  if (typeof originalEnv.ADMIN_STRICT_HOST_ROUTING === "undefined") {
    delete process.env.ADMIN_STRICT_HOST_ROUTING;
  } else {
    process.env.ADMIN_STRICT_HOST_ROUTING = originalEnv.ADMIN_STRICT_HOST_ROUTING;
  }
  if (typeof originalEnv.PORTLESS_ADMIN_URL === "undefined") {
    delete process.env.PORTLESS_ADMIN_URL;
  } else {
    process.env.PORTLESS_ADMIN_URL = originalEnv.PORTLESS_ADMIN_URL;
  }
  if (typeof originalEnv.PORTLESS_URL === "undefined") {
    delete process.env.PORTLESS_URL;
  } else {
    process.env.PORTLESS_URL = originalEnv.PORTLESS_URL;
  }
  if (typeof originalEnv.TRR_LEGACY_LOCAL_ADMIN_FALLBACK === "undefined") {
    delete process.env.TRR_LEGACY_LOCAL_ADMIN_FALLBACK;
  } else {
    process.env.TRR_LEGACY_LOCAL_ADMIN_FALLBACK = originalEnv.TRR_LEGACY_LOCAL_ADMIN_FALLBACK;
  }
});

function followProxyRedirects(initialUrl: string, limit = 5): { locations: string[]; statuses: number[] } {
  const locations: string[] = [];
  const statuses: number[] = [];
  const seen = new Set<string>();
  let currentUrl = initialUrl;

  for (let index = 0; index < limit; index += 1) {
    if (seen.has(currentUrl)) {
      throw new Error(`Proxy redirect loop detected at ${currentUrl}`);
    }
    seen.add(currentUrl);

    const response = proxy(new NextRequest(currentUrl));
    statuses.push(response.status);

    const location = response.headers.get("location");
    if ((response.status === 307 || response.status === 308) && location) {
      locations.push(location);
      currentUrl = location;
      continue;
    }

    return { locations, statuses };
  }

  throw new Error(`Proxy redirect chain exceeded ${limit} hops from ${initialUrl}`);
}

describe("admin host proxy", () => {
  it("keeps loopback admin paths local unless the legacy local admin fallback is enabled", () => {
    process.env.NODE_ENV = "development";
    delete process.env.ADMIN_ENFORCE_HOST;
    delete process.env.ADMIN_APP_ORIGIN;
    delete process.env.ADMIN_APP_HOSTS;
    delete process.env.TRR_LEGACY_LOCAL_ADMIN_FALLBACK;
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/admin/fonts");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("can still redirect loopback admin paths through the explicit legacy local admin fallback", () => {
    process.env.NODE_ENV = "development";
    delete process.env.ADMIN_ENFORCE_HOST;
    delete process.env.ADMIN_APP_ORIGIN;
    delete process.env.ADMIN_APP_HOSTS;
    process.env.TRR_LEGACY_LOCAL_ADMIN_FALLBACK = "1";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/admin/fonts");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("http://admin.localhost:3000/admin/fonts");
  });

  it("derives the local admin origin by prefixing the public host with admin", () => {
    process.env.NODE_ENV = "development";
    delete process.env.ADMIN_ENFORCE_HOST;
    delete process.env.ADMIN_APP_ORIGIN;
    delete process.env.ADMIN_APP_HOSTS;
    delete process.env.TRR_LEGACY_LOCAL_ADMIN_FALLBACK;
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://thereality.test:3000/admin/fonts");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("http://admin.thereality.test:3000/admin/fonts");
  });

  it("can derive the production admin origin from a configured base domain", () => {
    process.env.NODE_ENV = "production";
    delete process.env.ADMIN_APP_ORIGIN;
    process.env.ADMIN_APP_BASE_DOMAIN = "thereality.report";
    process.env.ADMIN_APP_HOST_PREFIX = "admin";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("https://thereality.report/admin/fonts");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("https://admin.thereality.report/admin/fonts");
  });

  it("can derive the production admin origin from the request host when explicitly enabled", () => {
    process.env.NODE_ENV = "production";
    delete process.env.ADMIN_APP_ORIGIN;
    delete process.env.ADMIN_APP_BASE_DOMAIN;
    process.env.ADMIN_APP_DERIVE_FROM_REQUEST_HOST = "true";
    process.env.ADMIN_APP_HOST_PREFIX = "admin";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("https://thereality.report/admin/fonts");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("https://admin.thereality.report/admin/fonts");
  });

  it("allows /api/admin requests on localhost in development by default allowlist", () => {
    process.env.NODE_ENV = "development";
    delete process.env.ADMIN_ENFORCE_HOST;
    delete process.env.ADMIN_APP_ORIGIN;
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/api/admin/auth/status");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("redirects /admin requests on public host to admin origin", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/admin/fonts?tab=buttons");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(
      "http://admin.localhost:3000/admin/fonts?tab=buttons",
    );
  });

  it("keeps Portless admin redirects on the clean admin host when Next uses an alternate port", () => {
    process.env.ADMIN_APP_ORIGIN = "https://admin.trr.localhost";
    process.env.ADMIN_APP_HOSTS = "admin.trr.localhost,trr.localhost,admin.localhost,localhost,127.0.0.1,[::1]";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3001/admin/social/instagram/bravotv/posts");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(
      "https://admin.trr.localhost/admin/social/instagram/bravotv/posts",
    );
  });

  it("serves the clean Portless admin host root as the admin dashboard", () => {
    process.env.NODE_ENV = "development";
    process.env.ADMIN_APP_ORIGIN = "https://admin.trr.localhost";
    process.env.ADMIN_APP_HOSTS = "admin.trr.localhost,trr.localhost,admin.localhost,localhost,127.0.0.1,[::1]";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("https://admin.trr.localhost/");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("x-middleware-rewrite")).toBeNull();
    expect(response.headers.get("location")).toBe("https://admin.trr.localhost/admin");
  });

  it("recognizes the clean Portless admin host from forwarded host headers", () => {
    process.env.NODE_ENV = "development";
    process.env.ADMIN_APP_ORIGIN = "https://admin.trr.localhost";
    process.env.ADMIN_APP_HOSTS = "admin.trr.localhost,trr.localhost,admin.localhost,localhost,127.0.0.1,[::1]";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://127.0.0.1:3001/", {
      headers: {
        "x-forwarded-host": "admin.trr.localhost",
      },
    });
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("x-middleware-rewrite")).toBeNull();
    expect(response.headers.get("location")).toBe("https://admin.trr.localhost/admin");
  });

  it("derives Portless admin origin without carrying the underlying Next port", () => {
    process.env.NODE_ENV = "development";
    delete process.env.ADMIN_APP_ORIGIN;
    delete process.env.PORTLESS_ADMIN_URL;
    process.env.PORTLESS_URL = "https://trr.localhost";
    process.env.ADMIN_APP_HOSTS = "admin.trr.localhost,trr.localhost,admin.localhost,localhost,127.0.0.1,[::1]";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3001/admin/social/instagram/bravotv/posts");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(
      "https://admin.trr.localhost/admin/social/instagram/bravotv/posts",
    );
  });

  it("rewrites Portless short admin paths through the local HTTP Next origin", () => {
    process.env.NODE_ENV = "development";
    process.env.ADMIN_APP_ORIGIN = "https://admin.trr.localhost";
    process.env.ADMIN_APP_HOSTS = "admin.trr.localhost,trr.localhost,admin.localhost,localhost,127.0.0.1,[::1]";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("https://localhost:3002/social", {
      headers: {
        "x-forwarded-host": "admin.trr.localhost",
      },
    });
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-rewrite")).toBe("http://localhost:3002/admin/social");
  });

  it("redirects /design-system requests on public host to admin origin", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/design-system/components/layout");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(
      "http://admin.localhost:3000/design-system/components/layout",
    );
  });

  it("keeps /shows requests on the public host", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/shows/rhoslc/s6/social/reddit");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("redirects /games requests on public host to admin origin", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/games");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("http://admin.localhost:3000/games");
  });

  it.each([
    ["/screenlaytics", "https://admin.trr.localhost/screenalytics"],
    ["/admin/screenalytics", "https://admin.trr.localhost/screenalytics"],
    ["/admin/screenlaytics", "https://admin.trr.localhost/screenalytics"],
    ["/admin/cast-screentime", "https://admin.trr.localhost/screenalytics"],
  ])("redirects legacy Screenalytics path %s to the canonical Screenalytics path", (pathname, expectedLocation) => {
    process.env.ADMIN_APP_ORIGIN = "https://admin.trr.localhost";
    process.env.ADMIN_APP_HOSTS = "admin.trr.localhost,trr.localhost,admin.localhost,localhost,127.0.0.1,[::1]";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(`https://admin.trr.localhost${pathname}`);
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(expectedLocation);
  });

  it.each([
    "http://localhost:3000/screenalytics?run=demo",
    "http://localhost:3000/admin/cast-screentime?run=demo",
  ])("canonicalizes %s to the Portless Screenalytics run URL", (url) => {
    process.env.ADMIN_APP_ORIGIN = "https://admin.trr.localhost";
    process.env.ADMIN_APP_HOSTS = "admin.trr.localhost,trr.localhost,admin.localhost,localhost,127.0.0.1,[::1]";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(url);
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("https://admin.trr.localhost/screenalytics/runs/demo");
  });

  it("canonicalizes the RHOBH S5 E16 test extra setup query to the clean episode URL", () => {
    process.env.ADMIN_APP_ORIGIN = "https://admin.trr.localhost";
    process.env.ADMIN_APP_HOSTS = "admin.trr.localhost,trr.localhost,admin.localhost,localhost,127.0.0.1,[::1]";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const query = new URLSearchParams({
      owner_scope: "season",
      owner_id: "98ac397a-3928-4583-92bc-25ea84c42d89",
      media_type: "extras",
      media_kind: "screenalytics_test",
      media_type_filter: "extras",
      show_id: "909ddc36-ca4d-4b09-8aa5-dd5dd34f987e",
    });
    const request = new NextRequest(`http://localhost:3000/admin/cast-screentime?${query.toString()}`);
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(
      "https://admin.trr.localhost/screenalytics/rhobh/s5/e16/extras/screenalytics-test?media_type_filter=extras",
    );
  });

  it("rewrites canonical Screenalytics run URLs to the internal implementation while keeping the clean URL visible", () => {
    process.env.NODE_ENV = "development";
    process.env.ADMIN_APP_ORIGIN = "https://admin.trr.localhost";
    process.env.ADMIN_APP_HOSTS = "admin.trr.localhost,trr.localhost,admin.localhost,localhost,127.0.0.1,[::1]";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("https://localhost:3002/screenalytics/runs/demo?tab=review", {
      headers: {
        "x-forwarded-host": "admin.trr.localhost",
      },
    });
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-rewrite")).toBe(
      "http://localhost:3002/admin/cast-screentime?tab=review&run_id=demo",
    );
  });

  it("rewrites the canonical Screenalytics RHOBH test-extra setup URL with its default context", () => {
    process.env.NODE_ENV = "development";
    process.env.ADMIN_APP_ORIGIN = "https://admin.trr.localhost";
    process.env.ADMIN_APP_HOSTS = "admin.trr.localhost,trr.localhost,admin.localhost,localhost,127.0.0.1,[::1]";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("https://localhost:3002/screenalytics/rhobh/s5/e16/extras/screenalytics-test", {
      headers: {
        "x-forwarded-host": "admin.trr.localhost",
      },
    });
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-rewrite")).toBe(
      "http://localhost:3002/admin/cast-screentime?owner_scope=episode&owner_id=4eb4ceb4-c13d-4c29-bd0f-8bcde94b6591&show_id=909ddc36-ca4d-4b09-8aa5-dd5dd34f987e&media_type=extras&media_kind=screenalytics_test&prefill_context=screenalytics_test_extra",
    );
  });

  it("does not re-canonicalize the hidden Screenalytics implementation URL during an internal rewrite", () => {
    process.env.NODE_ENV = "development";
    process.env.ADMIN_APP_ORIGIN = "https://admin.trr.localhost";
    process.env.ADMIN_APP_HOSTS = "admin.trr.localhost,trr.localhost,admin.localhost,localhost,127.0.0.1,[::1]";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(
      "http://localhost:3002/admin/cast-screentime?owner_scope=episode&owner_id=4eb4ceb4-c13d-4c29-bd0f-8bcde94b6591&show_id=909ddc36-ca4d-4b09-8aa5-dd5dd34f987e&media_type=extras&media_kind=screenalytics_test&prefill_context=screenalytics_test_extra",
      {
        headers: {
          "x-forwarded-host": "admin.trr.localhost",
          "x-trr-admin-rewrite": "1",
        },
      },
    );
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("location")).toBeNull();
  });

  it.each([
    "/dev-dashboard",
    "/dev-dashboard/instagram-catalog-backfill-mockup",
    "/docs",
    "/groups",
    "/shows/settings",
    "/settings",
    "/surveys",
    "/users",
  ])("redirects %s requests on public host to admin origin", (pathname) => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(`http://localhost:3000${pathname}`);
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(`http://admin.localhost:3000${pathname}`);
  });

  it("keeps root show settings aliases on the public placeholder route", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/rhoslc/settings");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("location")).toBeNull();
  });

  it.each([
    "/social-media",
    "/rhoslc/social",
    "/rhoslc/s6/social/w0",
    "/people/mary-cosby",
  ])("keeps %s on the public host", (pathname) => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(`http://localhost:3000${pathname}`);
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("keeps /people detail routes on the public host", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/people/mary-cosby");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("redirects /people root on public host to admin origin", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/people");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("http://admin.localhost:3000/people");
  });

  it("allows /docs on the canonical admin host", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/docs");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("serves the canonical admin-host root as the admin dashboard", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-rewrite")).toBe("http://admin.localhost:3000/admin");
    expect(response.headers.get("location")).toBeNull();
  });

  it("serves the default local admin UI host root as the admin dashboard in development", () => {
    process.env.NODE_ENV = "development";
    delete process.env.ADMIN_APP_ORIGIN;
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-rewrite")).toBe("http://admin.localhost:3000/admin");
    expect(response.headers.get("location")).toBeNull();
  });

  it("keeps /admin on the canonical admin host as the dashboard route", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/admin");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it.each([
    ["/social-media", "http://admin.localhost:3000/social"],
    ["/admin/social-media", "http://admin.localhost:3000/social"],
    ["/admin/social/reddit", "http://admin.localhost:3000/social/reddit"],
    ["/admin/social/instagram/bravotv", "http://admin.localhost:3000/social/instagram/bravotv"],
    ["/admin/social/instagram/bravotv/posts", "http://admin.localhost:3000/social/instagram/bravotv/posts"],
    ["/admin/social/instagram/bravotv/hashtags", "http://admin.localhost:3000/social/instagram/bravotv/hashtags"],
    ["/admin/social/instagram/bravotv/collaborators-tags", "http://admin.localhost:3000/social/instagram/bravotv/collaborators-tags"],
    ["/admin/social/instagram/bravotv/comments", "http://admin.localhost:3000/social/instagram/bravotv/comments"],
    ["/shows/rhoslc", "http://admin.localhost:3000/rhoslc"],
    ["/admin/design-docs/overview", "http://admin.localhost:3000/design-docs/overview"],
    ["/admin/api-references", "http://admin.localhost:3000/api-references"],
    ["/admin/dev-dashboard/skills-and-agents", "http://admin.localhost:3000/dev-dashboard/skills-and-agents"],
    [
      "/admin/dev-dashboard/instagram-catalog-backfill-mockup",
      "http://admin.localhost:3000/dev-dashboard/instagram-catalog-backfill-mockup",
    ],
  ])("redirects %s to the canonical admin-host URL", (pathname, expectedLocation) => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(`http://admin.localhost:3000${pathname}`);
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(expectedLocation);
  });

  it.each([
    ["/shows", "http://admin.localhost:3000/admin/shows"],
    ["/shows/settings", "http://admin.localhost:3000/admin/shows/settings"],
    ["/social", "http://admin.localhost:3000/admin/social"],
    ["/social/reddit", "http://admin.localhost:3000/admin/social/reddit"],
    ["/design-docs/overview", "http://admin.localhost:3000/admin/design-docs/overview"],
    ["/api-references", "http://admin.localhost:3000/admin/api-references"],
    ["/dev-dashboard/skills-and-agents", "http://admin.localhost:3000/admin/dev-dashboard/skills-and-agents"],
    [
      "/dev-dashboard/instagram-catalog-backfill-mockup",
      "http://admin.localhost:3000/admin/dev-dashboard/instagram-catalog-backfill-mockup",
    ],
    ["/rhoslc", "http://admin.localhost:3000/admin/trr-shows/rhoslc"],
    ["/rhoslc/credits", "http://admin.localhost:3000/admin/trr-shows/rhoslc/credits"],
    ["/rhoslc/social", "http://admin.localhost:3000/admin/trr-shows/rhoslc/social"],
    ["/rhoslc/social/reddit", "http://admin.localhost:3000/admin/trr-shows/rhoslc/social?social_view=reddit"],
    ["/rhoslc/assets/videos", "http://admin.localhost:3000/admin/trr-shows/rhoslc/assets/videos"],
    ["/rhoslc/social/s6", "http://admin.localhost:3000/admin/trr-shows/rhoslc/social"],
    [
      "/rhoslc/social/s6/w0",
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6/social/week/0",
    ],
    [
      "/rhoslc/social/s6/w0/instagram",
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6/social/week/0/instagram",
    ],
    ["/rhoslc/s6", "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6"],
    ["/rhoslc/s6/credits", "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6?tab=credits"],
    ["/rhoslc/s6/social", "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6?tab=social"],
    ["/rhoslc/s6/social/reddit", "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6?tab=social&social_view=reddit"],
    ["/rhoslc/s6/assets/videos", "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6?tab=assets&assets=videos"],
    [
      "/rhoslc/s6/social/w0/details",
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6/social/week/0",
    ],
    [
      "/rhoslc/s6/social/w0/youtube",
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6/social/week/0/youtube",
    ],
  ])("rewrites %s to the internal admin surface while keeping the short URL visible", (pathname, expectedRewrite) => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(`http://admin.localhost:3000${pathname}`);
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-rewrite")).toBe(expectedRewrite);
  });

  // All migrated social-account-profile tabs render at canonical /social/...
  // paths with zero rewrite — Next.js serves the /app/social/... page
  // directly. This locks the fix for the ERR_TOO_MANY_REDIRECTS loop on
  // /social/instagram/bravotv/comments and keeps slug visits stable for every
  // tab, including catalog and socialblade.
  it.each([
    "/social/instagram/bravotv",
    "/social/instagram/bravotv/socialblade",
    "/social/instagram/bravotv/catalog",
    "/social/instagram/bravotv/catalog/alt-1",
    "/social/instagram/bravotv/posts",
    "/social/instagram/bravotv/hashtags",
    "/social/instagram/bravotv/collaborators-tags",
    "/social/instagram/bravotv/comments",
  ])("serves canonical %s on admin host without rewrite or redirect", (pathname) => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(`http://admin.localhost:3000${pathname}`);
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
    expect(response.headers.get("x-middleware-rewrite")).toBeNull();
    expect(response.headers.get("location")).toBeNull();
  });

  it.each([
    ["/social/profiles/instagram/bravotv", "http://admin.localhost:3000/social/instagram/bravotv"],
    [
      "/social/profiles/instagram/bravotv/comments?run_id=demo",
      "http://admin.localhost:3000/social/instagram/bravotv/comments?run_id=demo",
    ],
  ])("redirects legacy social profile URL %s to its canonical profile route", (pathname, expectedLocation) => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(`http://admin.localhost:3000${pathname}`);
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(expectedLocation);
  });

  it.each([
    ["/rhoslc/cast", "http://admin.localhost:3000/rhoslc/credits"],
    ["/rhoslc/s6/cast", "http://admin.localhost:3000/rhoslc/s6/credits"],
  ])("redirects legacy short admin-host cast aliases to credits: %s", (pathname, expectedLocation) => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(`http://admin.localhost:3000${pathname}`);
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(expectedLocation);
  });

  it("preserves the incoming search string once when rewriting canonical social profile routes", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(
      "http://admin.localhost:3000/social/instagram/bravotv/catalog?tab=recent&sort=desc",
    );
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
    expect(response.headers.get("x-middleware-rewrite")).toBeNull();
    expect(response.headers.get("location")).toBeNull();
  });

  it("keeps root show routes on the public host", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/rhoslc/s6/social/reddit");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("redirects /brands requests on public host to admin origin", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/brands/networks-and-streaming");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(
      "http://admin.localhost:3000/brands",
    );
  });

  it("redirects legacy brands /admin routes to canonical /brands routes", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(
      "http://admin.localhost:3000/admin/networks-and-streaming/network/bravo",
    );
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(
      "http://admin.localhost:3000/brands/bravo",
    );
  });

  it("redirects legacy /admin/brands brand slugs to canonical /brands brand profile routes", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/admin/brands/instagram");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(
      "http://admin.localhost:3000/brands/instagram",
    );
  });

  it("redirects /admin requests from 127.0.0.1 to admin origin", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://127.0.0.1:3000/admin/fonts");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("http://admin.localhost:3000/admin/fonts");
  });

  it("blocks /api/admin requests on non-admin host", async () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/api/admin/auth/status");
    const response = proxy(request);

    expect(response.status).toBe(403);
    await expect(response.json()).resolves.toMatchObject({
      error: "Admin API is not available on this host.",
    });
  });

  it("allows /api/admin requests on ADMIN_APP_HOSTS hosts even when non-canonical", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_APP_HOSTS = "localhost";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/api/admin/auth/status");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("does not rewrite admin API progress routes into admin UI pages", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(
      "http://admin.localhost:3000/api/admin/trr-api/social/profiles/instagram/bravotv/comments/runs/5bc3a298-b647-4f2b-ad49-d3d7b95e35a4/progress",
    );
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
    expect(response.headers.get("x-middleware-rewrite")).toBeNull();
    expect(response.headers.get("location")).toBeNull();
  });

  it("keeps /admin requests on the current production host when no explicit admin origin is configured", () => {
    process.env.NODE_ENV = "production";
    delete process.env.ADMIN_APP_ORIGIN;
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("https://trr-app.vercel.app/admin");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("allows /api/admin requests on the current production host when no explicit admin origin is configured", () => {
    process.env.NODE_ENV = "production";
    delete process.env.ADMIN_APP_ORIGIN;
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("https://trr-app.vercel.app/api/admin/auth/status");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("allows admin routes on admin host", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/admin/fonts");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("allows design-system routes on admin host", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/design-system/questions-forms/admin");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("redirects /shows detail routes to the short admin-host show URL", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/shows/rhoslc");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("http://admin.localhost:3000/rhoslc");
  });

  it("rewrites /people detail routes to the admin person workspace on admin host", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/people/mary-cosby");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-rewrite")).toBe(
      "http://admin.localhost:3000/admin/trr-shows/people/mary-cosby",
    );
  });

  it("rewrites canonical person gallery URLs with show query context into the admin workspace without self-redirecting", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/people/mary-cosby/gallery?showId=rhoslc");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-rewrite")).toBe(
      "http://admin.localhost:3000/admin/trr-shows/people/mary-cosby/gallery?showId=rhoslc",
    );
  });

  it("rewrites person gallery routes without show context to the admin person workspace on admin host", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/people/mary-cosby/gallery");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-rewrite")).toBe(
      "http://admin.localhost:3000/admin/trr-shows/people/mary-cosby/gallery",
    );
  });

  it.each([
    [
      "http://admin.localhost:3000/admin/trr-shows/rhoslc",
      "http://admin.localhost:3000/rhoslc",
    ],
    [
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/credits",
      "http://admin.localhost:3000/rhoslc/credits",
    ],
    [
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/cast",
      "http://admin.localhost:3000/rhoslc/credits",
    ],
    [
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/season-6/social",
      "http://admin.localhost:3000/rhoslc/s6/social",
    ],
    [
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/season-6/credits",
      "http://admin.localhost:3000/rhoslc/s6/credits",
    ],
    [
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/season-6/cast",
      "http://admin.localhost:3000/rhoslc/s6/credits",
    ],
    [
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6/social/week/0",
      "http://admin.localhost:3000/rhoslc/s6/social/w0/details",
    ],
    [
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6/social/week/0/youtube",
      "http://admin.localhost:3000/rhoslc/s6/social/w0/youtube",
    ],
    [
      "http://admin.localhost:3000/rhoslc/seasons/6/social/week/0/youtube",
      "http://admin.localhost:3000/rhoslc/s6/social/w0/youtube",
    ],
  ])("redirects legacy internal admin URLs back to the short canonical URL: %s", (inputUrl, expectedLocation) => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(inputUrl);
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe(expectedLocation);
  });

  it("settles legacy admin show social-week URLs after one 307", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const chain = followProxyRedirects(
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6/social/week/0/youtube",
    );

    expect(chain.locations).toEqual(["http://admin.localhost:3000/rhoslc/s6/social/w0/youtube"]);
    expect(chain.statuses).toEqual([307, 200]);
  });

  it("redirects internal admin person workspace URLs back to the short canonical /people URL", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest(
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/people/mary-cosby/settings",
    );
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("http://admin.localhost:3000/people/mary-cosby/settings");
  });

  it("redirects unmatched show-level public routes away from guard pages and back into the admin workspace", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/rhoslc/unmatched-public-route");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("http://admin.localhost:3000/admin/trr-shows/rhoslc");
  });

  it("rewrites unmatched season-level public routes into the admin season workspace", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/rhoslc/s6/unmatched-public-route");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-rewrite")).toBe(
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6",
    );
  });

  it("does not canonicalize malformed internal season aliases into public placeholder routes", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/admin/trr-shows/rhoslc/season-index/videos");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("allows /people root on admin host", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/people");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("rewrites root show reddit routes on admin host into the admin season workspace", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    delete process.env.ADMIN_APP_HOSTS;
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://admin.localhost:3000/rhoslc/s6/social/reddit");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-rewrite")).toBe(
      "http://admin.localhost:3000/admin/trr-shows/rhoslc/seasons/6?tab=social&social_view=reddit",
    );
  });

  it("uses host header precedence when URL hostname differs in local dev", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/admin/fonts", {
      headers: {
        host: "admin.localhost:3000",
      },
    });
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("allows admin routes on bracketed IPv6 admin host", () => {
    process.env.ADMIN_APP_ORIGIN = "http://[::1]:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://[::1]:3000/admin/fonts");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("redirects non-admin paths to / on admin host when strict routing is enabled", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_APP_HOSTS = "localhost";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "true";

    const request = new NextRequest("http://admin.localhost:3000/hub");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("http://admin.localhost:3000/");
  });

  it("does not redirect design-system routes to /admin when strict routing is enabled", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_APP_HOSTS = "localhost";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "true";

    const request = new NextRequest("http://admin.localhost:3000/design-system/icons-illustrations");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("still redirects /admin UI paths to canonical origin even when host is allowlisted for admin API", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_APP_HOSTS = "localhost";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "false";

    const request = new NextRequest("http://localhost:3000/admin/fonts");
    const response = proxy(request);

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toBe("http://admin.localhost:3000/admin/fonts");
  });

  it("does not redirect /api/session/login on admin host when strict routing is enabled", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "true";

    const request = new NextRequest("http://admin.localhost:3000/api/session/login");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });

  it("does not redirect /api/session/logout on admin host when strict routing is enabled", () => {
    process.env.ADMIN_APP_ORIGIN = "http://admin.localhost:3000";
    process.env.ADMIN_ENFORCE_HOST = "true";
    process.env.ADMIN_STRICT_HOST_ROUTING = "true";

    const request = new NextRequest("http://admin.localhost:3000/api/session/logout");
    const response = proxy(request);

    expect(response.status).toBe(200);
    expect(response.headers.get("x-middleware-next")).toBe("1");
  });
});
