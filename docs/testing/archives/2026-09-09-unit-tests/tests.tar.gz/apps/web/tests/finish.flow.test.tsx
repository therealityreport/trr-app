// @ts-nocheck - Test files use different module resolution and mock configurations
import React from 'react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import * as usersDb from '@/lib/db/users';
import { captureExpectedConsoleLog, captureExpectedConsoleWarn } from './helpers/expected-console';

const replace = vi.fn();
const router = { replace };

vi.mock('next/navigation', () => ({
  useRouter: () => router,
}));

vi.mock('@/lib/firebase', () => ({
  auth: {
    onAuthStateChanged: (cb: any) => { cb({ uid: 'u1', email: 'a@example.com', providerData: [], getIdToken: async () => 't' }); return () => {}; },
  },
}));

vi.mock('@/lib/db/users', () => ({
  getUserProfile: vi.fn().mockResolvedValue(null),
  upsertUserProfile: vi.fn().mockResolvedValue(undefined),
  getUserByUsername: vi.fn()
    .mockResolvedValueOnce({ uid: 'u2' }) // first check: taken
    .mockResolvedValue(null), // then available
}));

import FinishPage from '@/app/auth/finish/page';
import { ALL_SHOWS } from '@/lib/data/shows';

const REQUESTED_SHOWS = [
  'Summer House',
  'The Real Housewives of Rhode Island',
  'Love Island USA',
];

describe('/auth/finish interactions', () => {
  beforeEach(() => {
    sessionStorage.clear();
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ shows: [] }),
    } as Response));
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('enforces min-3 shows and username uniqueness on blur', async () => {
    const expectedLogs = captureExpectedConsoleLog(/^Finish: /);
    render(<FinishPage />);
    // wait for page render (username input appears)
    const uname = await screen.findByLabelText(/username/i);
    fireEvent.change(uname, { target: { value: 'taken_user' } });
    fireEvent.blur(uname);
    expect(await screen.findByText(/taken/i)).toBeInTheDocument();

    // select first three shows
    const firstThree = ALL_SHOWS.slice(0, 3);
    for (const s of firstThree) {
      fireEvent.click(screen.getByRole('button', { name: s }));
    }
    // error for shows should disappear when >=3
    for (const s of firstThree) {
      expect(screen.getByRole('button', { name: s })).toHaveAttribute('aria-pressed', 'true');
    }
    expectedLogs.expectCalled();
  });

  it('renders API-provided covered shows in the picker list', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        shows: REQUESTED_SHOWS.map((name) => ({ id: name, name, alternativeNames: [] })),
      }),
    } as Response));

    render(<FinishPage />);

    for (const show of REQUESTED_SHOWS) {
      expect(await screen.findByRole('button', { name: show })).toBeInTheDocument();
    }
  });

  it('falls back to the local show list when the API is unavailable', async () => {
    const consoleError = vi.spyOn(console, 'error').mockImplementation(() => {});
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new Error('shows unavailable')));

    render(<FinishPage />);

    expect(await screen.findByRole('button', { name: ALL_SHOWS[0] })).toBeInTheDocument();
    consoleError.mockRestore();
  });

  it('captures show requests from the request CTA', async () => {
    const expectedLogs = captureExpectedConsoleLog(/^Finish: /);
    render(<FinishPage />);
    await screen.findByRole('button', { name: ALL_SHOWS[0] });

    const toggleText = await screen.findByText(/request on here/i);
    fireEvent.click(toggleText.closest('button') as HTMLButtonElement);

    const input = screen.getByPlaceholderText(/type a show name/i);
    fireEvent.change(input, { target: { value: 'The Valley' } });
    fireEvent.click(screen.getByRole('button', { name: /add/i }));

    expect(screen.getByLabelText(/remove requested show the valley/i)).toBeInTheDocument();
    const raw = sessionStorage.getItem('finish_show_requests');
    expect(raw).toContain('The Valley');
    expectedLogs.expectCalled();
  });

  it('keeps the form usable when username lookup fails', async () => {
    const expectedLogs = captureExpectedConsoleLog(/^Finish: /);
    const expectedWarn = captureExpectedConsoleWarn(
      /^Finish: username uniqueness lookup unavailable; skipping live uniqueness check .*firestore unavailable/,
    );
    vi.mocked(usersDb.getUserByUsername).mockRejectedValueOnce(new Error('firestore unavailable'));
    render(<FinishPage />);
    const uname = await screen.findByLabelText(/username/i);
    fireEvent.change(uname, { target: { value: 'fallback_user' } });
    fireEvent.blur(uname);
    await waitFor(() => {
      expect(screen.queryByText(/taken/i)).not.toBeInTheDocument();
    });
    expectedLogs.expectCalled();
    expectedWarn.expectCalled();
  });
});
