import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";

const { requireAdminMock, getBackendApiUrlMock } = vi.hoisted(() => ({
  requireAdminMock: vi.fn(),
  getBackendApiUrlMock: vi.fn(),
}));

vi.mock("@/lib/server/auth", () => ({
  requireAdmin: requireAdminMock,
}));

vi.mock("@/lib/server/trr-api/backend", () => ({
  getBackendApiUrl: getBackendApiUrlMock,
}));

import { POST } from "@/app/api/admin/trr-api/shows/[showId]/refresh/stream/route";

const BACKEND_STREAM_URL = "https://backend.example.com/api/v1/admin/shows/show-1/refresh/stream";
const BACKEND_HEALTH_URL = "https://backend.example.com/health";

const makeRequest = () =>
  new NextRequest(
    "http://localhost/api/admin/trr-api/shows/show-1/refresh/stream",
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ targets: ["photos"] }),
    },
  );

describe("show refresh stream proxy route", () => {
  beforeEach(() => {
    requireAdminMock.mockReset();
    getBackendApiUrlMock.mockReset();
    vi.restoreAllMocks();
    requireAdminMock.mockResolvedValue(undefined);
    getBackendApiUrlMock.mockReturnValue(BACKEND_STREAM_URL);
    process.env.TRR_INTERNAL_ADMIN_SHARED_SECRET = "internal-secret";
  });

  it("retries transient fetch errors and then returns streamed response", async () => {
    let streamAttempts = 0;
    const fetchMock = vi.fn().mockImplementation((input: RequestInfo | URL) => {
      const url = String(input);
      if (url === BACKEND_HEALTH_URL) {
        return Promise.resolve(new Response(JSON.stringify({ ok: true }), { status: 200 }));
      }
      streamAttempts += 1;
      if (streamAttempts === 1) {
        return Promise.reject(new Error("fetch failed"));
      }
      return Promise.resolve(
        new Response("event: progress\ndata: {\"stage\":\"syncing\"}\n\n", {
          status: 200,
          headers: { "content-type": "text/event-stream" },
        })
      );
    });
    vi.stubGlobal("fetch", fetchMock);

    const response = await POST(makeRequest(), {
      params: Promise.resolve({ showId: "show-1" }),
    });
    const payload = await response.text();

    expect(response.status).toBe(200);
    expect(fetchMock).toHaveBeenCalledTimes(3);
    expect(payload).toContain("\"syncing\"");
    const streamCall = fetchMock.mock.calls.find((call) => String(call[0]) === BACKEND_STREAM_URL);
    const finalBody = (streamCall?.[1] as RequestInit | undefined)?.body;
    expect(typeof finalBody).toBe("string");
    expect(JSON.parse(String(finalBody))).toEqual({ targets: ["photos"] });
  });

  it("emits terminal BACKEND_UNRESPONSIVE when preflight health check fails", async () => {
    const fetchMock = vi.fn().mockImplementation((input: RequestInfo | URL) => {
      const url = String(input);
      if (url === BACKEND_HEALTH_URL) {
        return Promise.reject(new Error("fetch failed"));
      }
      return Promise.resolve(new Response("event: progress\ndata: {\"stage\":\"syncing\"}\n\n", { status: 200 }));
    });
    vi.stubGlobal("fetch", fetchMock);

    const response = await POST(makeRequest(), {
      params: Promise.resolve({ showId: "show-1" }),
    });
    const payload = await response.text();

    expect(response.status).toBe(200);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(payload).toContain("\"checkpoint\":\"backend_preflight_failed\"");
    expect(payload).toContain("\"error_code\":\"BACKEND_UNRESPONSIVE\"");
    expect(payload).toContain("\"is_terminal\":true");
  });
});
