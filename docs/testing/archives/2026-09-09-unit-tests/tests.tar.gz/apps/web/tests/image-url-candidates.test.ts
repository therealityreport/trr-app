import { describe, expect, it } from "vitest";

import {
  buildCardImageUrlCandidates,
  buildDetailImageUrlCandidates,
  getPersonPhotoCardUrlCandidates,
  getPersonPhotoOriginalUrlCandidates,
  getSeasonAssetCardUrlCandidates,
} from "@/lib/admin/image-url-candidates";

describe("image-url-candidates", () => {
  it("builds ordered card candidates and dedupes", () => {
    const candidates = buildCardImageUrlCandidates({
      cropDisplayUrl: " https://cdn.example.com/crop.webp ",
      thumbUrl: "https://cdn.example.com/thumb.webp",
      displayUrl: "https://cdn.example.com/display.webp",
      hostedUrl: "https://cdn.example.com/display.webp",
      originalUrl: "https://origin.example.com/original.jpg",
      sourceUrl: "https://origin.example.com/original.jpg",
    });

    expect(candidates).toEqual([
      "https://cdn.example.com/crop.webp",
      "https://cdn.example.com/thumb.webp",
      "https://cdn.example.com/display.webp",
      "https://origin.example.com/original.jpg",
    ]);
  });

  it("builds ordered detail candidates", () => {
    const candidates = buildDetailImageUrlCandidates({
      cropDetailUrl: "https://cdn.example.com/crop-detail.webp",
      detailUrl: "https://cdn.example.com/detail.webp",
      hostedUrl: "https://cdn.example.com/hosted.webp",
      originalUrl: "https://origin.example.com/original.jpg",
      sourceUrl: "https://origin.example.com/source.jpg",
    });

    expect(candidates).toEqual([
      "https://cdn.example.com/hosted.webp",
      "https://origin.example.com/source.jpg",
      "https://origin.example.com/original.jpg",
      "https://cdn.example.com/detail.webp",
      "https://cdn.example.com/crop-detail.webp",
    ]);
  });

  it("prioritizes season card crop/thumb/display before hosted/original/source", () => {
    const candidates = getSeasonAssetCardUrlCandidates({
      hosted_url: "https://cdn.example.com/hosted.webp",
      crop_display_url: "https://cdn.example.com/crop.webp",
      thumb_url: "https://cdn.example.com/thumb.webp",
      display_url: "https://cdn.example.com/display.webp",
      original_url: "https://origin.example.com/original.jpg",
      source_url: "https://origin.example.com/source.jpg",
    });

    expect(candidates).toEqual([
      "https://cdn.example.com/crop.webp",
      "https://cdn.example.com/thumb.webp",
      "https://cdn.example.com/display.webp",
      "https://cdn.example.com/hosted.webp",
      "https://origin.example.com/original.jpg",
      "https://origin.example.com/source.jpg",
    ]);
  });

  it("prefers original/source before hosted for person original candidates", () => {
    const candidates = getPersonPhotoOriginalUrlCandidates({
      original_url: "https://origin.example.com/original.jpg",
      url: "https://origin.example.com/source.jpg",
      hosted_url: "https://cdn.example.com/hosted.webp",
    });

    expect(candidates).toEqual([
      "https://origin.example.com/original.jpg",
      "https://origin.example.com/source.jpg",
      "https://cdn.example.com/hosted.webp",
    ]);
  });

  it("prefers uncropped/base candidates before crop_display for person gallery cards", () => {
    const candidates = getPersonPhotoCardUrlCandidates({
      crop_display_url: "https://cdn.example.com/crop.webp",
      thumb_url: "https://cdn.example.com/thumb.webp",
      display_url: "https://cdn.example.com/display.webp",
      hosted_url: "https://cdn.example.com/hosted.webp",
      original_url: "https://origin.example.com/original.jpg",
      url: "https://origin.example.com/source.jpg",
    });

    expect(candidates).toEqual([
      "https://cdn.example.com/thumb.webp",
      "https://cdn.example.com/display.webp",
      "https://cdn.example.com/hosted.webp",
      "https://origin.example.com/original.jpg",
      "https://origin.example.com/source.jpg",
      "https://cdn.example.com/crop.webp",
    ]);
  });

  it("prioritizes mirrored hosted candidates before external display variants", () => {
    const candidates = buildCardImageUrlCandidates({
      cropDisplayUrl: "https://origin.example.com/crop.jpg",
      thumbUrl: "https://origin.example.com/thumb.jpg",
      displayUrl: "https://origin.example.com/display.jpg",
      hostedUrl: "https://pub-a3c452f3df0d40319f7c585253a4776c.r2.dev/media/hosted.webp",
      originalUrl: "https://origin.example.com/original.jpg",
      sourceUrl: "https://origin.example.com/source.jpg",
    });

    expect(candidates[0]).toBe("https://pub-a3c452f3df0d40319f7c585253a4776c.r2.dev/media/hosted.webp");
    expect(candidates.slice(1)).toEqual([
      "https://origin.example.com/crop.jpg",
      "https://origin.example.com/thumb.jpg",
      "https://origin.example.com/display.jpg",
      "https://origin.example.com/original.jpg",
      "https://origin.example.com/source.jpg",
    ]);
  });

  it("rewrites legacy CloudFront hosted candidates onto the canonical R2 host", () => {
    const candidates = buildDetailImageUrlCandidates({
      hostedUrl: "https://d111111abcdef8.cloudfront.net/media/aa/bb.webp",
      detailUrl: "https://origin.example.com/detail.jpg",
      cropDetailUrl: "https://origin.example.com/crop-detail.jpg",
      originalUrl: "https://origin.example.com/original.jpg",
      sourceUrl: "https://origin.example.com/source.jpg",
    });

    expect(candidates[0]).toBe("https://pub-a3c452f3df0d40319f7c585253a4776c.r2.dev/media/aa/bb.webp");
  });

  it("keeps stale gallery variant candidates first but canonicalizes them off legacy CloudFront", () => {
    const candidates = getPersonPhotoCardUrlCandidates({
      display_url: "https://d1fmdyqfafwim3.cloudfront.net/media-variants/asset-1/base/card.webp",
      hosted_url: "https://d1fmdyqfafwim3.cloudfront.net/images/people/example/photo.jpg",
      original_url: "https://www.bravotv.com/sites/bravo/files/2025/08/rhoslc_s6_lisa_1x1.png",
      url: "https://www.bravotv.com/people/lisa-barlow",
    });

    expect(candidates).toEqual([
      "https://pub-a3c452f3df0d40319f7c585253a4776c.r2.dev/media-variants/asset-1/base/card.webp",
      "https://pub-a3c452f3df0d40319f7c585253a4776c.r2.dev/images/people/example/photo.jpg",
      "https://www.bravotv.com/sites/bravo/files/2025/08/rhoslc_s6_lisa_1x1.png",
      "https://www.bravotv.com/people/lisa-barlow",
    ]);
  });

  it("canonicalizes legacy cast-photo variant candidates for gallery card rendering", () => {
    const candidates = getPersonPhotoCardUrlCandidates({
      display_url: "https://d1fmdyqfafwim3.cloudfront.net/cast-photo-variants/asset-1/base/card.webp",
      thumb_url: "https://d1fmdyqfafwim3.cloudfront.net/cast-photo-variants/asset-1/base/thumb.webp",
      detail_url: "https://d1fmdyqfafwim3.cloudfront.net/cast-photo-variants/asset-1/base/detail.webp",
      hosted_url: "https://pub-a3c452f3df0d40319f7c585253a4776c.r2.dev/images/people/example/photo.jpg",
    });

    expect(candidates).toEqual([
      "https://pub-a3c452f3df0d40319f7c585253a4776c.r2.dev/cast-photo-variants/asset-1/base/thumb.webp",
      "https://pub-a3c452f3df0d40319f7c585253a4776c.r2.dev/cast-photo-variants/asset-1/base/card.webp",
      "https://pub-a3c452f3df0d40319f7c585253a4776c.r2.dev/images/people/example/photo.jpg",
    ]);
  });
});
