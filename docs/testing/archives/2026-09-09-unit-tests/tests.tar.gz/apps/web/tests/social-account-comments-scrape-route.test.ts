import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";

const {
  requireAdminMock,
  buildAdminAuthPartitionMock,
  buildAdminSnapshotCacheKeyMock,
  getOrCreateAdminSnapshotMock,
  buildAdminReadResponseHeadersMock,
  fetchSocialBackendJsonMock,
  invalidateAdminSnapshotFamiliesMock,
  socialProxyErrorResponseMock,
} = vi.hoisted(() => ({
  requireAdminMock: vi.fn(),
  buildAdminAuthPartitionMock: vi.fn(),
  buildAdminSnapshotCacheKeyMock: vi.fn(),
  getOrCreateAdminSnapshotMock: vi.fn(),
  buildAdminReadResponseHeadersMock: vi.fn(),
  fetchSocialBackendJsonMock: vi.fn(),
  invalidateAdminSnapshotFamiliesMock: vi.fn(),
  socialProxyErrorResponseMock: vi.fn(),
}));

vi.mock("@/lib/server/auth", () => ({
  requireAdmin: requireAdminMock,
}));

vi.mock("@/lib/server/trr-api/social-admin-proxy", () => ({
  fetchSocialBackendJson: fetchSocialBackendJsonMock,
  socialProxyErrorResponse: socialProxyErrorResponseMock,
}));

vi.mock("@/lib/server/admin/admin-snapshot-cache", () => ({
  buildAdminAuthPartition: buildAdminAuthPartitionMock,
  buildAdminSnapshotCacheKey: buildAdminSnapshotCacheKeyMock,
  getOrCreateAdminSnapshot: getOrCreateAdminSnapshotMock,
  invalidateAdminSnapshotFamilies: invalidateAdminSnapshotFamiliesMock,
}));

vi.mock("@/lib/server/trr-api/admin-read-proxy", () => ({
  buildAdminReadResponseHeaders: buildAdminReadResponseHeadersMock,
}));

import { POST } from "@/app/api/admin/trr-api/social/profiles/[platform]/[handle]/comments/scrape/route";

describe("social account comments scrape proxy route", () => {
  beforeEach(() => {
    requireAdminMock.mockReset();
    buildAdminAuthPartitionMock.mockReset();
    buildAdminSnapshotCacheKeyMock.mockReset();
    getOrCreateAdminSnapshotMock.mockReset();
    buildAdminReadResponseHeadersMock.mockReset();
    fetchSocialBackendJsonMock.mockReset();
    invalidateAdminSnapshotFamiliesMock.mockReset();
    socialProxyErrorResponseMock.mockReset();

    requireAdminMock.mockResolvedValue({ uid: "admin-1", provider: "firebase" });
    fetchSocialBackendJsonMock.mockResolvedValue({ run_id: "comments-run-1", status: "queued" });
    socialProxyErrorResponseMock.mockImplementation((error: unknown) =>
      new Response(JSON.stringify({ error: String(error), code: "BACKEND_UNREACHABLE" }), {
        status: 502,
        headers: { "content-type": "application/json" },
      }),
    );
  });

  it("forwards comments scrape launches to TRR-Backend as JSON objects", async () => {
    const response = await POST(
      new NextRequest("http://localhost/api/admin/trr-api/social/profiles/instagram/thetraitorsus/comments/scrape", {
        method: "POST",
        body: JSON.stringify({
          mode: "profile",
          source_scope: "network",
          refresh_policy: "all_saved_posts",
        }),
      }),
      {
        params: Promise.resolve({ platform: "instagram", handle: "thetraitorsus" }),
      },
    );

    expect(response.status).toBe(200);
    expect(fetchSocialBackendJsonMock).toHaveBeenCalledWith(
      "/profiles/instagram/thetraitorsus/comments/scrape",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({
          mode: "profile",
          source_scope: "network",
          refresh_policy: "all_saved_posts",
        }),
        fallbackError: "Failed to start social account comments scrape",
        retries: 0,
        timeoutMs: 210_000,
      }),
    );
    expect(invalidateAdminSnapshotFamiliesMock).toHaveBeenCalledWith([
      { pageFamily: "social-profile", scope: "instagram:thetraitorsus" },
    ]);
  });

  it("sends an empty JSON object when the launch body is blank", async () => {
    const response = await POST(
      new NextRequest("http://localhost/api/admin/trr-api/social/profiles/instagram/thetraitorsus/comments/scrape", {
        method: "POST",
        body: "   ",
      }),
      {
        params: Promise.resolve({ platform: "instagram", handle: "thetraitorsus" }),
      },
    );

    expect(response.status).toBe(200);
    expect(fetchSocialBackendJsonMock).toHaveBeenCalledWith(
      "/profiles/instagram/thetraitorsus/comments/scrape",
      expect.objectContaining({ body: "{}" }),
    );
  });

  it("returns standardized proxy errors", async () => {
    fetchSocialBackendJsonMock.mockRejectedValueOnce(new Error("fetch failed"));

    const response = await POST(
      new NextRequest("http://localhost/api/admin/trr-api/social/profiles/instagram/thetraitorsus/comments/scrape", {
        method: "POST",
        body: JSON.stringify({
          mode: "profile",
          source_scope: "network",
          refresh_policy: "all_saved_posts",
        }),
      }),
      {
        params: Promise.resolve({ platform: "instagram", handle: "thetraitorsus" }),
      },
    );
    const payload = (await response.json()) as { code?: string };

    expect(response.status).toBe(502);
    expect(payload.code).toBe("BACKEND_UNREACHABLE");
    expect(socialProxyErrorResponseMock).toHaveBeenCalledTimes(1);
  });
});
