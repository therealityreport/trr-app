import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

describe("show page person refresh Getty prefetch wiring", () => {
  const pagePath = path.resolve(
    __dirname,
    "../src/app/admin/trr-shows/[showId]/page.tsx"
  );
  const pageContents = fs.readFileSync(pagePath, "utf8");

  it("always uses local Getty prefetch before full person refresh runs", () => {
    expect(pageContents).toContain("prefetchGettyLocallyForPerson");
    expect(pageContents).not.toContain("getGettyRemoteReadiness()");
    expect(pageContents).toContain("show?.name ?? undefined");
    expect(pageContents).toContain("getty_prefetch_attempted: true");
    expect(pageContents).toContain("getty_prefetch_succeeded: false");
    expect(pageContents).toContain("Object.assign(body, gettyPrefetch.bodyPatch)");
    expect(pageContents).toContain('transportMode: "auto"');
    expect(pageContents).not.toContain("Getty remote probe healthy. Starting backend refresh without local prefetch.");
    expect(pageContents).toContain("Getty/NBCUMV refresh could not start during local Getty prefetch.");
    expect(pageContents).toContain("Getty/NBCUMV refresh was not started.");
  });

  it("passes personName through all show-page person refresh launchers", () => {
    expect(pageContents).toMatch(/mode,\s*\n\s*signal: options\?\.signal,\s*\n\s*personName: label,/);
  });
});
