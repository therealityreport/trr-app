import React from "react";
import { beforeEach, afterEach, describe, it, expect, vi } from "vitest";
import { fireEvent, render, screen, within } from "@testing-library/react";
import MatrixLikertInput from "@/components/survey/MatrixLikertInput";

function makeQuestion(configOverride: Record<string, unknown> = {}) {
  return {
    id: "q-agree",
    survey_id: "survey-1",
    question_key: "agree_scale",
    question_text: "How strongly do you agree?",
    question_type: "likert",
    display_order: 1,
    is_required: true,
    config: {
      uiVariant: "agree-likert-scale",
      rows: [
        { id: "s1", label: "Statement one" },
        { id: "s2", label: "Statement two" },
      ],
      ...configOverride,
    },
    created_at: "",
    updated_at: "",
    options: [
      {
        id: "o1",
        question_id: "q-agree",
        option_key: "strongly_disagree",
        option_text: "Strongly Disagree",
        display_order: 1,
        metadata: {},
        created_at: "",
      },
      {
        id: "o2",
        question_id: "q-agree",
        option_key: "somewhat_disagree",
        option_text: "Somewhat Disagree",
        display_order: 2,
        metadata: {},
        created_at: "",
      },
      {
        id: "o3",
        question_id: "q-agree",
        option_key: "neutral",
        option_text: "Neither",
        display_order: 3,
        metadata: {},
        created_at: "",
      },
      {
        id: "o4",
        question_id: "q-agree",
        option_key: "somewhat_agree",
        option_text: "Somewhat Agree",
        display_order: 4,
        metadata: {},
        created_at: "",
      },
      {
        id: "o5",
        question_id: "q-agree",
        option_key: "strongly_agree",
        option_text: "Strongly Agree",
        display_order: 5,
        metadata: {},
        created_at: "",
      },
    ],
  };
}

describe("MatrixLikertInput", () => {
  const originalMatchMedia = window.matchMedia;
  const originalGetBoundingClientRect = HTMLElement.prototype.getBoundingClientRect;

  beforeEach(() => {
    window.matchMedia = vi.fn().mockImplementation((query: string) => ({
      matches: query.includes("min-width") ? false : false,
      media: query,
      onchange: null,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      addListener: vi.fn(),
      removeListener: vi.fn(),
      dispatchEvent: vi.fn(),
    })) as typeof window.matchMedia;

    HTMLElement.prototype.getBoundingClientRect = vi.fn(() => ({
      width: 390,
      height: 100,
      top: 0,
      left: 0,
      right: 390,
      bottom: 100,
      x: 0,
      y: 0,
      toJSON: () => ({}),
    })) as typeof HTMLElement.prototype.getBoundingClientRect;
  });

  afterEach(() => {
    window.matchMedia = originalMatchMedia;
    HTMLElement.prototype.getBoundingClientRect = originalGetBoundingClientRect;
  });

  it("applies CDN-resolved font overrides to prompt, statement, and options", () => {
    render(
      <MatrixLikertInput
        question={makeQuestion({
          subTextHeadingFontFamily: "Gloucester",
          rowLabelFontFamily: "Rude Slab Condensed",
          optionTextFontFamily: "Plymouth Serial",
        }) as never}
        value={{}}
        onChange={() => {}}
      />,
    );

    expect(screen.getByTestId("agree-likert-prompt")).toHaveStyle({
      fontFamily: '"Gloucester", var(--font-sans), sans-serif',
    });
    expect(screen.getByText("Statement one")).toHaveStyle({
      fontFamily: '"Rude Slab Condensed", var(--font-sans), sans-serif',
    });
    expect(screen.getByRole("button", { name: "Select Strongly Agree for Statement one" })).toHaveStyle({
      fontFamily: '"Plymouth Serial", var(--font-sans), sans-serif',
    });
    expect(screen.queryByTestId("matrix-likert-missing-fonts")).not.toBeInTheDocument();
  });

  it("uses exact fallback typography values instead of width interpolation", () => {
    render(
      <MatrixLikertInput
        question={makeQuestion() as never}
        value={{}}
        onChange={() => {}}
      />,
    );

    expect(screen.getByTestId("agree-likert-prompt")).toHaveStyle({
      fontSize: "28px",
      lineHeight: "1.05",
      letterSpacing: "0em",
    });
    expect(screen.getByText("Statement one")).toHaveStyle({
      fontSize: "24px",
      lineHeight: "1.05",
    });
    expect(screen.getByRole("button", { name: "Select Strongly Agree for Statement one" })).toHaveStyle({
      fontFamily: '"Plymouth Serial", var(--font-sans), sans-serif',
    });
    expect(within(screen.getByRole("button", { name: "Select Strongly Agree for Statement one" })).getByText("Strongly Agree")).toHaveStyle({
      fontSize: "13px",
      lineHeight: "1.2",
    });
  });

  it("keeps text typography stable even when the container width changes", () => {
    const narrowRect = vi.fn(() => ({
      width: 390,
      height: 100,
      top: 0,
      left: 0,
      right: 390,
      bottom: 100,
      x: 0,
      y: 0,
      toJSON: () => ({}),
    }));
    const wideRect = vi.fn(() => ({
      width: 1320,
      height: 100,
      top: 0,
      left: 0,
      right: 1320,
      bottom: 100,
      x: 0,
      y: 0,
      toJSON: () => ({}),
    }));

    HTMLElement.prototype.getBoundingClientRect = narrowRect as typeof HTMLElement.prototype.getBoundingClientRect;
    const narrow = render(
      <MatrixLikertInput
        question={makeQuestion() as never}
        value={{}}
        onChange={() => {}}
      />,
    );

    const narrowPrompt = screen.getByTestId("agree-likert-prompt");
    const narrowStatement = screen.getByText("Statement one");
    const narrowOptionLabel = within(screen.getByRole("button", { name: "Select Strongly Agree for Statement one" })).getByText("Strongly Agree");

    const narrowStyles = {
      prompt: narrowPrompt.getAttribute("style"),
      statement: narrowStatement.getAttribute("style"),
      option: narrowOptionLabel.getAttribute("style"),
    };

    narrow.unmount();

    HTMLElement.prototype.getBoundingClientRect = wideRect as typeof HTMLElement.prototype.getBoundingClientRect;
    render(
      <MatrixLikertInput
        question={makeQuestion() as never}
        value={{}}
        onChange={() => {}}
      />,
    );

    expect(screen.getByTestId("agree-likert-prompt").getAttribute("style")).toContain("font-size: 28px");
    expect(screen.getByTestId("agree-likert-prompt").getAttribute("style")).toBe(narrowStyles.prompt);
    expect(screen.getByText("Statement one").getAttribute("style")).toBe(narrowStyles.statement);
    expect(within(screen.getByRole("button", { name: "Select Strongly Agree for Statement one" })).getByText("Strongly Agree").getAttribute("style")).toBe(narrowStyles.option);
  });

  it("shows warning when required hosted fonts are missing", () => {
    render(
      <MatrixLikertInput
        question={makeQuestion({
          rowLabelFontFamily: "Totally Missing Font",
          canvaFonts: ["Totally Missing Font"],
        }) as never}
        value={{}}
        onChange={() => {}}
      />,
    );

    expect(screen.getByTestId("matrix-likert-missing-fonts")).toHaveTextContent(
      "Missing hosted fonts: Totally Missing Font",
    );
  });

  it("stores per-row selection values when options are clicked", () => {
    const updates: Array<Record<string, string>> = [];

    function Harness() {
      const [value, setValue] = React.useState<Record<string, string> | null>({});
      return (
        <MatrixLikertInput
          question={makeQuestion() as never}
          value={value}
          onChange={(next) => {
            updates.push(next);
            setValue(next);
          }}
        />
      );
    }

    render(<Harness />);
    expect(screen.queryByTestId("agree-likert-continue")).not.toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Select Somewhat Agree for Statement one" }));
    expect(screen.getByTestId("agree-likert-continue")).toHaveTextContent("Continue");
    fireEvent.click(screen.getByRole("button", { name: "Select Strongly Disagree for Statement two" }));

    expect(updates).toContainEqual({ s1: "somewhat_agree" });
    expect(updates).toContainEqual({ s1: "somewhat_agree", s2: "strongly_disagree" });
  });

  it("toggles a selected option off when clicked again", () => {
    function Harness() {
      const [value, setValue] = React.useState<Record<string, string> | null>({});
      return (
        <MatrixLikertInput
          question={makeQuestion() as never}
          value={value}
          onChange={setValue}
        />
      );
    }

    render(<Harness />);

    const rowOneAgree = screen.getByRole("button", { name: "Select Somewhat Agree for Statement one" });
    fireEvent.click(rowOneAgree);
    expect(screen.getByTestId("agree-likert-continue")).toBeInTheDocument();

    fireEvent.click(rowOneAgree);
    expect(screen.queryByTestId("agree-likert-continue")).not.toBeInTheDocument();
  });

  it("orders and colors options in figma agree-to-disagree sequence", () => {
    const question = makeQuestion();
    question.options = [...question.options].reverse();

    render(
      <MatrixLikertInput
        question={question as never}
        value={{}}
        onChange={() => {}}
      />,
    );

    const row = screen.getByTestId("agree-likert-row-s1");
    expect(screen.getByTestId("agree-likert-rows")).toHaveStyle({ marginTop: "15px" });
    expect(screen.getByTestId("agree-likert-option-stack-s1")).toHaveStyle({ marginTop: "20px" });
    const buttons = within(row).getAllByRole("button");
    expect(buttons).toHaveLength(5);

    expect(buttons[0]).toHaveTextContent("Strongly Agree");
    expect(buttons[0]).toHaveStyle({ backgroundColor: "rgb(53, 106, 59)" });
    expect(buttons[0]).toHaveStyle({ color: "rgb(255, 255, 255)" });

    expect(buttons[1]).toHaveTextContent("Somewhat Agree");
    expect(buttons[1]).toHaveStyle({ backgroundColor: "rgb(118, 163, 76)" });
    expect(buttons[1]).toHaveStyle({ color: "rgb(0, 0, 0)" });

    expect(buttons[2]).toHaveTextContent("Neither");
    expect(buttons[2]).toHaveStyle({ backgroundColor: "rgb(230, 185, 3)" });
    expect(buttons[2]).toHaveStyle({ color: "rgb(0, 0, 0)" });

    expect(buttons[4]).toHaveTextContent("Strongly Disagree");
    expect(buttons[4]).toHaveStyle({ backgroundColor: "rgb(153, 6, 10)" });
    expect(buttons[4]).toHaveStyle({ color: "rgb(255, 255, 255)" });
  });

  it("applies shape and button scale overrides to bars and labels", () => {
    render(
      <MatrixLikertInput
        question={makeQuestion({ shapeScale: 70, buttonScale: 130 }) as never}
        value={{}}
        onChange={() => {}}
      />,
    );

    const button = screen.getByRole("button", { name: "Select Strongly Agree for Statement one" });
    const label = within(button).getByText("Strongly Agree");

    expect(Number.parseInt(button.style.borderRadius, 10)).toBeGreaterThanOrEqual(7);
    expect(Number.parseInt(button.style.minHeight, 10)).toBeGreaterThan(40);
    expect(Number.parseInt(label.style.fontSize, 10)).toBeGreaterThanOrEqual(12);
  });
});
