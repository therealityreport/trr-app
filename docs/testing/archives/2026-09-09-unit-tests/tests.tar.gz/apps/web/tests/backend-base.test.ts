import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { getBackendApiBase, getBackendApiUrl, getBackendRootBase, getBackendRootUrl } from "@/lib/server/trr-api/backend";

const originalNodeEnv = process.env.NODE_ENV;

describe("backend base normalization", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

afterEach(() => {
  delete process.env.TRR_API_URL;
  if (originalNodeEnv === undefined) {
    delete process.env.NODE_ENV;
  } else {
    process.env.NODE_ENV = originalNodeEnv;
  }
});

  it("returns null for blank TRR_API_URL values", () => {
    process.env.TRR_API_URL = "   ";

    expect(getBackendRootBase()).toBeNull();
    expect(getBackendApiBase()).toBeNull();
    expect(getBackendRootUrl("/health")).toBeNull();
    expect(getBackendApiUrl("/admin/socials/ingest/queue-status")).toBeNull();
  });

  it("trims whitespace and normalizes localhost to 127.0.0.1", () => {
    process.env.TRR_API_URL = "  http://localhost:8000/  ";

    expect(getBackendRootBase()).toBe("http://127.0.0.1:8000");
    expect(getBackendRootUrl("/admin/health/db-pressure")).toBe("http://127.0.0.1:8000/admin/health/db-pressure");
    expect(getBackendApiBase()).toBe("http://127.0.0.1:8000/api/v1");
    expect(getBackendApiBase("v2")).toBe("http://127.0.0.1:8000/api/v2");
    expect(getBackendApiUrl("admin/socials/ingest/queue-status")).toBe(
      "http://127.0.0.1:8000/api/v1/admin/socials/ingest/queue-status",
    );
  });

  it("normalizes API-prefixed backend URLs back to the root for root-level health routes", () => {
    process.env.TRR_API_URL = "http://localhost:8000/api/v1/";

    expect(getBackendRootBase()).toBe("http://127.0.0.1:8000");
    expect(getBackendRootUrl("/health")).toBe("http://127.0.0.1:8000/health");
    expect(getBackendApiBase()).toBe("http://127.0.0.1:8000/api/v1");
  });

  it("normalizes v2-prefixed roots and builds explicit v2 API URLs", () => {
    process.env.TRR_API_URL = "http://localhost:8000/api/v2/";

    expect(getBackendRootBase()).toBe("http://127.0.0.1:8000");
    expect(getBackendApiBase("v2")).toBe("http://127.0.0.1:8000/api/v2");
    expect(getBackendApiUrl("/admin/covered-shows", "v2")).toBe(
      "http://127.0.0.1:8000/api/v2/admin/covered-shows",
    );
  });

  it("supports Portless backend aliases for root health and API routes", () => {
    process.env.TRR_API_URL = "https://api.trr.localhost";

    expect(getBackendRootBase()).toBe("https://api.trr.localhost");
    expect(getBackendRootUrl("/admin/health/db-pressure")).toBe("https://api.trr.localhost/admin/health/db-pressure");
    expect(getBackendApiUrl("/admin/socials")).toBe("https://api.trr.localhost/api/v1/admin/socials");
  });

  it("warns once when TRR_API_URL points at a remote host in development", () => {
    process.env.NODE_ENV = "development";
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => undefined);
    process.env.TRR_API_URL = "https://backend.example.com";

    expect(getBackendRootBase()).toBe("https://backend.example.com");
    expect(getBackendApiBase()).toBe("https://backend.example.com/api/v1");
    expect(getBackendApiBase()).toBe("https://backend.example.com/api/v1");
    expect(warnSpy).toHaveBeenCalledTimes(1);
    expect(String(warnSpy.mock.calls[0]?.[0] ?? "")).toContain("TRR_API_URL points to a remote host");
  });
});
